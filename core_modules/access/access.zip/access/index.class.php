<?php
/**
* Contact Module
*
* This module handles all HTML FORMs with action tags to the contact section.
* It sends the contact email(s) and uploads data (optional)
* Ex. <FORM name="form1" action="index.php?section=contact&cmd=thanks" method="post">
*
* @copyright   CONTREXX CMS - Astalavista IT Engineering GmbH Thun
* @author      Astalavista Development Team <thun@astalvista.ch>
* @module      contact
* @modulegroup modules
* @version     1.1.0
*/
require_once ASCMS_CORE_MODULE_PATH.'/contact/lib/ContactLib.class.php';

class Contact extends ContactLib
{

    var $enabledUploadFileExtensions = array("txt","doc","xls","pdf","ppt","gif","jpg","png","xml",
                                             "odt","ott","sxw","stw","dot","rtf","sdw","wpd","jtd",
                                             "jtt","hwp","wps","ods","ots","sxc","stc","dif","dbf",
                                             "xlw","xlt","sdc","vor","sdc","cvs","slk","wk1","wks",
                                             "123","odp","otp","sxi","sti","pps","pot","sxd","sda",
                                             "sdd","sdp","cgm","odg","otg","sxd","std","dxf","emf",
                                             "eps","met","pct","sgf","sgv","svm","wmf","bmp","jpeg",
                                             "jfif","jif","jpe","pbm","pcx","pgm","ppm","psd","ras",
                                             "tga","tif","tiff","xbm","xpm","pcd","oth","odm","sxg",
                                             "sgl","odb","odf","sxm","smf","mml","zip","rar");


    function Contact($pageContent)
    {
	    $this->__construct($pageContent);
	}

	function __construct($pageContent)
	{
		$this->pageContent = $pageContent;
		$this->objTemplate = &new HTML_Template_Sigma('.');
		$this->objTemplate->setErrorHandling(PEAR_ERROR_DIE);
	    $this->objTemplate->setTemplate($this->pageContent);
	}


    function getContactPage()
    {
    	if (isset($_POST['submitContactForm'])) {
    		$showThanks = (isset($_GET['cmd']) && $_GET['cmd'] == 'thanks') ? true : false;

	    	$arrFormData = &$this->_getContactFormData();
	    	if ($arrFormData) {
	    		if ($this->_checkValues($arrFormData)) {
		    		$this->_insertIntoDatabase($arrFormData);
		    		$this->_sendMail($arrFormData);
	    		} else {
	    			$this->_showError();
	    			return $this->objTemplate->get();
	    		}

	    		if (!$showThanks) {
	    			$this->_showFeedback($arrFormData);
	    		}
	    	}
    	}

    	if ($this->objTemplate->blockExists('contact_form')) {
	    	if (isset($arrFormData['showForm']) && !$arrFormData['showForm']) {
				$this->objTemplate->hideBlock('contact_form');
			} else {
				$this->objTemplate->touchBlock('contact_form');
			}
    	}

    	return $this->objTemplate->get();
    }

    function _getContactFormData()
    {
    	global $_ARRAYLANG, $_CONFIG;

		if (isset($_POST) && !empty($_POST)) {
			$arrFormData = array();
			$arrFormData['id'] = isset($_GET['cmd']) ? intval($_GET['cmd']) : 0;
			if ($this->getContactFormDetails($arrFormData['id'], $arrFormData['emails'], $arrFormData['subject'], $arrFormData['feedback'], $arrFormData['showForm'])) {
				$arrFormData['fields'] = $this->getFormFields($arrFormData['id']);
			} else {
				$arrFormData['id'] = 0;
				$arrFormData['emails'] = explode(',', $_CONFIG['contactFormEmail']);
				$arrFormData['subject'] = $_ARRAYLANG['TXT_CONTACT_FORM']." ".$_CONFIG['domainUrl'];
				$arrFormData['showForm'] = 1;
			}
			$arrFormData['uploadedFiles'] = $this->_uploadFiles($arrFormData['fields']);

			foreach ($_POST as $key => $value) {
				if (!empty($value) && $key != 'Submit' && $key != 'submitContactForm') {
					$id = intval(substr($key, 17));
					if (isset($arrFormData['fields'][$id])) {
						$key = $arrFormData['fields'][$id]['name'];
					} else {
						$key = stripslashes(contrexx_strip_tags($key));
					}
					if (is_array($value)) {
						$value = implode(', ', $value);
					}

					$arrFormData['data'][$key] = stripslashes(contrexx_strip_tags($value));
				}
			}

			if (isset($_SERVER["HTTP_X_FORWARDED_FOR"]) && !empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
				$arrFormData['meta']['ipaddress'] = $_SERVER["HTTP_X_FORWARDED_FOR"];
			} else {
				$arrFormData['meta']['ipaddress'] = $_SERVER["REMOTE_ADDR"];
			}

			$arrFormData['meta']['time'] = time();
			$arrFormData['meta']['host'] = contrexx_strip_tags(@gethostbyaddr($arrFormData['meta']['ipaddress']));
			$arrFormData['meta']['lang'] = contrexx_strip_tags($_SERVER["HTTP_ACCEPT_LANGUAGE"]);
			$arrFormData['meta']['browser'] = contrexx_strip_tags($_SERVER["HTTP_USER_AGENT"]);

			return $arrFormData;
		}
		return false;
    }

	function _insertIntoDatabase($arrFormData)
	{
		$arrDbEntry = array();

		if(!empty($arrFormData['data'])) {
			foreach ($arrFormData['data'] as $key => $value) {
				array_push($arrDbEntry, base64_encode($key).",".base64_encode($value));
			}
		}

		foreach ($arrFormData['uploadedFiles'] as $key => $file) {
			array_push($arrDbEntry, base64_encode($key).",".base64_encode(contrexx_strip_tags($file)));
		}

		$message = implode(';', $arrDbEntry);
		$this->_insertIntoDb($arrFormData['id'], $message, $arrFormData['meta']['time'], $arrFormData['meta']['host'], $arrFormData['meta']['lang'], $arrFormData['meta']['browser'], $arrFormData['meta']['ipaddress']);
	}




	function _sendMail($arrFormData)
	{
		global $_ARRAYLANG, $_CONFIG;

		$body = '';

		if (count($arrFormData['uploadedFiles']) > 0) {
			$body .= $_ARRAYLANG['TXT_CONTACT_UPLOADS'].":\n";
			foreach ($arrFormData['uploadedFiles'] as $key => $file) {
				$body .= $key.": ".ASCMS_PROTOCOL."://".$_CONFIG['domainUrl'].ASCMS_PATH_OFFSET.contrexx_strip_tags($file)."\n";
			}
			$body .= "\n";
		}


		if(!empty($arrFormData['data'])) {
			foreach ($arrFormData['data'] as $key => $value) {
				$body .= $key.": \t\t".htmlspecialchars($value)."\n";
			}
		}

		$message  = $_ARRAYLANG['TXT_CONTACT_TRANSFERED_DATA_FROM']." ".$_CONFIG['domainUrl']."\n\n";
		$message .= $_ARRAYLANG['TXT_CONTACT_DATE']." ".date(ASCMS_DATE_FORMAT, $arrFormData['meta']['time'])."\n\n";
		$message .= $body."\n\n";
		$message .= $_ARRAYLANG['TXT_CONTACT_HOSTNAME']." : ".$arrFormData['meta']['host']."\n";
		$message .= $_ARRAYLANG['TXT_CONTACT_IP_ADDRESS']." : ".$arrFormData['meta']['ipaddress']."\n";
		$message .= $_ARRAYLANG['TXT_CONTACT_BROWSER_LANGUAGE']." : ".$arrFormData['meta']['lang']."\n";
		$message .= $_ARRAYLANG['TXT_CONTACT_BROWSER_VERSION']." : ".$arrFormData['meta']['browser']."\n";

		foreach ($arrFormData['emails'] as $sendTo) {
			if (!empty($sendTo)) {
				@mail($sendTo, $arrFormData['subject'], $message, "From: ".$_CONFIG['coreAdminEmail']."\r\n"."Reply-To: ".$sendTo."\r\n"."X-Mailer: PHP/" . phpversion());
			}
		}
	}




	function _insertIntoDb($formId, $message, $time, $host, $lang, $browser, $ipaddress)
	{
		global $objDatabase;

		$objDatabase->Execute("INSERT INTO ".DBPREFIX."module_contact_form_data (`id_form`, `time`, `host`, `lang`, `browser`, `ipaddress`, `data`) VALUES (".$formId.", ".$time.", '".$host."', '".$lang."', '".$browser."', '".$ipaddress."', '".$message."')");
	}




	/**
	* Format a file name to be safe
	*
	* @param    string $file   The string file name
	* @param    int    $maxlen Maximun permited string lenght
	* @return   string Formatted file name
	*/
	function _cleanFileName($name, $maxlen=250){
	    $noalpha = '�������������������������������������������@';
	    $alpha =   'aeiouaeiouaeiouAEIOUAEIOUAEIOUaeiouAEIOUncCa';
	    $name = substr ($name, 0, $maxlen);
	    $name = strtr ($name, $noalpha, $alpha);
	    $mixChars = array('�' => 'th', '�' => 'th', '�' => 'dh', '�' => 'dh',
	                    '�' => 'ss', '�' => 'oe', '�' => 'oe', '�' => 'ae',
	                    '�' => 'ae', '$' => 's',  '�' => 'y');
	    $name = strtr($name, $mixChars);
	    // not permitted chars are replaced with "_"
	    return ereg_replace ('[^a-zA-Z0-9,._\+\()\-]', '_', $name);
	}




	function _uploadFiles($arrFields)
	{
		$arrSettings = $this->getSettings();

		$arrFiles = array();
		if (isset($_FILES) && is_array($_FILES)) {
			foreach (array_keys($_FILES) as $file) {
				$fileName = $this->_cleanFileName($_FILES[$file]['name']);
				$fileTmpName = $_FILES[$file]['tmp_name'];

				if (!empty($fileTmpName)) {
					$prefix = '';
					while (file_exists(ASCMS_DOCUMENT_ROOT.$arrSettings['fileUploadDepositionPath'].'/'.$prefix.$fileName)) {
						if (empty($prefix)) {
							$prefix = 0;
						}
						$prefix++;
					}

					if (preg_match('/.([a-zA-Z0-9_]{1,4})$/', $fileName, $arrMaches)) {
						if (in_array($arrMaches[1], $this->enabledUploadFileExtensions)) {
							if (move_uploaded_file($fileTmpName, ASCMS_DOCUMENT_ROOT.$arrSettings['fileUploadDepositionPath'].'/'.$prefix.$fileName)) {
								$id = intval(substr($file, 17));
								if (isset($arrFields[$id])) {
									$key = $arrFields[$id]['name'];
								} else {
									$key = contrexx_strip_tags($file);
								}
								$arrFiles[$key] = $arrSettings['fileUploadDepositionPath'].'/'.$prefix.$fileName;
							}
						}
					}
				}
			}
		}

		return $arrFiles;
	}

	/**
	 * Shows the thanks text
	 *
	 * @access private
	 */
	function _showFeedback($arrFormData)
	{
		$feedback = $arrFormData['feedback'];

		if (isset($arrFormData['fields'])) {
			foreach ($arrFormData['fields'] as $key => $field) {
				$name = $field['name'];
				$value = contrexx_strip_tags($_POST['contactFormField_'.$key]);

				$feedback = str_replace('[['.$name.']]', $value, $feedback);
			}
		}

		$this->objTemplate->setVariable(array(
			"CONTACT_FEEDBACK_TEXT"		=> nl2br(htmlentities(stripslashes($feedback)))."<br /><br />"
		));
	}

	/**
	 * Show Error
	 */
	function _showError()
	{
		global $_ARRAYLANG;

		$feedback =  "<span style=\"color: red\">";
		$feedback .= $_ARRAYLANG['TXT_FEEDBACK_ERROR'] . "</span>";

		$this->objTemplate->setVariable(array(
			"CONTACT_FEEDBACK_TEXT" => $feedback));
	}

	/**
	 * Checks the Values sent trough post
	 *
	 * Checks the Values sent trough post. Normally this is already done
	 * by Javascript, but it could be possible that the client doens't run
	 * JS, so this is done here again. Sadly, it is not possible to rewrite
	 * the posted values again
	 * @access private
	 */
	function _checkValues($arrFields)
	{
		$error = false;
		$arrSettings = $this->getSettings();
		$arrSpamKeywords = explode(',', $arrSettings['spamProtectionWordList']);
		$this->initCheckTypes();

		if (count($arrFields['fields']) > 0) {
			foreach ($arrFields['fields'] as $field) {
				$regex = "%".$this->arrCheckTypes[$field['check_type']]['regex'] ."%";
				if ($field['is_required'] && empty($arrFields['data'][$field['name']])) {
					$error = true;
				} elseif (empty($arrFields['data'][$field['name']])) {
					continue;
				} elseif(!preg_match($regex, $arrFields['data'][$field['name']])) {
					$error = true;
				} elseif ($this->_isSpam($arrFields['data'][$field['name']], $arrSpamKeywords)) {
					$error = true;
				}
			}
		}

		if ($error) {
			return false;
		} else {
			return true;
		}
	}

	/**
	* Checks a string for spam keywords
	*
	* @param string $string
	* @param array $arrKeywords
	* @return boolean true if spam was found
	*/
	function _isSpam($string, $arrKeywords)
	{
		foreach ($arrKeywords as $keyword) {
		    if (preg_match("%$keyword%i",$string)) {
		        return true;
		    }
		}
		return false;
	}
}
?>
