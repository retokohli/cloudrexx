<?php
/**
* Contrexx CMS
* generated date Wed,  2 Aug 2006 16:54:47 +0200
**/

$_ARRAYLANG['TXT_CONTACT_FORM'] = "New Webform contact entry at";
$_ARRAYLANG['TXT_CONTACT_TRANSFERED_DATA_FROM'] = "These are the informations transferred from the contact form of the website of ";
$_ARRAYLANG['TXT_CONTACT_DATE'] = "Date";
$_ARRAYLANG['TXT_CONTACT_HOSTNAME'] = "Hostname";
$_ARRAYLANG['TXT_CONTACT_IP_ADDRESS'] = "IP address";
$_ARRAYLANG['TXT_CONTACT_BROWSER_LANGUAGE'] = "Browser Language";
$_ARRAYLANG['TXT_CONTACT_BROWSER_VERSION'] = "Browser version ";
$_ARRAYLANG['TXT_CONTACT_UPLOADS'] = "Uploads";
$_ARRAYLANG['TXT_NEW_ENTRY_ERORR'] = "Please check your input!";
$_ARRAYLANG['TXT_FEEDBACK_ERROR'] = "Ein oder mehrere Fehler sind aufgetreten. Ben�zen Sie die \"Zur�ck\"-Schaltfl�che Ihres Browser um zur�ck zum Formular zu gelangen und �berpr�fen Sie ihre Angaben!";
?>