<?php
/**
* Contrexx CMS
* generated date Wed,  2 Aug 2006 16:54:47 +0200
**/

$_ARRAYLANG['TXT_CONTACT_TRANSFERED_DATA_FROM'] = "Ceci sont les informations transf�r�es depuis le formulaire de contact du site web";
$_ARRAYLANG['TXT_CONTACT_FORM'] = "Nouvelle entr�e dans le formulaire de contact sur";
$_ARRAYLANG['TXT_CONTACT_DATE'] = "Date";
$_ARRAYLANG['TXT_CONTACT_HOSTNAME'] = "Nom du h�te";
$_ARRAYLANG['TXT_CONTACT_IP_ADDRESS'] = "Adresse IP";
$_ARRAYLANG['TXT_CONTACT_BROWSER_LANGUAGE'] = "Langage du navigateur";
$_ARRAYLANG['TXT_CONTACT_BROWSER_VERSION'] = "Version du navigateur";
$_ARRAYLANG['TXT_CONTACT_UPLOADS'] = "Uploads";
$_ARRAYLANG['TXT_NEW_ENTRY_ERORR'] = "Veuillez v�rifier votre saisie!";
$_ARRAYLANG['TXT_FEEDBACK_ERROR'] = "Une ou plusieurs erreurs sont survenues. Utilisez la touche \"Retour arri�re\" de votre navigateur pour retourner au formulaire et v�rifiez vos saisies!";
?>