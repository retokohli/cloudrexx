<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Update from Version 1.0.8/1.0.9 to 1.0.9.4.1</title>
</head>
<body>
<?php
/**

	Plazieren Sie diese Datei in das Hauptverzeichniss Ihrer Contrexx Installation
	und klicken Sie anschliessend auf "Update starten".

*/
if (!@include_once('config/configuration.php')) {
	print "Plazieren Sie diese Datei in das Hauptverzeichniss Ihrer Contrexx Installation.";
} elseif (!@include_once(ASCMS_CORE_PATH.'/API.php')) {
	print "Die Datei ".ASCMS_CORE_PATH."/API.php fehlt oder kann nicht geladen werden!";
}

if (isset($_SYSCONFIG)) {
	foreach ($_SYSCONFIG as $sysconfigKey => $sysconfValue) {
		$_CONFIG[$sysconfigKey] = $sysconfValue;
	}
}

?>
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
<?php
	if (!isset($_POST['doUpdate'])) {
		print "<input type=\"submit\" name=\"doUpdate\" value=\"Update ausf�hren\" />";

	} else {
		$errorMsg = '';
		$objDatabase = getDatabaseObject($errorMsg);
		$objDatabase->debug=true;

		$objUpdate = &new Update();
		$objUpdate->doUpdate();
	}


class Update
{
	function doUpdate()
	{
		if ($this->_accessUpdate()) {
			print "Das Update wurde erfolgreich ausgef�hrt!";
		}
	}

	function _databaseError($query, $errorMsg)
	{
		print "Datenbank Fehler bei folgedem SQL Statement:<br />";
		print $query."<br /><br />";
		print "Detailierte Informationen:<br />";
		print $errorMsg."<br /><br />";
		print "Versuchen Sie das Update erneut auszuf�hren!<br />";

		return false;
	}

	function _accessUpdate()
	{
		global $objDatabase;

		$arrTables = $objDatabase->MetaTables('TABLES');
		if (!$arrTables) {
			print 'Die Struktur der Datenbank konnte nicht ermittelt werden!';
    		return false;
		}

		if (!in_array(DBPREFIX."access_rel_user_group", $arrTables)) {
			$query = "CREATE TABLE `".DBPREFIX."access_rel_user_group` (
				`user_id` int(10) unsigned NOT NULL,
				`group_id` int(10) unsigned NOT NULL,
				PRIMARY KEY  (`user_id`,`group_id`)
			) TYPE=MyISAM";
			if ($objDatabase->Execute($query) === false) {
				return $this->_databaseError($query, $objDatabase->ErrorMsg());
			}
		}

		if (!in_array(DBPREFIX."access_settings", $arrTables)) {
			$query = "CREATE TABLE `".DBPREFIX."access_settings` (
				`key` VARCHAR( 32 ) NOT NULL ,
				`value` VARCHAR( 255 ) NOT NULL ,
				`status` TINYINT( 1 ) UNSIGNED NOT NULL ,
				UNIQUE (
					`key`
				)
				) TYPE = MYISAM";
			if ($objDatabase->Execute($query) === false) {
				return $this->_databaseError($query, $objDatabase->ErrorMsg());
			}
		}

		if (!in_array(DBPREFIX."access_user_profile", $arrTables)) {
			$query = "CREATE TABLE `".DBPREFIX."access_user_profile` (
				`user_id` INT UNSIGNED NOT NULL ,
				`prefix` ENUM( '', 'm', 'f' ) NOT NULL ,
				`firstname` VARCHAR( 255 ) NOT NULL ,
				`lastname` VARCHAR( 255 ) NOT NULL ,
				`company` VARCHAR( 100 ) NOT NULL ,
				`address` TINYTEXT NOT NULL ,
				`city` VARCHAR( 50 ) NOT NULL ,
				`zip` VARCHAR( 10 ) NOT NULL ,
				`country_id` SMALLINT UNSIGNED NOT NULL DEFAULT '0',
				`phone_office` VARCHAR( 20 ) NOT NULL ,
				`phone_private` VARCHAR( 20 ) NOT NULL ,
				`phone_mobile` VARCHAR( 20 ) NOT NULL ,
				`phone_fax` VARCHAR( 20 ) NOT NULL ,
				`birthday` VARCHAR( 10 ) DEFAULT '00-00-0000' NOT NULL ,
				`website` VARCHAR( 255 ) NOT NULL ,
				`skype` VARCHAR( 32 ) NOT NULL ,
				`profession` VARCHAR( 150 ) NOT NULL ,
				`interests` VARCHAR( 255 ) NOT NULL ,
				`picture` VARCHAR( 255 ) NOT NULL ,
				PRIMARY KEY ( `user_id` ) ,
				FULLTEXT `fulltext` (
					`firstname` ,
					`lastname` ,
					`company` ,
					`address` ,
					`city` ,
					`zip` ,
					`phone_office` ,
					`phone_private` ,
					`phone_mobile` ,
					`phone_fax` ,
					`website` ,
					`profession` ,
					`interests`
				)
			) TYPE=MYISAM";
			if ($objDatabase->Execute($query) === false) {
				return $this->_databaseError($query, $objDatabase->ErrorMsg());
			}
		}

		if (!in_array(DBPREFIX."lib_country", $arrTables)) {
			$query = "CREATE TABLE `".DBPREFIX."lib_country` (
				`id` int(11) unsigned NOT NULL auto_increment,
				`name` varchar(64) NOT NULL,
				`iso_code_2` char(2) NOT NULL,
				`iso_code_3` char(3) NULL,
				PRIMARY KEY  (`id`),
				KEY `INDEX_COUNTRIES_NAME` (`name`)
				) TYPE=MyISAM";
			if ($objDatabase->Execute($query) === false) {
				return $this->_databaseError($query, $objDatabase->ErrorMsg());
			}
		}

		$arrCountries = array(
			1	=> array(
				'name'	=> 'Afghanistan',
				'iso_2'	=> 'AF',
				'iso_3'	=> 'AFG'
			),
			2	=> array(
				'name'	=> 'Albania',
				'iso_2'	=> 'AL',
				'iso_3'	=> 'ALB'
			),
			3	=> array(
				'name'	=> 'Algeria',
				'iso_2'	=> 'DZ',
				'iso_3'	=> 'DZA'
			),
			4	=> array(
				'name'	=> 'American Samoa',
				'iso_2'	=> 'AS',
				'iso_3'	=> 'ASM'
			),
			5	=> array(
				'name'	=> 'Andorra',
				'iso_2'	=> 'AD',
				'iso_3'	=> 'AND'
			),
			6	=> array(
				'name'	=> 'Angola',
				'iso_2'	=> 'AO',
				'iso_3'	=> 'AGO'
			),
			7	=> array(
				'name'	=> 'Anguilla',
				'iso_2'	=> 'AI',
				'iso_3'	=> 'AIA'
			),
			8	=> array(
				'name'	=> 'Antarctica',
				'iso_2'	=> 'AQ',
				'iso_3'	=> 'ATA'
			),
			9	=> array(
				'name'	=> 'Antigua and Barbuda',
				'iso_2'	=> 'AG',
				'iso_3'	=> 'ATG'
			),
			10	=> array(
				'name'	=> 'Argentina',
				'iso_2'	=> 'AR',
				'iso_3'	=> 'ARG'
			),
			11	=> array(
				'name'	=> 'Armenia',
				'iso_2'	=> 'AM',
				'iso_3'	=> 'ARM'
			),
			12	=> array(
				'name'	=> 'Aruba',
				'iso_2'	=> 'AW',
				'iso_3'	=> 'ABW'
			),
			13	=> array(
				'name'	=> 'Australia',
				'iso_2'	=> 'AU',
				'iso_3'	=> 'AUS'
			),
			14	=> array(
				'name'	=> '�sterreich',
				'iso_2'	=> 'AT',
				'iso_3'	=> 'AUT'
			),
			15	=> array(
				'name'	=> 'Azerbaijan',
				'iso_2'	=> 'AZ',
				'iso_3'	=> 'AZE'
			),
			16	=> array(
				'name'	=> 'Bahamas',
				'iso_2'	=> 'BS',
				'iso_3'	=> 'BHS'
			),
			17	=> array(
				'name'	=> 'Bahrain',
				'iso_2'	=> 'BH',
				'iso_3'	=> 'BHR'
			),
			18	=> array(
				'name'	=> 'Bangladesh',
				'iso_2'	=> 'BD',
				'iso_3'	=> 'BGD'
			),
			19	=> array(
				'name'	=> 'Barbados',
				'iso_2'	=> 'BB',
				'iso_3'	=> 'BRB'
			),
			20	=> array(
				'name'	=> 'Belarus',
				'iso_2'	=> 'BY',
				'iso_3'	=> 'BLR'
			),
			21	=> array(
				'name'	=> 'Belgium',
				'iso_2'	=> 'BE',
				'iso_3'	=> 'BEL'
			),
			22	=> array(
				'name'	=> 'Belize',
				'iso_2'	=> 'BZ',
				'iso_3'	=> 'BLZ'
			),
			23	=> array(
				'name'	=> 'Benin',
				'iso_2'	=> 'BJ',
				'iso_3'	=> 'BEN'
			),
			24	=> array(
				'name'	=> 'Bermuda',
				'iso_2'	=> 'BM',
				'iso_3'	=> 'BMU'
			),
			25	=> array(
				'name'	=> 'Bhutan',
				'iso_2'	=> 'BT',
				'iso_3'	=> 'BTN'
			),
			26	=> array(
				'name'	=> 'Bolivia',
				'iso_2'	=> 'BO',
				'iso_3'	=> 'BOL'
			),
			27	=> array(
				'name'	=> 'Bosnia and Herzegowina',
				'iso_2'	=> 'BA',
				'iso_3'	=> 'BIH'
			),
			28	=> array(
				'name'	=> 'Botswana',
				'iso_2'	=> 'BW',
				'iso_3'	=> 'BWA'
			),
			29	=> array(
				'name'	=> 'Bouvet Island',
				'iso_2'	=> 'BV',
				'iso_3'	=> 'BVT'
			),
			30	=> array(
				'name'	=> 'Brazil',
				'iso_2'	=> 'BR',
				'iso_3'	=> 'BRA'
			),
			31	=> array(
				'name'	=> 'British Indian Ocean Territory',
				'iso_2'	=> 'IO',
				'iso_3'	=> 'IOT'
			),
			32	=> array(
				'name'	=> 'Brunei Darussalam',
				'iso_2'	=> 'BN',
				'iso_3'	=> 'BRN'
			),
			33	=> array(
				'name'	=> 'Bulgaria',
				'iso_2'	=> 'BG',
				'iso_3'	=> 'BGR'
			),
			34	=> array(
				'name'	=> 'Burkina Faso',
				'iso_2'	=> 'BF',
				'iso_3'	=> 'BFA'
			),
			35	=> array(
				'name'	=> 'Burundi',
				'iso_2'	=> 'BI',
				'iso_3'	=> 'BDI'
			),
			36	=> array(
				'name'	=> 'Cambodia',
				'iso_2'	=> 'KH',
				'iso_3'	=> 'KHM'
			),
			37	=> array(
				'name'	=> 'Cameroon',
				'iso_2'	=> 'CM',
				'iso_3'	=> 'CMR'
			),
			38	=> array(
				'name'	=> 'Canada',
				'iso_2'	=> 'CA',
				'iso_3'	=> 'CAN'
			),
			39	=> array(
				'name'	=> 'Cape Verde',
				'iso_2'	=> 'CV',
				'iso_3'	=> 'CPV'
			),
			40	=> array(
				'name'	=> 'Cayman Islands',
				'iso_2'	=> 'KY',
				'iso_3'	=> 'CYM'
			),
			41	=> array(
				'name'	=> 'Central African Republic',
				'iso_2'	=> 'CF',
				'iso_3'	=> 'CAF'
			),
			42	=> array(
				'name'	=> 'Chad',
				'iso_2'	=> 'TD',
				'iso_3'	=> 'TCD'
			),
			43	=> array(
				'name'	=> 'Chile',
				'iso_2'	=> 'CL',
				'iso_3'	=> 'CHL'
			),
			44	=> array(
				'name'	=> 'China',
				'iso_2'	=> 'CN',
				'iso_3'	=> 'CHN'
			),
			45	=> array(
				'name'	=> 'Christmas Island',
				'iso_2'	=> 'CX',
				'iso_3'	=> 'CXR'
			),
			46	=> array(
				'name'	=> 'Cocos (Keeling) Islands',
				'iso_2'	=> 'CC',
				'iso_3'	=> 'CCK'
			),
			47	=> array(
				'name'	=> 'Colombia',
				'iso_2'	=> 'CO',
				'iso_3'	=> 'COL'
			),
			48	=> array(
				'name'	=> 'Comoros',
				'iso_2'	=> 'KM',
				'iso_3'	=> 'COM'
			),
			49	=> array(
				'name'	=> 'Congo',
				'iso_2'	=> 'CG',
				'iso_3'	=> 'COG'
			),
			50	=> array(
				'name'	=> 'Cook Islands',
				'iso_2'	=> 'CK',
				'iso_3'	=> 'COK'
			),
			51	=> array(
				'name'	=> 'Costa Rica',
				'iso_2'	=> 'CR',
				'iso_3'	=> 'CRI'
			),
			52	=> array(
				'name'	=> 'Cote D''Ivoire',
				'iso_2'	=> 'CI',
				'iso_3'	=> 'CIV'
			),
			53	=> array(
				'name'	=> 'Croatia',
				'iso_2'	=> 'HR',
				'iso_3'	=> 'HRV'
			),
			54	=> array(
				'name'	=> 'Cuba',
				'iso_2'	=> 'CU',
				'iso_3'	=> 'CUB'
			),
			55	=> array(
				'name'	=> 'Cyprus',
				'iso_2'	=> 'CY',
				'iso_3'	=> 'CYP'
			),
			56	=> array(
				'name'	=> 'Czech Republic',
				'iso_2'	=> 'CZ',
				'iso_3'	=> 'CZE'
			),
			57	=> array(
				'name'	=> 'Denmark',
				'iso_2'	=> 'DK',
				'iso_3'	=> 'DNK'
			),
			58	=> array(
				'name'	=> 'Djibouti',
				'iso_2'	=> 'DJ',
				'iso_3'	=> 'DJI'
			),
			59	=> array(
				'name'	=> 'Dominica',
				'iso_2'	=> 'DM',
				'iso_3'	=> 'DMA'
			),
			60	=> array(
				'name'	=> 'Dominican Republic',
				'iso_2'	=> 'DO',
				'iso_3'	=> 'DOM'
			),
			61	=> array(
				'name'	=> 'East Timor',
				'iso_2'	=> 'TP',
				'iso_3'	=> 'TMP'
			),
			62	=> array(
				'name'	=> 'Ecuador',
				'iso_2'	=> 'EC',
				'iso_3'	=> 'ECU'
			),
			63	=> array(
				'name'	=> 'Egypt',
				'iso_2'	=> 'EG',
				'iso_3'	=> 'EGY'
			),
			64	=> array(
				'name'	=> 'El Salvador',
				'iso_2'	=> 'SV',
				'iso_3'	=> 'SLV'
			),
			65	=> array(
				'name'	=> 'Equatorial Guinea',
				'iso_2'	=> 'GQ',
				'iso_3'	=> 'GNQ'
			),
			66	=> array(
				'name'	=> 'Eritrea',
				'iso_2'	=> 'ER',
				'iso_3'	=> 'ERI'
			),
			67	=> array(
				'name'	=> 'Estonia',
				'iso_2'	=> 'EE',
				'iso_3'	=> 'EST'
			),
			68	=> array(
				'name'	=> 'Ethiopia',
				'iso_2'	=> 'ET',
				'iso_3'	=> 'ETH'
			),
			69	=> array(
				'name'	=> 'Falkland Islands (Malvinas)',
				'iso_2'	=> 'FK',
				'iso_3'	=> 'FLK'
			),
			70	=> array(
				'name'	=> 'Faroe Islands',
				'iso_2'	=> 'FO',
				'iso_3'	=> 'FRO'
			),
			71	=> array(
				'name'	=> 'Fiji',
				'iso_2'	=> 'FJ',
				'iso_3'	=> 'FJI'
			),
			72	=> array(
				'name'	=> 'Finland',
				'iso_2'	=> 'FI',
				'iso_3'	=> 'FIN'
			),
			73	=> array(
				'name'	=> 'France',
				'iso_2'	=> 'FR',
				'iso_3'	=> 'FRA'
			),
			74	=> array(
				'name'	=> 'France, Metropolitan',
				'iso_2'	=> 'FX',
				'iso_3'	=> 'FXX'
			),
			75	=> array(
				'name'	=> 'French Guiana',
				'iso_2'	=> 'GF',
				'iso_3'	=> 'GUF'
			),
			76	=> array(
				'name'	=> 'French Polynesia',
				'iso_2'	=> 'PF',
				'iso_3'	=> 'PYF'
			),
			77	=> array(
				'name'	=> 'French Southern Territories',
				'iso_2'	=> 'TF',
				'iso_3'	=> 'ATF'
			),
			78	=> array(
				'name'	=> 'Gabon',
				'iso_2'	=> 'GA',
				'iso_3'	=> 'GAB'
			),
			79	=> array(
				'name'	=> 'Gambia',
				'iso_2'	=> 'GM',
				'iso_3'	=> 'GMB'
			),
			80	=> array(
				'name'	=> 'Georgia',
				'iso_2'	=> 'GE',
				'iso_3'	=> 'GEO'
			),
			81	=> array(
				'name'	=> 'Deutschland',
				'iso_2'	=> 'DE',
				'iso_3'	=> 'DEU'
			),
			82	=> array(
				'name'	=> 'Ghana',
				'iso_2'	=> 'GH',
				'iso_3'	=> 'GHA'
			),
			83	=> array(
				'name'	=> 'Gibraltar',
				'iso_2'	=> 'GI',
				'iso_3'	=> 'GIB'
			),
			84	=> array(
				'name'	=> 'Greece',
				'iso_2'	=> 'GR',
				'iso_3'	=> 'GRC'
			),
			85	=> array(
				'name'	=> 'Greenland',
				'iso_2'	=> 'GL',
				'iso_3'	=> 'GRL'
			),
			86	=> array(
				'name'	=> 'Grenada',
				'iso_2'	=> 'GD',
				'iso_3'	=> 'GRD'
			),
			87	=> array(
				'name'	=> 'Guadeloupe',
				'iso_2'	=> 'GP',
				'iso_3'	=> 'GLP'
			),
			88	=> array(
				'name'	=> 'Guam',
				'iso_2'	=> 'GU',
				'iso_3'	=> 'GUM'
			),
			89	=> array(
				'name'	=> 'Guatemala',
				'iso_2'	=> 'GT',
				'iso_3'	=> 'GTM'
			),
			90	=> array(
				'name'	=> 'Guinea',
				'iso_2'	=> 'GN',
				'iso_3'	=> 'GIN'
			),
			91	=> array(
				'name'	=> 'Guinea-bissau',
				'iso_2'	=> 'GW',
				'iso_3'	=> 'GNB'
			),
			92	=> array(
				'name'	=> 'Guyana',
				'iso_2'	=> 'GY',
				'iso_3'	=> 'GUY'
			),
			93	=> array(
				'name'	=> 'Haiti',
				'iso_2'	=> 'HT',
				'iso_3'	=> 'HTI'
			),
			94	=> array(
				'name'	=> 'Heard and Mc Donald Islands',
				'iso_2'	=> 'HM',
				'iso_3'	=> 'HMD'
			),
			95	=> array(
				'name'	=> 'Honduras',
				'iso_2'	=> 'HN',
				'iso_3'	=> 'HND'
			),
			96	=> array(
				'name'	=> 'Hong Kong',
				'iso_2'	=> 'HK',
				'iso_3'	=> 'HKG'
			),
			97	=> array(
				'name'	=> 'Hungary',
				'iso_2'	=> 'HU',
				'iso_3'	=> 'HUN'
			),
			98	=> array(
				'name'	=> 'Iceland',
				'iso_2'	=> 'IS',
				'iso_3'	=> 'ISL'
			),
			99	=> array(
				'name'	=> 'India',
				'iso_2'	=> 'IN',
				'iso_3'	=> 'IND'
			),
			100	=> array(
				'name'	=> 'Indonesia',
				'iso_2'	=> 'ID',
				'iso_3'	=> 'IDN'
			),
			101	=> array(
				'name'	=> 'Iran (Islamic Republic of)',
				'iso_2'	=> 'IR',
				'iso_3'	=> 'IRN'
			),
			102	=> array(
				'name'	=> 'Iraq',
				'iso_2'	=> 'IQ',
				'iso_3'	=> 'IRQ'
			),
			103	=> array(
				'name'	=> 'Ireland',
				'iso_2'	=> 'IE',
				'iso_3'	=> 'IRL'
			),
			104	=> array(
				'name'	=> 'Israel',
				'iso_2'	=> 'IL',
				'iso_3'	=> 'ISR'
			),
			105	=> array(
				'name'	=> 'Italy',
				'iso_2'	=> 'IT',
				'iso_3'	=> 'ITA'
			),
			106	=> array(
				'name'	=> 'Jamaica',
				'iso_2'	=> 'JM',
				'iso_3'	=> 'JAM'
			),
			107	=> array(
				'name'	=> 'Japan',
				'iso_2'	=> 'JP',
				'iso_3'	=> 'JPN'
			),
			108	=> array(
				'name'	=> 'Jordan',
				'iso_2'	=> 'JO',
				'iso_3'	=> 'JOR'
			),
			109	=> array(
				'name'	=> 'Kazakhstan',
				'iso_2'	=> 'KZ',
				'iso_3'	=> 'KAZ'
			),
			110	=> array(
				'name'	=> 'Kenya',
				'iso_2'	=> 'KE',
				'iso_3'	=> 'KEN'
			),
			111	=> array(
				'name'	=> 'Kiribati',
				'iso_2'	=> 'KI',
				'iso_3'	=> 'KIR'
			),
			112	=> array(
				'name'	=> 'Korea, Democratic People''s Republic of',
				'iso_2'	=> 'KP',
				'iso_3'	=> 'PRK'
			),
			113	=> array(
				'name'	=> 'Korea, Republic of',
				'iso_2'	=> 'KR',
				'iso_3'	=> 'KOR'
			),
			114	=> array(
				'name'	=> 'Kuwait',
				'iso_2'	=> 'KW',
				'iso_3'	=> 'KWT'
			),
			115	=> array(
				'name'	=> 'Kyrgyzstan',
				'iso_2'	=> 'KG',
				'iso_3'	=> 'KGZ'
			),
			116	=> array(
				'name'	=> 'Lao People''s Democratic Republic',
				'iso_2'	=> 'LA',
				'iso_3'	=> 'LAO'
			),
			117	=> array(
				'name'	=> 'Latvia',
				'iso_2'	=> 'LV',
				'iso_3'	=> 'LVA'
			),
			118	=> array(
				'name'	=> 'Lebanon',
				'iso_2'	=> 'LB',
				'iso_3'	=> 'LBN'
			),
			119	=> array(
				'name'	=> 'Lesotho',
				'iso_2'	=> 'LS',
				'iso_3'	=> 'LSO'
			),
			120	=> array(
				'name'	=> 'Liberia',
				'iso_2'	=> 'LR',
				'iso_3'	=> 'LBR'
			),
			121	=> array(
				'name'	=> 'Libyan Arab Jamahiriya',
				'iso_2'	=> 'LY',
				'iso_3'	=> 'LBY'
			),
			122	=> array(
				'name'	=> 'Liechtenstein',
				'iso_2'	=> 'LI',
				'iso_3'	=> 'LIE'
			),
			123	=> array(
				'name'	=> 'Lithuania',
				'iso_2'	=> 'LT',
				'iso_3'	=> 'LTU'
			),
			124	=> array(
				'name'	=> 'Luxembourg',
				'iso_2'	=> 'LU',
				'iso_3'	=> 'LUX'
			),
			125	=> array(
				'name'	=> 'Macau',
				'iso_2'	=> 'MO',
				'iso_3'	=> 'MAC'
			),
			126	=> array(
				'name'	=> 'Macedonia, The Former Yugoslav Republic of',
				'iso_2'	=> 'MK',
				'iso_3'	=> 'MKD'
			),
			127	=> array(
				'name'	=> 'Madagascar',
				'iso_2'	=> 'MG',
				'iso_3'	=> 'MDG'
			),
			128	=> array(
				'name'	=> 'Malawi',
				'iso_2'	=> 'MW',
				'iso_3'	=> 'MWI'
			),
			129	=> array(
				'name'	=> 'Malaysia',
				'iso_2'	=> 'MY',
				'iso_3'	=> 'MYS'
			),
			130	=> array(
				'name'	=> 'Maldives',
				'iso_2'	=> 'MV',
				'iso_3'	=> 'MDV'
			),
			131	=> array(
				'name'	=> 'Mali',
				'iso_2'	=> 'ML',
				'iso_3'	=> 'MLI'
			),
			132	=> array(
				'name'	=> 'Malta',
				'iso_2'	=> 'MT',
				'iso_3'	=> 'MLT'
			),
			133	=> array(
				'name'	=> 'Marshall Islands',
				'iso_2'	=> 'MH',
				'iso_3'	=> 'MHL'
			),
			134	=> array(
				'name'	=> 'Martinique',
				'iso_2'	=> 'MQ',
				'iso_3'	=> 'MTQ'
			),
			135	=> array(
				'name'	=> 'Mauritania',
				'iso_2'	=> 'MR',
				'iso_3'	=> 'MRT'
			),
			136	=> array(
				'name'	=> 'Mauritius',
				'iso_2'	=> 'MU',
				'iso_3'	=> 'MUS'
			),
			137	=> array(
				'name'	=> 'Mayotte',
				'iso_2'	=> 'YT',
				'iso_3'	=> 'MYT'
			),
			138	=> array(
				'name'	=> 'Mexico',
				'iso_2'	=> 'MX',
				'iso_3'	=> 'MEX'
			),
			139	=> array(
				'name'	=> 'Micronesia, Federated States of',
				'iso_2'	=> 'FM',
				'iso_3'	=> 'FSM'
			),
			140	=> array(
				'name'	=> 'Moldova, Republic of',
				'iso_2'	=> 'MD',
				'iso_3'	=> 'MDA'
			),
			141	=> array(
				'name'	=> 'Monaco',
				'iso_2'	=> 'MC',
				'iso_3'	=> 'MCO'
			),
			142	=> array(
				'name'	=> 'Mongolia',
				'iso_2'	=> 'MN',
				'iso_3'	=> 'MNG'
			),
			143	=> array(
				'name'	=> 'Montserrat',
				'iso_2'	=> 'MS',
				'iso_3'	=> 'MSR'
			),
			144	=> array(
				'name'	=> 'Morocco',
				'iso_2'	=> 'MA',
				'iso_3'	=> 'MAR'
			),
			145	=> array(
				'name'	=> 'Mozambique',
				'iso_2'	=> 'MZ',
				'iso_3'	=> 'MOZ'
			),
			146	=> array(
				'name'	=> 'Myanmar',
				'iso_2'	=> 'MM',
				'iso_3'	=> 'MMR'
			),
			147	=> array(
				'name'	=> 'Namibia',
				'iso_2'	=> 'NA',
				'iso_3'	=> 'NAM'
			),
			148	=> array(
				'name'	=> 'Nauru',
				'iso_2'	=> 'NR',
				'iso_3'	=> 'NRU'
			),
			149	=> array(
				'name'	=> 'Nepal',
				'iso_2'	=> 'NP',
				'iso_3'	=> 'NPL'
			),
			150	=> array(
				'name'	=> 'Netherlands',
				'iso_2'	=> 'NL',
				'iso_3'	=> 'NLD'
			),
			151	=> array(
				'name'	=> 'Netherlands Antilles',
				'iso_2'	=> 'AN',
				'iso_3'	=> 'ANT'
			),
			152	=> array(
				'name'	=> 'New Caledonia',
				'iso_2'	=> 'NC',
				'iso_3'	=> 'NCL'
			),
			153	=> array(
				'name'	=> 'New Zealand',
				'iso_2'	=> 'NZ',
				'iso_3'	=> 'NZL'
			),
			154	=> array(
				'name'	=> 'Nicaragua',
				'iso_2'	=> 'NI',
				'iso_3'	=> 'NIC'
			),
			155	=> array(
				'name'	=> 'Niger',
				'iso_2'	=> 'NE',
				'iso_3'	=> 'NER'
			),
			156	=> array(
				'name'	=> 'Nigeria',
				'iso_2'	=> 'NG',
				'iso_3'	=> 'NGA'
			),
			157	=> array(
				'name'	=> 'Niue',
				'iso_2'	=> 'NU',
				'iso_3'	=> 'NIU'
			),
			158	=> array(
				'name'	=> 'Norfolk Island',
				'iso_2'	=> 'NF',
				'iso_3'	=> 'NFK'
			),
			159	=> array(
				'name'	=> 'Northern Mariana Islands',
				'iso_2'	=> 'MP',
				'iso_3'	=> 'MNP'
			),
			160	=> array(
				'name'	=> 'Norway',
				'iso_2'	=> 'NO',
				'iso_3'	=> 'NOR'
			),
			161	=> array(
				'name'	=> 'Oman',
				'iso_2'	=> 'OM',
				'iso_3'	=> 'OMN'
			),
			162	=> array(
				'name'	=> 'Pakistan',
				'iso_2'	=> 'PK',
				'iso_3'	=> 'PAK'
			),
			163	=> array(
				'name'	=> 'Palau',
				'iso_2'	=> 'PW',
				'iso_3'	=> 'PLW'
			),
			164	=> array(
				'name'	=> 'Panama',
				'iso_2'	=> 'PA',
				'iso_3'	=> 'PAN'
			),
			165	=> array(
				'name'	=> 'Papua New Guinea',
				'iso_2'	=> 'PG',
				'iso_3'	=> 'PNG'
			),
			166	=> array(
				'name'	=> 'Paraguay',
				'iso_2'	=> 'PY',
				'iso_3'	=> 'PRY'
			),
			167	=> array(
				'name'	=> 'Peru',
				'iso_2'	=> 'PE',
				'iso_3'	=> 'PER'
			),
			168	=> array(
				'name'	=> 'Philippines',
				'iso_2'	=> 'PH',
				'iso_3'	=> 'PHL'
			),
			169	=> array(
				'name'	=> 'Pitcairn',
				'iso_2'	=> 'PN',
				'iso_3'	=> 'PCN'
			),
			170	=> array(
				'name'	=> 'Poland',
				'iso_2'	=> 'PL',
				'iso_3'	=> 'POL'
			),
			171	=> array(
				'name'	=> 'Portugal',
				'iso_2'	=> 'PT',
				'iso_3'	=> 'PRT'
			),
			172	=> array(
				'name'	=> 'Puerto Rico',
				'iso_2'	=> 'PR',
				'iso_3'	=> 'PRI'
			),
			173	=> array(
				'name'	=> 'Qatar',
				'iso_2'	=> 'QA',
				'iso_3'	=> 'QAT'
			),
			174	=> array(
				'name'	=> 'Reunion',
				'iso_2'	=> 'RE',
				'iso_3'	=> 'REU'
			),
			175	=> array(
				'name'	=> 'Romania',
				'iso_2'	=> 'RO',
				'iso_3'	=> 'ROM'
			),
			176	=> array(
				'name'	=> 'Russian Federation',
				'iso_2'	=> 'RU',
				'iso_3'	=> 'RUS'
			),
			177	=> array(
				'name'	=> 'Rwanda',
				'iso_2'	=> 'RW',
				'iso_3'	=> 'RWA'
			),
			178	=> array(
				'name'	=> 'Saint Kitts and Nevis',
				'iso_2'	=> 'KN',
				'iso_3'	=> 'KNA'
			),
			179	=> array(
				'name'	=> 'Saint Lucia',
				'iso_2'	=> 'LC',
				'iso_3'	=> 'LCA'
			),
			180	=> array(
				'name'	=> 'Saint Vincent and the Grenadines',
				'iso_2'	=> 'VC',
				'iso_3'	=> 'VCT'
			),
			181	=> array(
				'name'	=> 'Samoa',
				'iso_2'	=> 'WS',
				'iso_3'	=> 'WSM'
			),
			182	=> array(
				'name'	=> 'San Marino',
				'iso_2'	=> 'SM',
				'iso_3'	=> 'SMR'
			),
			183	=> array(
				'name'	=> 'Sao Tome and Principe',
				'iso_2'	=> 'ST',
				'iso_3'	=> 'STP'
			),
			184	=> array(
				'name'	=> 'Saudi Arabia',
				'iso_2'	=> 'SA',
				'iso_3'	=> 'SAU'
			),
			185	=> array(
				'name'	=> 'Senegal',
				'iso_2'	=> 'SN',
				'iso_3'	=> 'SEN'
			),
			186	=> array(
				'name'	=> 'Seychelles',
				'iso_2'	=> 'SC',
				'iso_3'	=> 'SYC'
			),
			187	=> array(
				'name'	=> 'Sierra Leone',
				'iso_2'	=> 'SL',
				'iso_3'	=> 'SLE'
			),
			188	=> array(
				'name'	=> 'Singapore',
				'iso_2'	=> 'SG',
				'iso_3'	=> 'SGP'
			),
			189	=> array(
				'name'	=> 'Slovakia (Slovak Republic)',
				'iso_2'	=> 'SK',
				'iso_3'	=> 'SVK'
			),
			190	=> array(
				'name'	=> 'Slovenia',
				'iso_2'	=> 'SI',
				'iso_3'	=> 'SVN'
			),
			191	=> array(
				'name'	=> 'Solomon Islands',
				'iso_2'	=> 'SB',
				'iso_3'	=> 'SLB'
			),
			192	=> array(
				'name'	=> 'Somalia',
				'iso_2'	=> 'SO',
				'iso_3'	=> 'SOM'
			),
			193	=> array(
				'name'	=> 'South Africa',
				'iso_2'	=> 'ZA',
				'iso_3'	=> 'ZAF'
			),
			194	=> array(
				'name'	=> 'South Georgia and the South Sandwich Islands',
				'iso_2'	=> 'GS',
				'iso_3'	=> 'SGS'
			),
			195	=> array(
				'name'	=> 'Spain',
				'iso_2'	=> 'ES',
				'iso_3'	=> 'ESP'
			),
			196	=> array(
				'name'	=> 'Sri Lanka',
				'iso_2'	=> 'LK',
				'iso_3'	=> 'LKA'
			),
			197	=> array(
				'name'	=> 'St. Helena',
				'iso_2'	=> 'SH',
				'iso_3'	=> 'SHN'
			),
			198	=> array(
				'name'	=> 'St. Pierre and Miquelon',
				'iso_2'	=> 'PM',
				'iso_3'	=> 'SPM'
			),
			199	=> array(
				'name'	=> 'Sudan',
				'iso_2'	=> 'SD',
				'iso_3'	=> 'SDN'
			),
			200	=> array(
				'name'	=> 'Suriname',
				'iso_2'	=> 'SR',
				'iso_3'	=> 'SUR'
			),
			201	=> array(
				'name'	=> 'Svalbard and Jan Mayen Islands',
				'iso_2'	=> 'SJ',
				'iso_3'	=> 'SJM'
			),
			202	=> array(
				'name'	=> 'Swaziland',
				'iso_2'	=> 'SZ',
				'iso_3'	=> 'SWZ'
			),
			203	=> array(
				'name'	=> 'Sweden',
				'iso_2'	=> 'SE',
				'iso_3'	=> 'SWE'
			),
			204	=> array(
				'name'	=> 'Schweiz',
				'iso_2'	=> 'CH',
				'iso_3'	=> 'CHE'
			),
			205	=> array(
				'name'	=> 'Syrian Arab Republic',
				'iso_2'	=> 'SY',
				'iso_3'	=> 'SYR'
			),
			206	=> array(
				'name'	=> 'Taiwan',
				'iso_2'	=> 'TW',
				'iso_3'	=> 'TWN'
			),
			207	=> array(
				'name'	=> 'Tajikistan',
				'iso_2'	=> 'TJ',
				'iso_3'	=> 'TJK'
			),
			208	=> array(
				'name'	=> 'Tanzania, United Republic of',
				'iso_2'	=> 'TZ',
				'iso_3'	=> 'TZA'
			),
			209	=> array(
				'name'	=> 'Thailand',
				'iso_2'	=> 'TH',
				'iso_3'	=> 'THA'
			),
			210	=> array(
				'name'	=> 'Togo',
				'iso_2'	=> 'TG',
				'iso_3'	=> 'TGO'
			),
			211	=> array(
				'name'	=> 'Tokelau',
				'iso_2'	=> 'TK',
				'iso_3'	=> 'TKL'
			),
			212	=> array(
				'name'	=> 'Tonga',
				'iso_2'	=> 'TO',
				'iso_3'	=> 'TON'
			),
			213	=> array(
				'name'	=> 'Trinidad and Tobago',
				'iso_2'	=> 'TT',
				'iso_3'	=> 'TTO'
			),
			214	=> array(
				'name'	=> 'Tunisia',
				'iso_2'	=> 'TN',
				'iso_3'	=> 'TUN'
			),
			215	=> array(
				'name'	=> 'Turkey',
				'iso_2'	=> 'TR',
				'iso_3'	=> 'TUR'
			),
			216	=> array(
				'name'	=> 'Turkmenistan',
				'iso_2'	=> 'TM',
				'iso_3'	=> 'TKM'
			),
			217	=> array(
				'name'	=> 'Turks and Caicos Islands',
				'iso_2'	=> 'TC',
				'iso_3'	=> 'TCA'
			),
			218	=> array(
				'name'	=> 'Tuvalu',
				'iso_2'	=> 'TV',
				'iso_3'	=> 'TUV'
			),
			219	=> array(
				'name'	=> 'Uganda',
				'iso_2'	=> 'UG',
				'iso_3'	=> 'UGA'
			),
			220	=> array(
				'name'	=> 'Ukraine',
				'iso_2'	=> 'UA',
				'iso_3'	=> 'UKR'
			),
			221	=> array(
				'name'	=> 'United Arab Emirates',
				'iso_2'	=> 'AE',
				'iso_3'	=> 'ARE'
			),
			222	=> array(
				'name'	=> 'United Kingdom',
				'iso_2'	=> 'GB',
				'iso_3'	=> 'GBR'
			),
			223	=> array(
				'name'	=> 'United States',
				'iso_2'	=> 'US',
				'iso_3'	=> 'USA'
			),
			224	=> array(
				'name'	=> 'United States Minor Outlying Islands',
				'iso_2'	=> 'UM',
				'iso_3'	=> 'UMI'
			),
			225	=> array(
				'name'	=> 'Uruguay',
				'iso_2'	=> 'UY',
				'iso_3'	=> 'URY'
			),
			226	=> array(
				'name'	=> 'Uzbekistan',
				'iso_2'	=> 'UZ',
				'iso_3'	=> 'UZB'
			),
			227	=> array(
				'name'	=> 'Vanuatu',
				'iso_2'	=> 'VU',
				'iso_3'	=> 'VUT'
			),
			228	=> array(
				'name'	=> 'Vatican City State (Holy See)',
				'iso_2'	=> 'VA',
				'iso_3'	=> 'VAT'
			),
			229	=> array(
				'name'	=> 'Venezuela',
				'iso_2'	=> 'VE',
				'iso_3'	=> 'VEN'
			),
			230	=> array(
				'name'	=> 'Viet Nam',
				'iso_2'	=> 'VN',
				'iso_3'	=> 'VNM'
			),
			231	=> array(
				'name'	=> 'Virgin Islands (British)',
				'iso_2'	=> 'VG',
				'iso_3'	=> 'VGB'
			),
			232	=> array(
				'name'	=> 'Virgin Islands (U.S.)',
				'iso_2'	=> 'VI',
				'iso_3'	=> 'VIR'
			),
			233	=> array(
				'name'	=> 'Wallis and Futuna Islands',
				'iso_2'	=> 'WF',
				'iso_3'	=> 'WLF'
			),
			234	=> array(
				'name'	=> 'Western Sahara',
				'iso_2'	=> 'EH',
				'iso_3'	=> 'ESH'
			),
			235	=> array(
				'name'	=> 'Yemen',
				'iso_2'	=> 'YE',
				'iso_3'	=> 'YEM'
			),
			236	=> array(
				'name'	=> 'Yugoslavia',
				'iso_2'	=> 'YU',
				'iso_3'	=> 'YUG'
			),
			237	=> array(
				'name'	=> 'Zaire',
				'iso_2'	=> 'ZR',
				'iso_3'	=> 'ZAR'
			),
			238	=> array(
				'name'	=> 'Zambia',
				'iso_2'	=> 'ZM',
				'iso_3'	=> 'ZMB'
			),
			239	=> array(
				'name'	=> 'Zimbabwe',
				'iso_2'	=> 'ZW',
				'iso_3'	=> 'ZWE'
			)
		);

		foreach ($arrCountries as $countryId => $arrCountry) {
			$query = "SELECT 1 FROM `".DBPREFIX."lib_country` WHERE `id` = ".$countryId;
			$objResult = $objDatabase->SelectLimit($query, 1);
			if ($objResult) {
				if ($objResult->RecordCount() == 0) {
					$query = "INSERT INTO `".DBPREFIX."lib_country` VALUES (".$countryId.", '".$arrCountry['name']."', '".$arrCountry['iso_2']."', '".$arrCountry['iso_3']."')";
					if ($objDatabase->Execute($query) === false) {
						return $this->_databaseError($query, $objDatabase->ErrorMsg());
					}
				}
			} else {
				return $this->_databaseError($query, $objDatabase->ErrorMsg());
			}
		}

		$arrColumns = $objDatabase->MetaColumnNames(DBPREFIX."access_users");
    	if (!is_array($arrColumns)) {
    		print "Die Struktur der Datenbanktabelle ".DBPREFIX."access_users konnte nicht ermittelt werden!";
    		return false;
    	}

    	if (in_array('groups', $arrColumns)) {
    		$query = "SELECT `id`, `groups` FROM ".DBPREFIX."access_users WHERE `groups` != ''";
    		$objUser = $objDatabase->Execute($query);
    		if ($objUser) {
    			while (!$objUser->EOF) {
    				$arrGroups = explode(',', $objUser->fields['groups']);
    				foreach ($arrGroups as $groupId) {
    					$query = "SELECT 1 FROM ".DBPREFIX."access_rel_user_group WHERE `user_id` = ".$objUser->fields['id']." AND `group_id` = ".intval($groupId);
    					$objRel = $objDatabase->SelectLimit($query, 1);
    					if ($objRel) {
    						if ($objRel->RecordCount() == 0) {
    							$query = "INSERT INTO ".DBPREFIX."access_rel_user_group (`user_id`, `group_id`) VALUES (".$objUser->fields['id'].", ".intval($groupId).")";
    							if ($objDatabase->Execute($query) === false) {
    								return $this->_databaseError($query, $objDatabase->ErrorMsg());
    							}
    						}
    					} else {
    						return $this->_databaseError($query, $objDatabase->ErrorMsg());
    					}
    				}

    				$objUser->MoveNext();
    			}
    		} else {
    			return $this->_databaseError($query, $objDatabase->ErrorMsg());
    		}

    		$query = "ALTER TABLE ".DBPREFIX."access_users DROP `groups`";
    		if ($objDatabase->Execute($query) === false) {
    			return $this->_databaseError($query, $objDatabase->ErrorMsg());
    		}
    	}

    	if (in_array('firstname', $arrColumns)) {
    		$query = "SELECT `id`, `firstname`, `lastname`, `residence`, `profession`, `interests`, `webpage`, `company`, `zip`, `phone`, `mobile`, `street` FROM ".DBPREFIX."access_users";
    		$objUser = $objDatabase->Execute($query);
    		if ($objUser) {
    			while (!$objUser->EOF) {
    				$query = "SELECT 1 FROM ".DBPREFIX."access_user_profile WHERE `user_id` = ".$objUser->fields['id'];
    				$objProfile = $objDatabase->SelectLimit($query, 1);
    				if ($objProfile) {
    					if ($objProfile->RecordCount() == 0) {
    						$query = "INSERT INTO ".DBPREFIX."access_user_profile (
								`user_id`,
								`prefix`,
								`firstname`,
								`lastname`,
								`company`,
								`address`,
								`city`,
								`zip`,
								`country_id`,
								`phone_office`,
								`phone_private`,
								`phone_mobile`,
								`phone_fax`,
								`website`,
								`profession`,
								`interests`,
								`picture`
							) VALUES (
								".$objUser->fields['id'].",
								'',
								'".addslashes($objUser->fields['firstname'])."',
								'".addslashes($objUser->fields['lastname'])."',
								'".addslashes($objUser->fields['company'])."',
								'".addslashes($objUser->fields['street'])."',
								'".addslashes($objUser->fields['residence'])."',
								'".addslashes($objUser->fields['zip'])."',
								0,
								'',
								'".addslashes($objUser->fields['phone'])."',
								'".addslashes($objUser->fields['mobile'])."',
								'',
								'".addslashes($objUser->fields['webpage'])."',
								'".addslashes($objUser->fields['profession'])."',
								'".addslashes($objUser->fields['interests'])."',
								''
							)";
    						if ($objDatabase->Execute($query) === false) {
    							return $this->_databaseError($query, $objDatabase->ErrorMsg());
    						}
    					}
    				} else {
    					return $this->_databaseError($query, $objDatabase->ErrorMsg());
    				}

    				$objUser->MoveNext();
    			}
    		} else {
    			return $this->_databaseError($query, $objDatabase->ErrorMsg());
    		}

    		$arrRemoveColumns = array(
    			'firstname',
    			'lastname',
    			'residence',
    			'profession',
    			'interests',
    			'webpage',
    			'company',
    			'zip',
    			'phone',
    			'mobile',
    			'street',
    			'levelid'
   			);

   			foreach ($arrRemoveColumns as $column) {
   				if (in_array($column, $arrColumns)) {
   					$query = "ALTER TABLE ".DBPREFIX."access_users DROP `".$column."`";
   					if ($objDatabase->Execute($query) === false) {
   						return $this->_databaseError($query, $objDatabase->ErrorMsg());
   					}
   				}
   			}

   			$arrColumnDetails = $objDatabase->MetaColumns(DBPREFIX.'access_users');
	    	if ($arrColumnDetails === false) {
	    		print "Die Struktur der Datenbanktabelle ".DBPREFIX."access_users konnte nicht ermittelt werden!";
	    		return false;
	    	}

	    	if (in_array('regdate', $arrColumns)) {
		    	if ($arrColumnDetails['REGDATE']->type == 'date') {
		    		if (!in_array('regdate_new', $arrColumns)) {
		    			$query = "ALTER TABLE `".DBPREFIX."access_users` ADD `regdate_new` INT( 14 ) UNSIGNED NULL DEFAULT '0' AFTER `regdate`";
		    			if ($objDatabase->Execute($query) === false) {
		    				return $this->_databaseError($query, $objDatabase->ErrorMsg());
		    			}
		    		}

		    		$query = "SELECT `id`, `regdate` FROM `".DBPREFIX."access_users` WHERE `regdate` != '0000-00-00'";
		    		$objResult = $objDatabase->Execute($query);
		    		if ($objResult) {
		    			while (!$objResult->EOF) {
		    				if (preg_match_all('/([0-9]+)/', '2001-0-04', $arrDateParts)) {
		    					$regDate = mktime(1,0,0, $arrDateParts[0][1], $arrDateParts[0][2], $arrDateParts[0][0]);
		    					$query = "UPDATE `".DBPREFIX."access_users` SET `regdate_new` = ".$regDate." WHERE `id` = ".$objResult->fields['id'];
		    					if ($objDatabase->Execute($query) === false) {
		    						return $this->_databaseError($query, $objDatabase->ErrorMsg());
		    					}

		    					$query = "UPDATE `".DBPREFIX."access_users` SET `regdate` = '0000-00-00' WHERE `id` = ".$objResult->fields['id'];
		    					if ($objDatabase->Execute($query) === false) {
		    						return $this->_databaseError($query, $objDatabase->ErrorMsg());
		    					}
		    				}
		    				$objResult->MoveNext();
		    			}
		    		} else {
		    			return $this->_databaseError($query, $objDatabase->ErrorMsg());
		    		}

		    		$query = "ALTER TABLE `".DBPREFIX."access_users` DROP `regdate`";
		    		if ($objDatabase->Execute($query) === false) {
		    			return $this->_databaseError($query, $objDatabase->ErrorMsg());
		    		}
		    	}
	    	}

	    	$arrColumns = $objDatabase->MetaColumnNames(DBPREFIX.'access_users');
	    	if ($arrColumns === false) {
	    		print "Die Struktur der Datenbanktabelle ".DBPREFIX."access_users konnte nicht ermittelt werden!";
	    		return false;
	    	}

	    	if (in_array('regdate_new', $arrColumns)) {
	    		$query = "ALTER TABLE `".DBPREFIX."access_users` CHANGE `regdate_new` `regdate` INT( 14 ) UNSIGNED NULL DEFAULT '0'";
	    		if ($objDatabase->Execute($query) === false) {
	    			return $this->_databaseError($query, $objDatabase->ErrorMsg());
	    		}
	    	}

	    	$query = "ALTER TABLE `".DBPREFIX."access_users` CHANGE `is_admin` `is_admin` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '0'";
	    	if ($objDatabase->Execute($query) === false) {
	    		return $this->_databaseError($query, $objDatabase->ErrorMsg());
	    	}

   			$arrContentTables = array(
   				DBPREFIX."content",
   				DBPREFIX."content_history"
   			);

   			foreach ($arrContentTables as $dbTable) {
	   			$query = "SELECT `id`, `content`, `redirect` FROM ".$dbTable." WHERE `content` LIKE '%section=community%' OR `content` LIKE '%section=login%' OR `redirect` LIKE '%section=community%' OR `redirect` LIKE '%section=login%'";
	   			$objContent = $objDatabase->Execute($query);
	   			if ($objContent) {
	   				while (!$objContent->EOF) {
	   					$content = str_replace(
	   						array('section=community', 'section=login'),
	   						array('section=access', 'section=access'),
	   						$objContent->fields['content']
	   					);
	   					$redirect = str_replace(
	   						array('section=community', 'section=login'),
	   						array('section=access', 'section=access'),
	   						$objContent->fields['redirect']
	   					);

	   					$query = "UPDATE ".$dbTable." SET `content` = '".addslashes($content)."', `redirect` = '".addslashes($redirect)."' WHERE `id` = ".$objContent->fields['id'];
	   					if ($objDatabase->Execute($query) === false) {
	   						return $this->_databaseError($query, $objDatabase->ErrorMsg());
	   					}

	   					$objContent->MoveNext();
	   				}
	   			} else {
	   				return $this->_databaseError($query, $objDatabase->ErrorMsg());
	   			}
   			}
    	}

    	$arrColumns = $objDatabase->MetaColumnNames(DBPREFIX."backend_areas");
    	if (!is_array($arrColumns)) {
    		print "Die Struktur der Datenbanktabelle ".DBPREFIX."backend_areas konnte nicht ermittelt werden!";
    		return false;
    	}

    	if (!in_array('scope', $arrColumns)) {
    		$query = "ALTER TABLE `".DBPREFIX."backend_areas` ADD `scope` ENUM( 'global', 'frontend', 'backend' ) DEFAULT 'global' NOT NULL AFTER `type`";
    		if ($objDatabase->Execute($query) === false) {
    			return $this->_databaseError($query, $objDatabase->ErrorMsg());
    		}
    	}

    	$query = "UPDATE `".DBPREFIX."backend_areas` SET `scope` = 'backend'";
    	if ($objDatabase->Execute($query) === false) {
    		return $this->_databaseError($query, $objDatabase->ErrorMsg());
    	}

    	return true;
	}
}
?>
</form>
</body>
</html>