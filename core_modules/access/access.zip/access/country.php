<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Update from Version 1.0.8/1.0.9 to 1.0.9.4.1</title>
</head>
<body>
<?php
/**

	Plazieren Sie diese Datei in das Hauptverzeichniss Ihrer Contrexx Installation
	und klicken Sie anschliessend auf "Update starten".

*/
if (!@include_once('config/configuration.php')) {
	print "Plazieren Sie diese Datei in das Hauptverzeichniss Ihrer Contrexx Installation.";
} elseif (!@include_once(ASCMS_CORE_PATH.'/API.php')) {
	print "Die Datei ".ASCMS_CORE_PATH."/API.php fehlt oder kann nicht geladen werden!";
}

if (isset($_SYSCONFIG)) {
	foreach ($_SYSCONFIG as $sysconfigKey => $sysconfValue) {
		$_CONFIG[$sysconfigKey] = $sysconfValue;
	}
}

?>
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
<?php
	if (!isset($_POST['doUpdate'])) {
		print "<input type=\"submit\" name=\"doUpdate\" value=\"Update ausf�hren\" />";

	} else {
		$errorMsg = '';
		$objDatabase = getDatabaseObject($errorMsg);
		$objDatabase->debug=true;

		$objUpdate = &new Update();
		$objUpdate->doUpdate();
	}


class Update
{
	function doUpdate()
	{
		if ($this->_accessUpdate()) {
			print "Das Update wurde erfolgreich ausgef�hrt!";
		}
	}

	function _databaseError($query, $errorMsg)
	{
		print "Datenbank Fehler bei folgedem SQL Statement:<br />";
		print $query."<br /><br />";
		print "Detailierte Informationen:<br />";
		print $errorMsg."<br /><br />";
		print "Versuchen Sie das Update erneut auszuf�hren!<br />";

		return false;
	}

	function _accessUpdate()
	{
		global $objDatabase;

		$arrTables = $objDatabase->MetaTables('TABLES');
		if (!$arrTables) {
			print 'Die Struktur der Datenbank konnte nicht ermittelt werden!';
    		return false;
		}

		if (!in_array(DBPREFIX."access_rel_user_group", $arrTables)) {
			$query = "CREATE TABLE `".DBPREFIX."access_rel_user_group` (
				`id` int(10) unsigned NOT NULL auto_increment,
				`user_id` int(10) unsigned NOT NULL,
				`group_id` int(10) unsigned NOT NULL,
				PRIMARY KEY  (`id`),
				KEY `relation` (`user_id`,`group_id`)
			) TYPE=MyISAM";
			if ($objDatabase->Execute($query) === false) {
				return $this->_databaseError($query, $objDatabase->ErrorMsg());
			}
		}

		if (!in_array(DBPREFIX."access_user_profile", $arrTables)) {
			$query = "CREATE TABLE `".DBPREFIX."access_user_profile` (
				`user_id` INT UNSIGNED NOT NULL ,
				`prefix` ENUM( '', 'm', 'f' ) NOT NULL ,
				`firstname` VARCHAR( 255 ) NOT NULL ,
				`lastname` VARCHAR( 255 ) NOT NULL ,
				`company` VARCHAR( 100 ) NOT NULL ,
				`address` TINYTEXT NOT NULL ,
				`city` VARCHAR( 50 ) NOT NULL ,
				`zip` VARCHAR( 10 ) NOT NULL ,
				`country_id` SMALLINT UNSIGNED NOT NULL DEFAULT '0',
				`phone_office` VARCHAR( 20 ) NOT NULL ,
				`phone_private` VARCHAR( 20 ) NOT NULL ,
				`phone_mobile` VARCHAR( 20 ) NOT NULL ,
				`phone_fax` VARCHAR( 20 ) NOT NULL ,
				`website` VARCHAR( 255 ) NOT NULL ,
				`profession` VARCHAR( 150 ) NOT NULL ,
				`interests` VARCHAR( 255 ) NOT NULL ,
				`picture` VARCHAR( 255 ) NOT NULL ,
				PRIMARY KEY ( `user_id` ) ,
				FULLTEXT `fulltext` (
					`firstname` ,
					`lastname` ,
					`company` ,
					`address` ,
					`city` ,
					`zip` ,
					`phone_office` ,
					`phone_private` ,
					`phone_mobile` ,
					`phone_fax` ,
					`website` ,
					`profession` ,
					`interests`
				)
			) TYPE=MYISAM";
			if ($objDatabase->Execute($query) === false) {
				return $this->_databaseError($query, $objDatabase->ErrorMsg());
			}
		}

		$arrColumns = $objDatabase->MetaColumnNames(DBPREFIX."access_users");
    	if (!is_array($arrColumns)) {
    		print "Die Struktur der Datenbanktabelle ".DBPREFIX."access_users konnte nicht ermittelt werden!";
    		return false;
    	}

    	if (in_array('groups', $arrColumns)) {
    		$query = "SELECT `id`, `groups` FROM ".DBPREFIX."access_users WHERE `groups` != ''";
    		$objUser = $objDatabase->Execute($query);
    		if ($objUser) {
    			while (!$objUser->EOF) {
    				$arrGroups = explode(',', $objUser->fields['groups']);
    				foreach ($arrGroups as $groupId) {
    					$query = "SELECT 1 FROM ".DBPREFIX."access_rel_user_group WHERE `user_id` = ".$objUser->fields['id']." AND `group_id` = ".intval($groupId);
    					$objRel = $objDatabase->SelectLimit($query, 1);
    					if ($objRel) {
    						if ($objRel->RecordCount() == 0) {
    							$query = "INSERT INTO ".DBPREFIX."access_rel_user_group (`user_id`, `group_id`) VALUES (".$objUser->fields['id'].", ".intval($groupId).")";
    							if ($objDatabase->Execute($query) === false) {
    								return $this->_databaseError($query, $objDatabase->ErrorMsg());
    							}
    						}
    					} else {
    						return $this->_databaseError($query, $objDatabase->ErrorMsg());
    					}
    				}

    				$objUser->MoveNext();
    			}
    		} else {
    			return $this->_databaseError($query, $objDatabase->ErrorMsg());
    		}

    		$query = "ALTER TABLE ".DBPREFIX."access_users DROP `groups`";
    		if ($objDatabase->Execute($query) === false) {
    			return $this->_databaseError($query, $objDatabase->ErrorMsg());
    		}
    	}

    	if (in_array('firstname', $arrColumns)) {
    		$query = "SELECT `id`, `firstname`, `lastname`, `residence`, `profession`, `interests`, `webpage`, `company`, `zip`, `phone`, `mobile`, `street` FROM ".DBPREFIX."access_users";
    		$objUser = $objDatabase->Execute($query);
    		if ($objUser) {
    			while (!$objUser->EOF) {
    				$query = "SELECT 1 FROM ".DBPREFIX."access_user_profile WHERE `user_id` = ".$objUser->fields['id'];
    				$objProfile = $objDatabase->SelectLimit($query, 1);
    				if ($objProfile) {
    					if ($objProfile->RecordCount() == 0) {
    						$query = "INSERT INTO ".DBPREFIX."access_user_profile (
								`user_id`,
								`prefix`,
								`firstname`,
								`lastname`,
								`company`,
								`address`,
								`city`,
								`zip`,
								`country_id`,
								`phone_office`,
								`phone_private`,
								`phone_mobile`,
								`phone_fax`,
								`website`,
								`profession`,
								`interests`,
								`picture`
							) VALUES (
								".$objUser->fields['id'].",
								'',
								'".addslashes($objUser->fields['firstname'])."',
								'".addslashes($objUser->fields['lastname'])."',
								'".addslashes($objUser->fields['company'])."',
								'".addslashes($objUser->fields['street'])."',
								'".addslashes($objUser->fields['residence'])."',
								'".addslashes($objUser->fields['zip'])."',
								0,
								'',
								'".addslashes($objUser->fields['phone'])."',
								'".addslashes($objUser->fields['mobile'])."',
								'',
								'".addslashes($objUser->fields['webpage'])."',
								'".addslashes($objUser->fields['profession'])."',
								'".addslashes($objUser->fields['interests'])."',
								''
							)";
    						if ($objDatabase->Execute($query) === false) {
    							return $this->_databaseError($query, $objDatabase->ErrorMsg());
    						}
    					}
    				} else {
    					return $this->_databaseError($query, $objDatabase->ErrorMsg());
    				}

    				$objUser->MoveNext();
    			}
    		} else {
    			return $this->_databaseError($query, $objDatabase->ErrorMsg());
    		}

    		$arrRemoveColumns = array(
    			'firstname',
    			'lastname',
    			'residence',
    			'profession',
    			'interests',
    			'webpage',
    			'company',
    			'zip',
    			'phone',
    			'mobile',
    			'street',
    			'levelid'
   			);

   			foreach ($arrRemoveColumns as $column) {
   				if (in_array($column, $arrColumns)) {
   					$query = "ALTER TABLE ".DBPREFIX."access_users DROP `".$column."`";
   					if ($objDatabase->Execute($query) === false) {
   						return $this->_databaseError($query, $objDatabase->ErrorMsg());
   					}
   				}
   			}

   			$arrContentTables = array(
   				DBPREFIX."content",
   				DBPREFIX."content_history"
   			);

   			foreach ($arrContentTables as $dbTable) {
	   			$query = "SELECT `id`, `content`, `redirect` FROM ".$dbTable." WHERE `content` LIKE '%section=community%' OR `content` LIKE '%section=login%' OR `redirect` LIKE '%section=community%' OR `redirect` LIKE '%section=login%'";
	   			$objContent = $objDatabase->Execute($query);
	   			if ($objContent) {
	   				while (!$objContent->EOF) {
	   					$content = str_replace(
	   						array('section=community', 'section=login'),
	   						array('section=access', 'section=access'),
	   						$objContent->fields['content']
	   					);
	   					$redirect = str_replace(
	   						array('section=community', 'section=login'),
	   						array('section=access', 'section=access'),
	   						$objContent->fields['redirect']
	   					);

	   					$query = "UPDATE ".$dbTable." SET `content` = '".addslashes($content)."', `redirect` = '".addslashes($redirect)."' WHERE `id` = ".$objContent->fields['id'];
	   					if ($objDatabase->Execute($query) === false) {
	   						return $this->_databaseError($query, $objDatabase->ErrorMsg());
	   					}

	   					$objContent->MoveNext();
	   				}
	   			} else {
	   				return $this->_databaseError($query, $objDatabase->ErrorMsg());
	   			}
   			}

			return true;
    	}
	}
}
?>
</form>
</body>
</html>