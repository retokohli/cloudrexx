TODO:
-group permissions: button are wrong placed
-UpdateUser() doesn't work
-Add permission checks (add user id checker where a user is allowed to change his profile so that he will not be able to change an other profile by setting a user by hand)



add language variables:
	TXT_ACCESS
	TXT_ACCESS_MODULE_DESCRIPTION


change module community to access in modules table
change community backend area


ALTER TABLE `contrexx_access_users` DROP `levelid`

CREATE TABLE `contrexx_access_rel_user_group` (
`user_id` int(10) unsigned NOT NULL,
`group_id` int(10) unsigned NOT NULL,
PRIMARY KEY  (`user_id`,`group_id`)
) TYPE=MyISAM;


CREATE TABLE `contrexx_access_user_profile` (
`user_id` INT UNSIGNED NOT NULL ,
`prefix` ENUM( '', 'male', 'female' ) NOT NULL,
`firstname` VARCHAR( 255 ) NOT NULL ,
`lastname` VARCHAR( 255 ) NOT NULL ,
`company` VARCHAR( 100 ) NOT NULL ,
`address` TINYTEXT NOT NULL ,
`city` VARCHAR( 50 ) NOT NULL ,
`zip` VARCHAR( 10 ) NOT NULL ,
`country_id` SMALLINT UNSIGNED NOT NULL DEFAULT '0',
`phone_office` VARCHAR( 20 ) NOT NULL ,
`phone_private` VARCHAR( 20 ) NOT NULL ,
`phone_mobile` VARCHAR( 20 ) NOT NULL ,
`phone_fax` VARCHAR( 20 ) NOT NULL ,
`birthday` VARCHAR( 10 ) DEFAULT '00-00-0000' NOT NULL ,
`website` VARCHAR( 255 ) NOT NULL ,
`profession` VARCHAR( 150 ) NOT NULL ,
`interests` VARCHAR( 255 ) NOT NULL ,
`picture` VARCHAR( 255 ) NOT NULL ,
PRIMARY KEY ( `user_id` ) ,
FULLTEXT `fulltext` (
`firstname` ,
`lastname` ,
`company` ,
`address` ,
`city` ,
`zip` ,
`phone_office` ,
`phone_private` ,
`phone_mobile` ,
`phone_fax` ,
`website` ,
`profession` ,
`interests`
)
) TYPE = MYISAM ;



CREATE TABLE `contrexx_lib_country` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(64) NOT NULL,
  `iso_code_2` char(2) NOT NULL,
  `iso_code_3` char(3) NULL,
  PRIMARY KEY  (`id`),
  KEY `INDEX_COUNTRIES_NAME` (`name`)
) TYPE=MyISAM;

INSERT INTO `contrexx_lib_country` VALUES (1, 'Afghanistan', 'AF', 'AFG');
INSERT INTO `contrexx_lib_country` VALUES (2, 'Albania', 'AL', 'ALB');
INSERT INTO `contrexx_lib_country` VALUES (3, 'Algeria', 'DZ', 'DZA');
INSERT INTO `contrexx_lib_country` VALUES (4, 'American Samoa', 'AS', 'ASM');
INSERT INTO `contrexx_lib_country` VALUES (5, 'Andorra', 'AD', 'AND');
INSERT INTO `contrexx_lib_country` VALUES (6, 'Angola', 'AO', 'AGO');
INSERT INTO `contrexx_lib_country` VALUES (7, 'Anguilla', 'AI', 'AIA');
INSERT INTO `contrexx_lib_country` VALUES (8, 'Antarctica', 'AQ', 'ATA');
INSERT INTO `contrexx_lib_country` VALUES (9, 'Antigua and Barbuda', 'AG', 'ATG');
INSERT INTO `contrexx_lib_country` VALUES (10, 'Argentina', 'AR', 'ARG');
INSERT INTO `contrexx_lib_country` VALUES (11, 'Armenia', 'AM', 'ARM');
INSERT INTO `contrexx_lib_country` VALUES (12, 'Aruba', 'AW', 'ABW');
INSERT INTO `contrexx_lib_country` VALUES (13, 'Australia', 'AU', 'AUS');
INSERT INTO `contrexx_lib_country` VALUES (14, '�sterreich', 'AT', 'AUT');
INSERT INTO `contrexx_lib_country` VALUES (15, 'Azerbaijan', 'AZ', 'AZE');
INSERT INTO `contrexx_lib_country` VALUES (16, 'Bahamas', 'BS', 'BHS');
INSERT INTO `contrexx_lib_country` VALUES (17, 'Bahrain', 'BH', 'BHR');
INSERT INTO `contrexx_lib_country` VALUES (18, 'Bangladesh', 'BD', 'BGD');
INSERT INTO `contrexx_lib_country` VALUES (19, 'Barbados', 'BB', 'BRB');
INSERT INTO `contrexx_lib_country` VALUES (20, 'Belarus', 'BY', 'BLR');
INSERT INTO `contrexx_lib_country` VALUES (21, 'Belgium', 'BE', 'BEL');
INSERT INTO `contrexx_lib_country` VALUES (22, 'Belize', 'BZ', 'BLZ');
INSERT INTO `contrexx_lib_country` VALUES (23, 'Benin', 'BJ', 'BEN');
INSERT INTO `contrexx_lib_country` VALUES (24, 'Bermuda', 'BM', 'BMU');
INSERT INTO `contrexx_lib_country` VALUES (25, 'Bhutan', 'BT', 'BTN');
INSERT INTO `contrexx_lib_country` VALUES (26, 'Bolivia', 'BO', 'BOL');
INSERT INTO `contrexx_lib_country` VALUES (27, 'Bosnia and Herzegowina', 'BA', 'BIH');
INSERT INTO `contrexx_lib_country` VALUES (28, 'Botswana', 'BW', 'BWA');
INSERT INTO `contrexx_lib_country` VALUES (29, 'Bouvet Island', 'BV', 'BVT');
INSERT INTO `contrexx_lib_country` VALUES (30, 'Brazil', 'BR', 'BRA');
INSERT INTO `contrexx_lib_country` VALUES (31, 'British Indian Ocean Territory', 'IO', 'IOT');
INSERT INTO `contrexx_lib_country` VALUES (32, 'Brunei Darussalam', 'BN', 'BRN');
INSERT INTO `contrexx_lib_country` VALUES (33, 'Bulgaria', 'BG', 'BGR');
INSERT INTO `contrexx_lib_country` VALUES (34, 'Burkina Faso', 'BF', 'BFA');
INSERT INTO `contrexx_lib_country` VALUES (35, 'Burundi', 'BI', 'BDI');
INSERT INTO `contrexx_lib_country` VALUES (36, 'Cambodia', 'KH', 'KHM');
INSERT INTO `contrexx_lib_country` VALUES (37, 'Cameroon', 'CM', 'CMR');
INSERT INTO `contrexx_lib_country` VALUES (38, 'Canada', 'CA', 'CAN');
INSERT INTO `contrexx_lib_country` VALUES (39, 'Cape Verde', 'CV', 'CPV');
INSERT INTO `contrexx_lib_country` VALUES (40, 'Cayman Islands', 'KY', 'CYM');
INSERT INTO `contrexx_lib_country` VALUES (41, 'Central African Republic', 'CF', 'CAF');
INSERT INTO `contrexx_lib_country` VALUES (42, 'Chad', 'TD', 'TCD');
INSERT INTO `contrexx_lib_country` VALUES (43, 'Chile', 'CL', 'CHL');
INSERT INTO `contrexx_lib_country` VALUES (44, 'China', 'CN', 'CHN');
INSERT INTO `contrexx_lib_country` VALUES (45, 'Christmas Island', 'CX', 'CXR');
INSERT INTO `contrexx_lib_country` VALUES (46, 'Cocos (Keeling) Islands', 'CC', 'CCK');
INSERT INTO `contrexx_lib_country` VALUES (47, 'Colombia', 'CO', 'COL');
INSERT INTO `contrexx_lib_country` VALUES (48, 'Comoros', 'KM', 'COM');
INSERT INTO `contrexx_lib_country` VALUES (49, 'Congo', 'CG', 'COG');
INSERT INTO `contrexx_lib_country` VALUES (50, 'Cook Islands', 'CK', 'COK');
INSERT INTO `contrexx_lib_country` VALUES (51, 'Costa Rica', 'CR', 'CRI');
INSERT INTO `contrexx_lib_country` VALUES (52, 'Cote D''Ivoire', 'CI', 'CIV');
INSERT INTO `contrexx_lib_country` VALUES (53, 'Croatia', 'HR', 'HRV');
INSERT INTO `contrexx_lib_country` VALUES (54, 'Cuba', 'CU', 'CUB');
INSERT INTO `contrexx_lib_country` VALUES (55, 'Cyprus', 'CY', 'CYP');
INSERT INTO `contrexx_lib_country` VALUES (56, 'Czech Republic', 'CZ', 'CZE');
INSERT INTO `contrexx_lib_country` VALUES (57, 'Denmark', 'DK', 'DNK');
INSERT INTO `contrexx_lib_country` VALUES (58, 'Djibouti', 'DJ', 'DJI');
INSERT INTO `contrexx_lib_country` VALUES (59, 'Dominica', 'DM', 'DMA');
INSERT INTO `contrexx_lib_country` VALUES (60, 'Dominican Republic', 'DO', 'DOM');
INSERT INTO `contrexx_lib_country` VALUES (61, 'East Timor', 'TP', 'TMP');
INSERT INTO `contrexx_lib_country` VALUES (62, 'Ecuador', 'EC', 'ECU');
INSERT INTO `contrexx_lib_country` VALUES (63, 'Egypt', 'EG', 'EGY');
INSERT INTO `contrexx_lib_country` VALUES (64, 'El Salvador', 'SV', 'SLV');
INSERT INTO `contrexx_lib_country` VALUES (65, 'Equatorial Guinea', 'GQ', 'GNQ');
INSERT INTO `contrexx_lib_country` VALUES (66, 'Eritrea', 'ER', 'ERI');
INSERT INTO `contrexx_lib_country` VALUES (67, 'Estonia', 'EE', 'EST');
INSERT INTO `contrexx_lib_country` VALUES (68, 'Ethiopia', 'ET', 'ETH');
INSERT INTO `contrexx_lib_country` VALUES (69, 'Falkland Islands (Malvinas)', 'FK', 'FLK');
INSERT INTO `contrexx_lib_country` VALUES (70, 'Faroe Islands', 'FO', 'FRO');
INSERT INTO `contrexx_lib_country` VALUES (71, 'Fiji', 'FJ', 'FJI');
INSERT INTO `contrexx_lib_country` VALUES (72, 'Finland', 'FI', 'FIN');
INSERT INTO `contrexx_lib_country` VALUES (73, 'France', 'FR', 'FRA');
INSERT INTO `contrexx_lib_country` VALUES (74, 'France, Metropolitan', 'FX', 'FXX');
INSERT INTO `contrexx_lib_country` VALUES (75, 'French Guiana', 'GF', 'GUF');
INSERT INTO `contrexx_lib_country` VALUES (76, 'French Polynesia', 'PF', 'PYF');
INSERT INTO `contrexx_lib_country` VALUES (77, 'French Southern Territories', 'TF', 'ATF');
INSERT INTO `contrexx_lib_country` VALUES (78, 'Gabon', 'GA', 'GAB');
INSERT INTO `contrexx_lib_country` VALUES (79, 'Gambia', 'GM', 'GMB');
INSERT INTO `contrexx_lib_country` VALUES (80, 'Georgia', 'GE', 'GEO');
INSERT INTO `contrexx_lib_country` VALUES (81, 'Deutschland', 'DE', 'DEU');
INSERT INTO `contrexx_lib_country` VALUES (82, 'Ghana', 'GH', 'GHA');
INSERT INTO `contrexx_lib_country` VALUES (83, 'Gibraltar', 'GI', 'GIB');
INSERT INTO `contrexx_lib_country` VALUES (84, 'Greece', 'GR', 'GRC');
INSERT INTO `contrexx_lib_country` VALUES (85, 'Greenland', 'GL', 'GRL');
INSERT INTO `contrexx_lib_country` VALUES (86, 'Grenada', 'GD', 'GRD');
INSERT INTO `contrexx_lib_country` VALUES (87, 'Guadeloupe', 'GP', 'GLP');
INSERT INTO `contrexx_lib_country` VALUES (88, 'Guam', 'GU', 'GUM');
INSERT INTO `contrexx_lib_country` VALUES (89, 'Guatemala', 'GT', 'GTM');
INSERT INTO `contrexx_lib_country` VALUES (90, 'Guinea', 'GN', 'GIN');
INSERT INTO `contrexx_lib_country` VALUES (91, 'Guinea-bissau', 'GW', 'GNB');
INSERT INTO `contrexx_lib_country` VALUES (92, 'Guyana', 'GY', 'GUY');
INSERT INTO `contrexx_lib_country` VALUES (93, 'Haiti', 'HT', 'HTI');
INSERT INTO `contrexx_lib_country` VALUES (94, 'Heard and Mc Donald Islands', 'HM', 'HMD');
INSERT INTO `contrexx_lib_country` VALUES (95, 'Honduras', 'HN', 'HND');
INSERT INTO `contrexx_lib_country` VALUES (96, 'Hong Kong', 'HK', 'HKG');
INSERT INTO `contrexx_lib_country` VALUES (97, 'Hungary', 'HU', 'HUN');
INSERT INTO `contrexx_lib_country` VALUES (98, 'Iceland', 'IS', 'ISL');
INSERT INTO `contrexx_lib_country` VALUES (99, 'India', 'IN', 'IND');
INSERT INTO `contrexx_lib_country` VALUES (100, 'Indonesia', 'ID', 'IDN');
INSERT INTO `contrexx_lib_country` VALUES (101, 'Iran (Islamic Republic of)', 'IR', 'IRN');
INSERT INTO `contrexx_lib_country` VALUES (102, 'Iraq', 'IQ', 'IRQ');
INSERT INTO `contrexx_lib_country` VALUES (103, 'Ireland', 'IE', 'IRL');
INSERT INTO `contrexx_lib_country` VALUES (104, 'Israel', 'IL', 'ISR');
INSERT INTO `contrexx_lib_country` VALUES (105, 'Italy', 'IT', 'ITA');
INSERT INTO `contrexx_lib_country` VALUES (106, 'Jamaica', 'JM', 'JAM');
INSERT INTO `contrexx_lib_country` VALUES (107, 'Japan', 'JP', 'JPN');
INSERT INTO `contrexx_lib_country` VALUES (108, 'Jordan', 'JO', 'JOR');
INSERT INTO `contrexx_lib_country` VALUES (109, 'Kazakhstan', 'KZ', 'KAZ');
INSERT INTO `contrexx_lib_country` VALUES (110, 'Kenya', 'KE', 'KEN');
INSERT INTO `contrexx_lib_country` VALUES (111, 'Kiribati', 'KI', 'KIR');
INSERT INTO `contrexx_lib_country` VALUES (112, 'Korea, Democratic People''s Republic of', 'KP', 'PRK');
INSERT INTO `contrexx_lib_country` VALUES (113, 'Korea, Republic of', 'KR', 'KOR');
INSERT INTO `contrexx_lib_country` VALUES (114, 'Kuwait', 'KW', 'KWT');
INSERT INTO `contrexx_lib_country` VALUES (115, 'Kyrgyzstan', 'KG', 'KGZ');
INSERT INTO `contrexx_lib_country` VALUES (116, 'Lao People''s Democratic Republic', 'LA', 'LAO');
INSERT INTO `contrexx_lib_country` VALUES (117, 'Latvia', 'LV', 'LVA');
INSERT INTO `contrexx_lib_country` VALUES (118, 'Lebanon', 'LB', 'LBN');
INSERT INTO `contrexx_lib_country` VALUES (119, 'Lesotho', 'LS', 'LSO');
INSERT INTO `contrexx_lib_country` VALUES (120, 'Liberia', 'LR', 'LBR');
INSERT INTO `contrexx_lib_country` VALUES (121, 'Libyan Arab Jamahiriya', 'LY', 'LBY');
INSERT INTO `contrexx_lib_country` VALUES (122, 'Liechtenstein', 'LI', 'LIE');
INSERT INTO `contrexx_lib_country` VALUES (123, 'Lithuania', 'LT', 'LTU');
INSERT INTO `contrexx_lib_country` VALUES (124, 'Luxembourg', 'LU', 'LUX');
INSERT INTO `contrexx_lib_country` VALUES (125, 'Macau', 'MO', 'MAC');
INSERT INTO `contrexx_lib_country` VALUES (126, 'Macedonia, The Former Yugoslav Republic of', 'MK', 'MKD');
INSERT INTO `contrexx_lib_country` VALUES (127, 'Madagascar', 'MG', 'MDG');
INSERT INTO `contrexx_lib_country` VALUES (128, 'Malawi', 'MW', 'MWI');
INSERT INTO `contrexx_lib_country` VALUES (129, 'Malaysia', 'MY', 'MYS');
INSERT INTO `contrexx_lib_country` VALUES (130, 'Maldives', 'MV', 'MDV');
INSERT INTO `contrexx_lib_country` VALUES (131, 'Mali', 'ML', 'MLI');
INSERT INTO `contrexx_lib_country` VALUES (132, 'Malta', 'MT', 'MLT');
INSERT INTO `contrexx_lib_country` VALUES (133, 'Marshall Islands', 'MH', 'MHL');
INSERT INTO `contrexx_lib_country` VALUES (134, 'Martinique', 'MQ', 'MTQ');
INSERT INTO `contrexx_lib_country` VALUES (135, 'Mauritania', 'MR', 'MRT');
INSERT INTO `contrexx_lib_country` VALUES (136, 'Mauritius', 'MU', 'MUS');
INSERT INTO `contrexx_lib_country` VALUES (137, 'Mayotte', 'YT', 'MYT');
INSERT INTO `contrexx_lib_country` VALUES (138, 'Mexico', 'MX', 'MEX');
INSERT INTO `contrexx_lib_country` VALUES (139, 'Micronesia, Federated States of', 'FM', 'FSM');
INSERT INTO `contrexx_lib_country` VALUES (140, 'Moldova, Republic of', 'MD', 'MDA');
INSERT INTO `contrexx_lib_country` VALUES (141, 'Monaco', 'MC', 'MCO');
INSERT INTO `contrexx_lib_country` VALUES (142, 'Mongolia', 'MN', 'MNG');
INSERT INTO `contrexx_lib_country` VALUES (143, 'Montserrat', 'MS', 'MSR');
INSERT INTO `contrexx_lib_country` VALUES (144, 'Morocco', 'MA', 'MAR');
INSERT INTO `contrexx_lib_country` VALUES (145, 'Mozambique', 'MZ', 'MOZ');
INSERT INTO `contrexx_lib_country` VALUES (146, 'Myanmar', 'MM', 'MMR');
INSERT INTO `contrexx_lib_country` VALUES (147, 'Namibia', 'NA', 'NAM');
INSERT INTO `contrexx_lib_country` VALUES (148, 'Nauru', 'NR', 'NRU');
INSERT INTO `contrexx_lib_country` VALUES (149, 'Nepal', 'NP', 'NPL');
INSERT INTO `contrexx_lib_country` VALUES (150, 'Netherlands', 'NL', 'NLD');
INSERT INTO `contrexx_lib_country` VALUES (151, 'Netherlands Antilles', 'AN', 'ANT');
INSERT INTO `contrexx_lib_country` VALUES (152, 'New Caledonia', 'NC', 'NCL');
INSERT INTO `contrexx_lib_country` VALUES (153, 'New Zealand', 'NZ', 'NZL');
INSERT INTO `contrexx_lib_country` VALUES (154, 'Nicaragua', 'NI', 'NIC');
INSERT INTO `contrexx_lib_country` VALUES (155, 'Niger', 'NE', 'NER');
INSERT INTO `contrexx_lib_country` VALUES (156, 'Nigeria', 'NG', 'NGA');
INSERT INTO `contrexx_lib_country` VALUES (157, 'Niue', 'NU', 'NIU');
INSERT INTO `contrexx_lib_country` VALUES (158, 'Norfolk Island', 'NF', 'NFK');
INSERT INTO `contrexx_lib_country` VALUES (159, 'Northern Mariana Islands', 'MP', 'MNP');
INSERT INTO `contrexx_lib_country` VALUES (160, 'Norway', 'NO', 'NOR');
INSERT INTO `contrexx_lib_country` VALUES (161, 'Oman', 'OM', 'OMN');
INSERT INTO `contrexx_lib_country` VALUES (162, 'Pakistan', 'PK', 'PAK');
INSERT INTO `contrexx_lib_country` VALUES (163, 'Palau', 'PW', 'PLW');
INSERT INTO `contrexx_lib_country` VALUES (164, 'Panama', 'PA', 'PAN');
INSERT INTO `contrexx_lib_country` VALUES (165, 'Papua New Guinea', 'PG', 'PNG');
INSERT INTO `contrexx_lib_country` VALUES (166, 'Paraguay', 'PY', 'PRY');
INSERT INTO `contrexx_lib_country` VALUES (167, 'Peru', 'PE', 'PER');
INSERT INTO `contrexx_lib_country` VALUES (168, 'Philippines', 'PH', 'PHL');
INSERT INTO `contrexx_lib_country` VALUES (169, 'Pitcairn', 'PN', 'PCN');
INSERT INTO `contrexx_lib_country` VALUES (170, 'Poland', 'PL', 'POL');
INSERT INTO `contrexx_lib_country` VALUES (171, 'Portugal', 'PT', 'PRT');
INSERT INTO `contrexx_lib_country` VALUES (172, 'Puerto Rico', 'PR', 'PRI');
INSERT INTO `contrexx_lib_country` VALUES (173, 'Qatar', 'QA', 'QAT');
INSERT INTO `contrexx_lib_country` VALUES (174, 'Reunion', 'RE', 'REU');
INSERT INTO `contrexx_lib_country` VALUES (175, 'Romania', 'RO', 'ROM');
INSERT INTO `contrexx_lib_country` VALUES (176, 'Russian Federation', 'RU', 'RUS');
INSERT INTO `contrexx_lib_country` VALUES (177, 'Rwanda', 'RW', 'RWA');
INSERT INTO `contrexx_lib_country` VALUES (178, 'Saint Kitts and Nevis', 'KN', 'KNA');
INSERT INTO `contrexx_lib_country` VALUES (179, 'Saint Lucia', 'LC', 'LCA');
INSERT INTO `contrexx_lib_country` VALUES (180, 'Saint Vincent and the Grenadines', 'VC', 'VCT');
INSERT INTO `contrexx_lib_country` VALUES (181, 'Samoa', 'WS', 'WSM');
INSERT INTO `contrexx_lib_country` VALUES (182, 'San Marino', 'SM', 'SMR');
INSERT INTO `contrexx_lib_country` VALUES (183, 'Sao Tome and Principe', 'ST', 'STP');
INSERT INTO `contrexx_lib_country` VALUES (184, 'Saudi Arabia', 'SA', 'SAU');
INSERT INTO `contrexx_lib_country` VALUES (185, 'Senegal', 'SN', 'SEN');
INSERT INTO `contrexx_lib_country` VALUES (186, 'Seychelles', 'SC', 'SYC');
INSERT INTO `contrexx_lib_country` VALUES (187, 'Sierra Leone', 'SL', 'SLE');
INSERT INTO `contrexx_lib_country` VALUES (188, 'Singapore', 'SG', 'SGP');
INSERT INTO `contrexx_lib_country` VALUES (189, 'Slovakia (Slovak Republic)', 'SK', 'SVK');
INSERT INTO `contrexx_lib_country` VALUES (190, 'Slovenia', 'SI', 'SVN');
INSERT INTO `contrexx_lib_country` VALUES (191, 'Solomon Islands', 'SB', 'SLB');
INSERT INTO `contrexx_lib_country` VALUES (192, 'Somalia', 'SO', 'SOM');
INSERT INTO `contrexx_lib_country` VALUES (193, 'South Africa', 'ZA', 'ZAF');
INSERT INTO `contrexx_lib_country` VALUES (194, 'South Georgia and the South Sandwich Islands', 'GS', 'SGS');
INSERT INTO `contrexx_lib_country` VALUES (195, 'Spain', 'ES', 'ESP');
INSERT INTO `contrexx_lib_country` VALUES (196, 'Sri Lanka', 'LK', 'LKA');
INSERT INTO `contrexx_lib_country` VALUES (197, 'St. Helena', 'SH', 'SHN');
INSERT INTO `contrexx_lib_country` VALUES (198, 'St. Pierre and Miquelon', 'PM', 'SPM');
INSERT INTO `contrexx_lib_country` VALUES (199, 'Sudan', 'SD', 'SDN');
INSERT INTO `contrexx_lib_country` VALUES (200, 'Suriname', 'SR', 'SUR');
INSERT INTO `contrexx_lib_country` VALUES (201, 'Svalbard and Jan Mayen Islands', 'SJ', 'SJM');
INSERT INTO `contrexx_lib_country` VALUES (202, 'Swaziland', 'SZ', 'SWZ');
INSERT INTO `contrexx_lib_country` VALUES (203, 'Sweden', 'SE', 'SWE');
INSERT INTO `contrexx_lib_country` VALUES (204, 'Schweiz', 'CH', 'CHE');
INSERT INTO `contrexx_lib_country` VALUES (205, 'Syrian Arab Republic', 'SY', 'SYR');
INSERT INTO `contrexx_lib_country` VALUES (206, 'Taiwan', 'TW', 'TWN');
INSERT INTO `contrexx_lib_country` VALUES (207, 'Tajikistan', 'TJ', 'TJK');
INSERT INTO `contrexx_lib_country` VALUES (208, 'Tanzania, United Republic of', 'TZ', 'TZA');
INSERT INTO `contrexx_lib_country` VALUES (209, 'Thailand', 'TH', 'THA');
INSERT INTO `contrexx_lib_country` VALUES (210, 'Togo', 'TG', 'TGO');
INSERT INTO `contrexx_lib_country` VALUES (211, 'Tokelau', 'TK', 'TKL');
INSERT INTO `contrexx_lib_country` VALUES (212, 'Tonga', 'TO', 'TON');
INSERT INTO `contrexx_lib_country` VALUES (213, 'Trinidad and Tobago', 'TT', 'TTO');
INSERT INTO `contrexx_lib_country` VALUES (214, 'Tunisia', 'TN', 'TUN');
INSERT INTO `contrexx_lib_country` VALUES (215, 'Turkey', 'TR', 'TUR');
INSERT INTO `contrexx_lib_country` VALUES (216, 'Turkmenistan', 'TM', 'TKM');
INSERT INTO `contrexx_lib_country` VALUES (217, 'Turks and Caicos Islands', 'TC', 'TCA');
INSERT INTO `contrexx_lib_country` VALUES (218, 'Tuvalu', 'TV', 'TUV');
INSERT INTO `contrexx_lib_country` VALUES (219, 'Uganda', 'UG', 'UGA');
INSERT INTO `contrexx_lib_country` VALUES (220, 'Ukraine', 'UA', 'UKR');
INSERT INTO `contrexx_lib_country` VALUES (221, 'United Arab Emirates', 'AE', 'ARE');
INSERT INTO `contrexx_lib_country` VALUES (222, 'United Kingdom', 'GB', 'GBR');
INSERT INTO `contrexx_lib_country` VALUES (223, 'United States', 'US', 'USA');
INSERT INTO `contrexx_lib_country` VALUES (224, 'United States Minor Outlying Islands', 'UM', 'UMI');
INSERT INTO `contrexx_lib_country` VALUES (225, 'Uruguay', 'UY', 'URY');
INSERT INTO `contrexx_lib_country` VALUES (226, 'Uzbekistan', 'UZ', 'UZB');
INSERT INTO `contrexx_lib_country` VALUES (227, 'Vanuatu', 'VU', 'VUT');
INSERT INTO `contrexx_lib_country` VALUES (228, 'Vatican City State (Holy See)', 'VA', 'VAT');
INSERT INTO `contrexx_lib_country` VALUES (229, 'Venezuela', 'VE', 'VEN');
INSERT INTO `contrexx_lib_country` VALUES (230, 'Viet Nam', 'VN', 'VNM');
INSERT INTO `contrexx_lib_country` VALUES (231, 'Virgin Islands (British)', 'VG', 'VGB');
INSERT INTO `contrexx_lib_country` VALUES (232, 'Virgin Islands (U.S.)', 'VI', 'VIR');
INSERT INTO `contrexx_lib_country` VALUES (233, 'Wallis and Futuna Islands', 'WF', 'WLF');
INSERT INTO `contrexx_lib_country` VALUES (234, 'Western Sahara', 'EH', 'ESH');
INSERT INTO `contrexx_lib_country` VALUES (235, 'Yemen', 'YE', 'YEM');
INSERT INTO `contrexx_lib_country` VALUES (236, 'Yugoslavia', 'YU', 'YUG');
INSERT INTO `contrexx_lib_country` VALUES (237, 'Zaire', 'ZR', 'ZAR');
INSERT INTO `contrexx_lib_country` VALUES (238, 'Zambia', 'ZM', 'ZMB');
INSERT INTO `contrexx_lib_country` VALUES (239, 'Zimbabwe', 'ZW', 'ZWE');


CREATE TABLE `contrexx_access_settings` (
`key` VARCHAR( 32 ) NOT NULL ,
`value` VARCHAR( 255 ) NOT NULL ,
`status` TINYINT( 1 ) UNSIGNED NOT NULL ,
UNIQUE (
`key`
)
) TYPE = MYISAM ;


ALTER TABLE `contrexx_access_users` CHANGE `is_admin` `is_admin` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '0'

ALTER TABLE `contrexx_access_users` CHANGE `regdate` `regdate` INT( 14 ) UNSIGNED NULL DEFAULT '0'



INSERT INTO `contrexx_backend_areas` ( `area_id` , `parent_area_id` , `type` , `area_name` , `is_active` , `uri` , `target` , `module_id` , `order_id` , `access_id` )
VALUES (
'', '61', 'function', 'TXT_ACCESS_MANAGE_USERS', '1', '', '_self', '23', '0', '109'
);

ALTER TABLE `contrexx_backend_areas` ADD `scope` ENUM( 'global', 'frontend', 'backend' ) DEFAULT 'global' NOT NULL AFTER `type` ;