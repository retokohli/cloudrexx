<?php
/**
* Class access
*
* access module class
*
* @copyright	CONTREXX CMS - Astalavista IT Engineering GmbH Thun
* @author		Astalavista Development Team <thun@astalvista.ch>
* @module		access
* @modulegroup	core_modules
* @access		public
* @version		1.0.0
*/
error_reporting(E_ALL);ini_set('display_errors', 1);
//$objDatabase->debug=true;

//ini_set('display_errors', 1);
//error_reporting(E_ALL);

$_CORELANG['TXT_INVALID_USERNAME'] = 'Der Benutzername darf nur aus Alpfanumerischen Zeichen (a-z/A-Z/0-9) und den folgenden Sonderzeichen bestehen: -_';
$_CORELANG['TXT_USERNAME_ALREADY_USED'] = 'Der gew�hlte Benutzername wird bereits von einem anderen Benutzer verwendet! W�hlen Sie bitte einen anderen Benutzernamen!';
$_CORELANG['TXT_INVALID_EMAIL_ADDRESS'] = 'Sie m�ssen eine g�ltige E-Mail Adresse angeben!';
$_CORELANG['TXT_EMAIL_ALREADY_USED'] = 'Diese E-Mail Adresse wird bereits von einem anderen Benutzerkonto verwendet!';
$_CORELANG['TXT_INVALID_PASSWORD'] = 'Das Kennwort ist ung�ltig! Es muss mindestens 6 Zeichen lang sein!';
$_CORELANG['TXT_PASSWORD_NOT_CONFIRMED'] = 'Das Best�tigungskennwort stimmt nicht mit Ihrem gew�hlten Kennwort �berein!';
$_CORELANG['TXT_COULD_NOT_SET_GROUP_ASSOCIATIONS'] = 'Die Gruppenzugeh�rigkeiten konnten nicht gesetzt werden! Versuchen Sie den Vorgang zu wiederholen!';
$_CORELANG['TXT_COULD_NOT_SET_PROFILE_DATA'] = 'Beim Speichern der Profildaten trat ein Fehler auf! Versuchen Sie den Vorgang zu wiederholen!';
$_CORELANG['TXT_FAILED_TO_ADD_USER_ACCOUNT'] = 'Beim hinzuf�gen des Benutzerkontos trat ein Fehler auf! Versuchen Sie den Vorgang zu wiederholen!';
$_CORELANG['TXT_FAILED_TO_SET_USER_LANGUAGE'] = 'Die Benutzersprache konnte nicht gesetzt werden! Versuchen Sie den Vorgang zu wiederholen!';
$_CORELANG['TXT_ACCESS_LAST_ADMIN_USER'] = 'Der Benutzer %s konnte nicht gel�scht werden, da es der einzige Administrator ist!';
$_CORELANG['TXT_ACCESS_UNABLE_DELETE_YOUR_USER'] = 'Sie k�nnen Ihren eigenen Benutzer nicht l�schen!';
$_CORELANG['TXT_ACCESS_NO_USER_WITH_ID'] = 'Ein Benutzer mit der ID %s gibt es nicht!';
$_CORELANG['TXT_ACCESS_USER_DELETE_FAILED'] = 'Der Benutzer %s konnte nicht gel�scht werden, da ein Fehler auftrat!';
$_CORELANG['TXT_ACCESS_CHANGE_PERM_LAST_ADMIN_USER'] = 'Dem Benutzer %s konnten die Administrator-Rechte nicht entzogen werden, da es der einzige Administrator ist!';


$_ARRAYLANG['TXT_ACCESS_OVERVIEW'] = '�bersicht';
$_ARRAYLANG['TXT_ACCESS_USER'] = 'Benutzer';
$_ARRAYLANG['TXT_ACCESS_USERS'] = 'Benutzer';
$_ARRAYLANG['TXT_ACCESS_GROUPS'] = 'Gruppen';
$_ARRAYLANG['TXT_ACCESS_SETTINGS'] = 'Einstellungen';
$_ARRAYLANG['TXT_ACCESS_USER_LIST'] = 'Benutzer Liste';
$_ARRAYLANG['TXT_ACCESS_USERNAME'] = 'Benutzername';
$_ARRAYLANG['TXT_ACCESS_FIRSTNAME'] = 'Vorname';
$_ARRAYLANG['TXT_ACCESS_LASTNAME'] = 'Nachname';
$_ARRAYLANG['TXT_ACCESS_EMAIL'] = 'E-Mail';
$_ARRAYLANG['TXT_ACCESS_LANGUAGE'] = 'Sprache';
$_ARRAYLANG['TXT_ACCESS_ADMINISTRATOR'] = 'Administrator';
$_ARRAYLANG['TXT_ACCESS_FUNCTIONS'] = 'Funktionen';
$_ARRAYLANG['TXT_ACCESS_MODIFY_USER_ACCOUNT'] = 'Benutzerkonto bearbeiten';
$_ARRAYLANG['TXT_ACCESS_SEND_EMAIL_TO_USER'] = 'E-Mail an %s schicken';
$_ARRAYLANG['TXT_ACCESS_NO_ADMINISTRATOR'] = 'Kein Administrator';
$_ARRAYLANG['TXT_ACCESS_DELETE_USER_ACCOUNT'] = 'Benutzerkonto von %s l�schen';
$_ARRAYLANG['TXT_ACCESS_CHANGE_SORT_DIRECTION'] = 'Sortierreihenfolge �ndern';
$_ARRAYLANG['TXT_ACCESS_SELECT_GROUP'] = 'Gruppe ausw�hlen';
$_ARRAYLANG['TXT_ACCESS_ALL'] = 'Alle';
$_ARRAYLANG['TXT_ACCESS_NO_USER_IN_GROUP'] = 'Die Gruppe %s enth�lt keine Benutzer!';
$_ARRAYLANG['TXT_ACCESS_NO_USERS'] = 'Keine Bentzer vorhanden!';
$_ARRAYLANG['TXT_ACCESS_STATUS'] = 'Status';
$_ARRAYLANG['TXT_ACCESS_CONFIRM_DELETE_USER'] = 'M�chten Sie den Benutzer %s wirklich l�schen?';
$_ARRAYLANG['TXT_ACCESS_OPERATION_IRREVERSIBLE'] = 'Dieser Vorgang kann nicht r�ckg�ngig gemacht werden!';
$_ARRAYLANG['TXT_ACCESS_NO_USER_WITH_ID'] = 'Ein Benutzer mit der ID %s gibt es nicht!';
$_ARRAYLANG['TXT_ACCESS_USER_SUCCESSFULLY_DELETED'] = 'Der Benutzer %s wurde erfolgreich gel�scht.';
$_ARRAYLANG['TXT_ACCESS_MODIFY_USER_ACCOUNT'] = 'Benutzerkonto bearbeiten';
$_ARRAYLANG['TXT_ACCESS_CREATE_USER_ACCOUNT'] = 'Neues Benutzerkonto erstellen';
$_ARRAYLANG['TXT_ACCESS_USER_ACCOUNT'] = 'Benutzerkonto';
$_ARRAYLANG['TXT_ACCESS_USER_GROUP_S'] = 'Benutzergruppe(n)';
$_ARRAYLANG['TXT_ACCESS_PROFILE'] = 'Profil';
$_ARRAYLANG['TXT_ACCESS_PASSWORD'] = 'Kennwort';
$_ARRAYLANG['TXT_ACCESS_CONFIRM_PASSWORD'] = 'Kennwort best�tigen';
$_ARRAYLANG['TXT_ACCESS_PASSWORD_MINIMAL_CHARACTERS'] = '(min. 6 Zeichen)';
$_ARRAYLANG['TXT_ACCESS_USER_ADMIN_RIGHTS'] = 'Benutzer erh�lt Administrator-Rechte.';
$_ARRAYLANG['TXT_ACCESS_PASSWORD_FIELD_EMPTY'] = 'Wenn Sie das Kennwortfeld leer lassen, wird das aktuelle Kennwort beibehalten!';
$_ARRAYLANG['TXT_ACCESS_PASSWORD_MD5_ENCRYPTED'] = 'Das Passwort wird mit dem MD5 Logarithmus verschl�sselt.';
$_ARRAYLANG['TXT_ACCESS_AVAILABLE_GROUPS'] = 'Vorhandene Gruppen';
$_ARRAYLANG['TXT_ACCESS_ASSOCIATED_GROUPS'] = 'Zugeordnete Gruppen';
$_ARRAYLANG['TXT_ACCESS_CHECK_ALL'] = 'Alle ausw�hlen';
$_ARRAYLANG['TXT_ACCESS_UNCHECK_ALL'] = 'Auswahl entfernen';
$_ARRAYLANG['TXT_ACCESS_GENDER'] = 'Geschlecht';
$_ARRAYLANG['TXT_ACCESS_COMPANY'] = 'Firma';
$_ARRAYLANG['TXT_ACCESS_ADDRESS'] = 'Adresse';
$_ARRAYLANG['TXT_ACCESS_CITY'] = 'Ort';
$_ARRAYLANG['TXT_ACCESS_ZIP'] = 'PLZ';
$_ARRAYLANG['TXT_ACCESS_COUNTRY'] = 'Land';
$_ARRAYLANG['TXT_ACCESS_PHONE_OFFICE'] = 'Tel. B�ro';
$_ARRAYLANG['TXT_ACCESS_PHONE_PRIVATE'] = 'Tel. Privat';
$_ARRAYLANG['TXT_ACCESS_PHONE_MOBILE'] = 'Tel. Mobile';
$_ARRAYLANG['TXT_ACCESS_PHONE_FAX'] = 'Fax';
$_ARRAYLANG['TXT_ACCESS_BIRTHDAY'] = 'Geburtsday';
$_ARRAYLANG['TXT_ACCESS_WEBSITE'] = 'Webseite';
$_ARRAYLANG['TXT_ACCESS_PREFESSION'] = 'Beruf';
$_ARRAYLANG['TXT_ACCESS_INTERESTS'] = 'Interessen';
$_ARRAYLANG['TXT_ACCESS_SAVE'] = 'Speichern';
$_ARRAYLANG['TXT_ACCESS_CANCEL'] = 'Abbrechen';
$_ARRAYLANG['TXT_ACCESS_CHANGE_WEBSITE'] = 'Webseite �ndern';
$_ARRAYLANG['TXT_ACCESS_VISIT_WEBSITE'] = 'Webseite besuchen';
$_ARRAYLANG['TXT_ACCESS_NO_SPECIFIED'] = 'Keine angegeben!';
$_ARRAYLANG['TXT_ACCESS_SKYPE_NAME'] = 'Skype-Name';
$_ARRAYLANG['TXT_ACCESS_CHANGE_PROFILE_PIC'] = 'Profilbild �ndern';
$_ARRAYLANG['TXT_ACCESS_ACTIVE'] = 'Aktiv';
$_ARRAYLANG['TXT_ACCESS_GROUP_LIST'] = 'Gruppen Liste';
$_ARRAYLANG['TXT_ACCESS_NAME'] = 'Name';
$_ARRAYLANG['TXT_ACCESS_DESCRIPTION'] = 'Beschreibung';
$_ARRAYLANG['TXT_ACCESS_TYPE'] = 'Typ';
$_ARRAYLANG['TXT_ACCESS_MODIFY_GROUP'] = 'Gruppe bearbeiten';
$_ARRAYLANG['TXT_ACCESS_DELETE_GROUP'] = 'Gruppe %s l�schen';
$_ARRAYLANG['TXT_ACCESS_INACTIVE'] = 'Inaktiv';
$_ARRAYLANG['TXT_ACCESS_SHOW_USERS_OF_GROUP'] = 'Benutzer der Gruppe %s anzeigen';
$_ARRAYLANG['TXT_ACCESS_USER_REGISTRATION'] = 'Benutzerregistrierung';
$_ARRAYLANG['TXT_ACCESS_EMAILS'] = 'E-Mails';

$_ARRAYLANG['TXT_ACCESS_GENERAL'] = 'Allgemein';
$_ARRAYLANG['TXT_ACCESS_PERMISSIONS'] = 'Berechtigungen';
$_ARRAYLANG['TXT_ACCESS_AVAILABLE_USERS'] = 'Vorhandene Benutzer';
$_ARRAYLANG['TXT_ACCESS_ASSOCIATED_USERS'] = 'Zugeordnete Benutzer';
$_ARRAYLANG['TXT_ACCESS_SHOW_PAGE_IN_NEW_DOCUMENT'] = 'Webseite in neuem Fenster anzeigen';
$_ARRAYLANG['TXT_ACCESS_MODIFY_PAGE_IN_NEW_DOCUMENT'] = 'Webseite in neuem Fenster bearbeiten';
$_ARRAYLANG['TXT_ACCESS_PROTECTED'] = 'Gesch�tzt';
$_ARRAYLANG['TXT_ACCESS_PUBLIC'] = '�ffentlich';
$_ARRAYLANG['TXT_ACCESS_UNPROTECT_PAGE'] = 'Sind Sie sicher, dass Sie diese Seite wieder �ffentlich zug�nglich machen wollen?';
$_ARRAYLANG['TXT_ACCESS_PROTECT_PAGE'] = 'Soll diese Seite gesch�tzt werden?';
$_ARRAYLANG['TXT_ACCESS_CLICK_UNLOCK_PAGE_MODIF'] = 'Klicken Sie auf das Symbol um den Modifikationsschutz dieser Seite zu entfehrnen.';
$_ARRAYLANG['TXT_ACCESS_CLICK_LOCK_PAGE_MODIFY'] = 'Klicken Sie auf das Symbol um die Seite vor unerlaubten Modifikationen zu sch�tzen.';
$_ARRAYLANG['TXT_ACCESS_CLICK_UNLOCK_PAGE_ACCESS'] = 'Klicken Sie auf das Symbol um die Seite �ffentlich zug�nglich zu machen.';
$_ARRAYLANG['TXT_ACCESS_CLICK_LOCK_PAGE_ACCESS'] = 'Klicken Sie auf das Symbol um die Seite vor unerlaubtem Zugriff zu sch�tzen.';
$_ARRAYLANG['TXT_ACCESS_PROMT_EXEC_WARNING'] = 'Achtung: Nach dem Best�tigen dieser Anforderung wird die angeforderte Aktion sofort durchgef�hrt!';
$_ARRAYLANG['TXT_ACCESS_CONFIRM_LOCK_PAGE'] = 'M�chten Sie diese Seite vor unerlaubten Modifikationen sch�tzen?';
$_ARRAYLANG['TXT_ACCESS_CONFIRM_PROTECT_PAGE'] = 'M�chten Sie diese Seite vor unerlaubtem Zugriff sch�tzen?';
$_ARRAYLANG['TXT_ACCESS_CONFIRM_UNLOCK_PAGE'] = 'M�chten Sie den Modifikationsschutz dieser Seite wirklich entfehrnen?';
$_ARRAYLANG['TXT_ACCESS_CONFIRM_UNPROTECT_PAGE'] = 'M�chten Sie den Zugriffsschutz dieser Seite wirklich entfehrnen?';
$_ARRAYLANG['TXT_ACCESS_ADDRESS_OF_USER_TO_NOTIFY'] = 'E-Mail Adresse, an die eine Nachricht gesendet werden soll, wenn sich ein neuer Benutzer registriert hat.';
$_ARRAYLANG['TXT_ACCESS_PROFILE_PIC'] = 'Profilbild';
$_ARRAYLANG['TXT_ACCESS_MAX_WIDTH'] = 'Maximale Breite';
$_ARRAYLANG['TXT_ACCESS_MAX_HEIGHT'] = 'Maximale H�he';
$_ARRAYLANG['TXT_ACCESS_MAX_FILE_SIZE'] = 'Maximale Dateigr�sse';
$_ARRAYLANG['TXT_ACCESS_CONFIG_SUCCESSFULLY_SAVED'] = 'Die Einstellungen wurden erfolgreich gespeichert.';
$_ARRAYLANG['TXT_ACCESS_CONFIG_FAILED_SAVED'] = 'Beim Speichern der Einstellungen trat ein Fehler auf! Versuchen Sie den Vorgang zu wiederholen!';

// community vars
$_ARRAYLANG['TXT_ACCESS_GROUP_ASSOCIATION_TEXT'] = 'Choose the groups to which a new registered user should belong to.<br />Hint: A user, who isn�t associated to a group, isn�t able to login into the system!';
$_ARRAYLANG['TXT_ACCESS_USER_ACCOUNT_ACTIVATION_METHOD_TEXT'] = 'Method used to activate the user account of a new registered user';
$_ARRAYLANG['TXT_ACCESS_ACTIVATION_BY_USER'] = 'Activation by the user.';
$_ARRAYLANG['TXT_ACCESS_ACTIVATION_BY_AUTHORIZED_PERSON'] = 'Activation by an authorized person (see Backend group permissions under User administration).';
$_ARRAYLANG['TXT_ACCESS_TIME_PERIOD_ACTIVATION_TIME'] = 'Time period in hours before the activation time expires. (0 � 24 hours, 0 for unlimited)';
$_ARRAYLANG['TXT_ACCESS_INVALID_ENTERED_EMAIL_ADDRESS'] = 'Die eingegebene E-Mail Adresse ist ung�ltig!';

class Access extends FWUser
{
	var $_objTpl;

	var $arrStatusMsg = array('ok' => array(), 'error' => array());

	var $_pageTitle = '';

	var $_noProfilePic = '/images/modules/access/user_pic.gif';

	/**
	* Constructor
	*/
	function Access()
	{
		$this->__construct();
	}

	/**
	* PHP5 constructor
	*
	* @global object $objTemplate
	* @global array $_ARRAYLANG
	*/
	function __construct()
	{
		global $objTemplate, $_ARRAYLANG;

		$this->_objTpl = &new HTML_Template_Sigma(ASCMS_CORE_MODULE_PATH.'/access/template');
		$this->_objTpl->setErrorHandling(PEAR_ERROR_DIE);

    	$objTemplate->setVariable("CONTENT_NAVIGATION", "	<a href='index.php?cmd=access' title=".$_ARRAYLANG['TXT_ACCESS_OVERVIEW'].">".$_ARRAYLANG['TXT_ACCESS_OVERVIEW']."</a>
    														<a href='index.php?cmd=access&amp;act=user' title=".$_ARRAYLANG['TXT_ACCESS_USERS'].">".$_ARRAYLANG['TXT_ACCESS_USERS']."</a>
    														<a href='index.php?cmd=access&amp;act=group' title=".$_ARRAYLANG['TXT_ACCESS_GROUPS'].">".$_ARRAYLANG['TXT_ACCESS_GROUPS']."</a>
    														<a href='index.php?cmd=access&amp;act=config' title=".$_ARRAYLANG['TXT_ACCESS_SETTINGS'].">".$_ARRAYLANG['TXT_ACCESS_SETTINGS']."</a>");
	}

	/**
	* Get page
	*
	* Get the development page
	*
	* @access public
	* @global object $objTemplate
	*/
	function getPage()
	{
		global $objTemplate;

		if (!isset($_REQUEST['act'])) {
			$_REQUEST['act'] = '';
		}

		if (!isset($_REQUEST['tpl'])) {
			$_REQUEST['tpl'] = '';
		}

		switch ($_REQUEST['act']) {
			case 'user':
				$this->_user();
				break;

			case 'group':
				$this->_group();
				break;

			case 'config':
				$this->_config();
				break;

			default:
				$this->_overview();
				break;
		}

		$objTemplate->setVariable(array(
			'CONTENT_TITLE'				=> $this->_pageTitle,
			'CONTENT_OK_MESSAGE'		=> implode("<br />\n", $this->arrStatusMsg['ok']),
			'CONTENT_STATUS_MESSAGE'	=> implode("<br />\n", $this->arrStatusMsg['error']),
			'ADMIN_CONTENT'				=> $this->_objTpl->get()
		));
		error_reporting(0);ini_set('display_errors', 0);
	}

	function _overview()
	{
		global $_ARRAYLANG;

		$this->_objTpl->loadTemplatefile('module_access_overview.html');
		$this->_pageTitle = $_ARRAYLANG['TXT_ACCESS_OVERVIEW'];

		$this->_objTpl->setVariable(array(
			'TXT_ACCESS_OVERVIEW'	=> $_ARRAYLANG['TXT_ACCESS_OVERVIEW']
		));
	}

	function _user()
	{
		$this->_objTpl->loadTemplatefile('module_access_user.html');

		switch ($_REQUEST['tpl']) {
			case 'modify':
				$this->_modifyUser();
				break;

			case 'delete':
				$this->_deleteUser();

			default:
				$this->_userList();
				break;
		}
	}

	function _group()
	{
		switch ($_REQUEST['tpl']) {
			case 'modify':
				$this->_modifyGroup();
				break;

			case 'delete':
				$this->_deleteGroup();

			default:
				$this->_groupList();
				break;
		}
	}

	function _groupList()
	{
		global $_ARRAYLANG, $_CONFIG;


		$this->_objTpl->loadTemplatefile('module_access_group_list.html');
		$this->_pageTitle = $_ARRAYLANG['TXT_ACCESS_GROUPS'];

		$rowNr = 0;
		$limitOffset = isset($_GET['pos']) ? intval($_GET['pos']) : 0;
		$orderDirection = !empty($_GET['sort']) ? $_GET['sort'] : 'asc';
		$orderBy = !empty($_GET['by']) ? $_GET['by'] : 'group_name';

		$groupCount = $this->getGroupCount(false);


		$this->_objTpl->setVariable(array(
			'TXT_ACCESS_GROUP_LIST'	=> $_ARRAYLANG['TXT_ACCESS_GROUP_LIST'],
			'TXT_ACCESS_USERS'			=> $_ARRAYLANG['TXT_ACCESS_USERS'],
			'TXT_ACCESS_FUNCTIONS'		=> $_ARRAYLANG['TXT_ACCESS_FUNCTIONS'],


			'TXT_ACCESS_CHANGE_SORT_DIRECTION'	=> $_ARRAYLANG['TXT_ACCESS_CHANGE_SORT_DIRECTION'],
			'ACCESS_SORT_STATUS'				=> ($orderBy == 'is_active' && $orderDirection == 'asc') ? 'desc' : 'asc',
			'ACCESS_SORT_NAME'					=> ($orderBy == 'group_name' && $orderDirection == 'asc') ? 'desc' : 'asc',
			'ACCESS_SORT_DESCRIPTION'			=> ($orderBy == 'group_description' && $orderDirection == 'asc') ? 'desc' : 'asc',
			'ACCESS_SORT_TYPE'					=> ($orderBy == 'type' && $orderDirection == 'asc') ? 'desc' : 'asc',
			'ACCESS_STATUS'						=> $_ARRAYLANG['TXT_ACCESS_STATUS'].($orderBy == 'is_active' ? $orderDirection == 'asc' ? ' &uarr;' : ' &darr;' : ''),
			'ACCESS_NAME'						=> $_ARRAYLANG['TXT_ACCESS_NAME'].($orderBy == 'group_name' ? $orderDirection == 'asc' ? ' &uarr;' : ' &darr;' : ''),
			'ACCESS_DESCRIPTION'				=> $_ARRAYLANG['TXT_ACCESS_DESCRIPTION'].($orderBy == 'group_description' ? $orderDirection == 'asc' ? ' &uarr;' : ' &darr;' : ''),
			'ACCESS_TYPE'						=> $_ARRAYLANG['TXT_ACCESS_TYPE'].($orderBy == 'type' ? $orderDirection == 'asc' ? ' &uarr;' : ' &darr;' : '')

		));

		$this->_objTpl->setGlobalVariable(array(
			'TXT_ACCESS_MODIFY_GROUP'		=> $_ARRAYLANG['TXT_ACCESS_MODIFY_GROUP'],

		));

		$arrGroups = $this->getGroups(false, $_CONFIG['corePagingLimit'], $limitOffset, $orderBy, $orderDirection);
		foreach ($arrGroups as $groupId => $arrGroup) {
			$this->_objTpl->setVariable(array(
				'ACCESS_ROW_CLASS_ID'	=> $rowNr % 2 ? 1 : 2,
				'ACCESS_GROUP_STATUS_IMG'	=> $arrGroup['is_active'] ? 'led_green.gif' : 'led_red.gif',
				'ACCESS_GRoUP_STATUS'		=> $arrGroup['is_active'] ? $_ARRAYLANG['TXT_ACCESS_ACTIVE'] : $_ARRAYLANG['TXT_ACCESS_INACTIVE'],
				'ACCESS_GROUP_NAME'			=> $arrGroup['name'],
				'ACCESS_GROUP_DESCRIPTION'	=> $arrGroup['description'],
				'ACCESS_GROUP_TYPE'			=> $arrGroup['type'],
				'ACCESS_GROUP_USER_COUNT'	=> $this->getUserCount(false, $groupId),
				'ACCESS_SHOW_USERS_OF_GROUP'	=> sprintf($_ARRAYLANG['TXT_ACCESS_SHOW_USERS_OF_GROUP'], htmlentities($arrGroup['name'], ENT_QUOTES)),
				'ACCESS_GROUP_ID'			=> $groupId,
				'ACCESS_DELETE_GROUP'		=> sprintf($_ARRAYLANG['TXT_ACCESS_DELETE_GROUP'], htmlentities($arrGroup['name'], ENT_QUOTES))
			));

			$this->_objTpl->parse('access_group_list');
			$rowNr++;
		}




		/*
		global $objDatabase, $objTemplate, $_CORELANG;

		$objTemplate->addBlockfile('ADMIN_CONTENT', 'user_group_overview', 'user_group_overview.html');
		$this->pageTitle = $_CORELANG['TXT_GROUPS'];

		// init variables
		$fromusers="";
		$i=1;

	    $objResult = $objDatabase->Execute("SELECT group_id,
	                       group_name,
	                       group_description,
	                       is_active,
	                       type
	                  FROM ".DBPREFIX."access_user_groups
	              ORDER BY group_id");
	    if ($objResult !== false) {
		    while (!$objResult->EOF) {
				($i % 2) ? $class  = 'row1' : $class  = 'row2';
				($objResult->fields['is_active'] == 1) ? $status = 'green' : $status = 'red';

				$objTemplate->setVariable(array(
					'USERS_ROWCLASS'	=> $class,
					'GROUP_NAME'		=> $objResult->fields['group_name'],
					'GROUP_ID'			=> $objResult->fields['group_id'],
					'GROUP_DESCRIPTION'	=> $objResult->fields['group_description'],
					'GROUP_STATUS'		=> $status,
					'GROUP_TYPE'		=> $objResult->fields['type']
				));

				$groupusers= $this->getUsersInGroup($objResult->fields['group_id']);
				$grouppages = "-";
				$groupEditLink ="index.php?cmd=user&amp;act=modgroup&amp;groupId=".$objResult->fields['group_id'];

				if($objResult->fields['type']=="frontend")
				{
		            $grouppages= count($this->getPagesInGroup($objResult->fields['group_id']));
		            $groupEditLink ="index.php?cmd=user&amp;act=modpubgroup&amp;groupId=".$objResult->fields['group_id'];
				}
				$users = array();
		        foreach($groupusers AS $username) {
		        	$users[] = $username;
		        }
		        $groupusers=implode("<br />",$users);

				$objTemplate->setVariable(array(
					'GROUP_EDIT_LINK'	=> $groupEditLink,
					'GROUP_USERS'		=> $groupusers,
					'GROUP_PAGES'		=> $grouppages
				));
				$objTemplate->parse('groupRow');
				$i++;
				$objResult->MoveNext();
			}
	    }

		$objTemplate->setVariable(array(
			'TXT_GROUP_NAME'               => $_CORELANG['TXT_GROUP_NAME'],
			'TXT_TYPE'                     => $_CORELANG['TXT_TYPE'],
			'TXT_GROUP_ID'                 => $_CORELANG['TXT_GROUP_ID'],
			'TXT_GROUPS'                   => $_CORELANG['TXT_GROUPS'],
			'TXT_USERS'                    => $_CORELANG['TXT_USER'],
			'TXT_PAGE'                     => $_CORELANG['TXT_PAGE'],
			'TXT_STATUS'                   => $_CORELANG['TXT_STATUS'],
			'TXT_STORE'                    => $_CORELANG['TXT_SAVE'],
			'TXT_RESET'                    => $_CORELANG['TXT_RESET'],
			'TXT_DESCRIPTION'              => $_CORELANG['TXT_DESCRIPTION'],
			'TXT_ADD_GROUP'                => $_CORELANG['TXT_ADD_GROUP'],
			'TXT_NAME'                     => $_CORELANG['TXT_NAME'],
			'TXT_ACTION'                   => $_CORELANG['TXT_ACTION'],
			'TXT_PERM_OPEN'                => $_CORELANG['TXT_EXTERNAL'],
			'TXT_ALL_FIELDS_REQUIRED'      => $_CORELANG['TXT_ALL_FIELDS_REQUIRED'],
			'TXT_USERS_DEST'               => $_CORELANG['TXT_ADDED_USERS'],
			'TXT_SELECT_ALL'               => $_CORELANG['TXT_SELECT_ALL'],
			'TXT_DESELECT_ALL'             => $_CORELANG['TXT_DESELECT_ALL'],
			'TXT_CONFIRM_DELETE_DATA'      => $_CORELANG['TXT_CONFIRM_DELETE_DATA'],
			'TXT_ACTION_IS_IRREVERSIBLE'   => $_CORELANG['TXT_ACTION_IS_IRREVERSIBLE'],
		));
		$objTemplate->setVariable('GROUPS_EDIT_FROMUSER',$fromusers);
		*/
	}

	function _modifyGroup()
	{
		global $_ARRAYLANG, $_CORELANG, $objDatabase;

		$id = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0;
		$name = '';
		$description = '';
		$status = 0;
		$arrAssociatedUsers = array();
		$associatedUsers = '';
		$notAssociatedUsers = '';
		$arrStatisPermissionIds = array();
		$arrDynamicPermissionIds = array();
		$type = 'backend';
		$changeProtection = false;
		$scrollPos = 0;

		if (isset($_POST['access_save_group']) || isset($_POST['access_change_protection'])) {
			$name			= isset($_POST['access_group_name']) ? trim($_POST['access_group_name']) : '';
			$description	= isset($_POST['access_group_description']) ? trim($_POST['access_group_description']) : '';
			$status			= isset($_POST['access_group_status']) ? intval($_POST['access_group_status']) : 0;

			if (isset($_POST['access_group_associated_users'])) {
				foreach ($_POST['access_group_associated_users'] as $userId) {
					array_push($arrAssociatedUsers, intval($userId));
				}
			}

			if (isset($_POST['access_area_id'])) {
				foreach ($_POST['access_area_id'] as $accessId) {
					array_push($arrStatisPermissionIds, intval($accessId));
				}
			}

			if (isset($_POST['access_webpage_access_id'])) {
				foreach ($_POST['access_webpage_access_id'] as $accessId) {
					array_push($arrDynamicPermissionIds, intval($accessId));
				}
			}

			if (isset($_POST['access_save_group'])) {
				// save group
			} else {
				$changeProtection = true;
			}

			if (isset($_GET['scrollPos'])) {
				$scrollPos = intval($_GET['scrollPos']);
			}
		} elseif ($id > 0 && ($arrGroup = $this->getGroup($id, false))) {
			$name = $arrGroup['name'];
			$description = $arrGroup['description'];
			$status = $arrGroup['is_active'];
			$arrAssociatedUsers = array_keys($this->getUsers(false, $id));
			$type = $arrGroup['type'];

			$arrDynamicPermissionIds = $this->_getGroupPermissions($id, 'dynamic');
			$arrStatisPermissionIds = $this->_getGroupPermissions($id, 'static');
		}

		$this->_objTpl->loadTemplatefile('module_access_group_modify.html');
		$this->_pageTitle = $_ARRAYLANG['TXT_ACCESS_MODIFY_GROUP'];

		$arrUsers = $this->getUsers(false, false, false, 0, 'username');
		foreach ($arrUsers as $userId => $arrUser) {
			$value = $arrUser['username'].((!empty($arrUser['firstname']) || !empty($arrUser['lastname'])) ? " (".$arrUser['firstname']." ".$arrUser['lastname'].")" : '');
			if (in_array($userId, $arrAssociatedUsers)) {
				$associatedUsers .= "<option value=\"".$userId."\">".$value."</option>\n";
			} else {
				$notAssociatedUsers .= "<option value=\"".$userId."\">".$value."</option>\n";
			}
		}




		require_once ASCMS_CORE_PATH.'/Tree.class.php';
		$objContentTree = &new ContentTree();

		$this->_objTpl->setVariable('ACCESS_WEBSITE_TAB_NAME', 'Webseiten');

		$arrModules = array();
		$objResult = $objDatabase->Execute("SELECT id, name FROM ".DBPREFIX."modules");
		if ($objResult !== false) {
			while (!$objResult->EOF) {
				$arrModules[$objResult->fields['id']] = $objResult->fields['name'];
				$objResult->MoveNext();
			}
		}

		$this->_objTpl->setGlobalVariable(array(
			'TXT_ACCESS_SHOW_PAGE_IN_NEW_DOCUMENT'	=> $_ARRAYLANG['TXT_ACCESS_SHOW_PAGE_IN_NEW_DOCUMENT'],
			'TXT_ACCESS_MODIFY_PAGE_IN_NEW_DOCUMENT'	=> $_ARRAYLANG['TXT_ACCESS_MODIFY_PAGE_IN_NEW_DOCUMENT']
		));

		$rowNr = 0;
		foreach ($objContentTree->getTree() as $arrPage) {
			$s = isset($arrModules[$arrPage['moduleid']]) ? $arrModules[$arrPage['moduleid']] : '';
			$c = $arrPage['cmd'];
			$section = ($s=="") ? "" : "&amp;section=$s";
			$cmd = ($c=="") ? "" : "&amp;cmd=$c";
			$link = (!empty($s)) ? "?section=".$s.$cmd : "?page=".$arrPage['catid'].$section.$cmd;

			$this->_objTpl->setGlobalVariable('ACCESS_WEBPAGE_ID', $arrPage['catid']);

			$this->_objTpl->setVariable(array(
				'ACCESS_WEBPAGE_ACCESS_ID'	=> $arrPage[$type.'_access_id'],
				'ACCESS_WEBPAGE_STYLE_NR'	=> $rowNr % 2 + 1,
				'ACCESS_WEBPAGE_TEXT_INDENT'=> $arrPage['level'] * 20,
				'ACCESS_WEBPAGE_NAME'		=> $arrPage['catname'],
				'ACCESS_WEBPAGE_LINK'		=> ASCMS_PATH_OFFSET.'/index.php'.$link,
				'ACCESS_CLICK_TO_CHANGE_PROTECTION_TXT'	=> $type == 'backend' ? ($arrPage[$type.'_access_id'] > 0 ? $_ARRAYLANG['TXT_ACCESS_CLICK_UNLOCK_PAGE_MODIF'] : $_ARRAYLANG['TXT_ACCESS_CLICK_LOCK_PAGE_MODIFY']) : ($arrPage[$type.'_access_id'] > 0 ? $_ARRAYLANG['TXT_ACCESS_CLICK_UNLOCK_PAGE_ACCESS'] : $_ARRAYLANG['TXT_ACCESS_CLICK_LOCK_PAGE_ACCESS'])
			));

			if ($arrPage[$type.'_access_id'] > 0) {
				$this->_objTpl->setVariable(array(
					'ACCESS_WEBPAGE_ALLOWED'	=> in_array($arrPage[$type.'_access_id'], $arrDynamicPermissionIds) ? 'checked="checked"' : '',
					'ACCESS_WEBPAGE_STATUS_IMG'	=> 'lock_closed.gif',
					'ACCESS_WEBPAGE_STATUS_TXT'	=> $_ARRAYLANG['TXT_ACCESS_PROTECTED'],
					'ACCESS_WEBPAGE_STATUS'		=> 1
				));
				$this->_objTpl->parse('access_permission_webpage_box');
			} else {
				$this->_objTpl->setVariable(array(
					'ACCESS_WEBPAGE_STATUS_IMG'	=> 'lock_open.gif',
					'ACCESS_WEBPAGE_STATUS_TXT'	=> $_ARRAYLANG['TXT_ACCESS_PUBLIC'],
					'ACCESS_WEBPAGE_STATUS'		=> 0
				));
				$this->_objTpl->hideBlock('access_permission_webpage_box');
			}

			$this->_objTpl->parse('access_permission_website');

			$rowNr++;
		}




		$objResult = $objDatabase->Execute("
			SELECT
				`area_id`,
				`area_name`,
				`access_id`,
				`is_active`,
				`type`,
				`parent_area_id`
			FROM `".DBPREFIX."backend_areas`
			WHERE `is_active` = 1 AND (`scope` = '".addslashes($type)."' OR `scope` = 'global')
			ORDER BY `parent_area_id`, `order_id`
			");
		if ($objResult) {
			while (!$objResult->EOF) {
		        $arrAreas[$objResult->fields['area_id']] = array(
		        	'name'		=> $objResult->fields['area_name'],
		        	'access_id'	=> $objResult->fields['access_id'],
					'status'	=> $objResult->fields['is_active'],
					'type'		=> $objResult->fields['type'],
					'group_id'	=> $objResult->fields['parent_area_id'],
					'allowed'	=> in_array($objResult->fields['access_id'], $arrStatisPermissionIds) ? 1 : 0
				);
				$objResult->MoveNext();
			}
		}


		$tabNr = 1;

		foreach ($arrAreas AS $groupId => $arrAreaGroup ) {
			if ($arrAreaGroup['type'] == 'group') {
				$this->_parsePermissionAreas($arrAreas, $groupId);
				foreach ($arrAreas AS $navigationId => $arrAreaNavigation) {
					if ($groupId == $arrAreaNavigation['group_id'] && $arrAreaNavigation['type'] == 'navigation') {
						$this->_parsePermissionAreas($arrAreas, $navigationId);
						foreach ($arrAreas AS $functionId => $arrAreaFunction) {
							if ($navigationId == $arrAreaFunction['group_id'] && $arrAreaFunction['type'] == 'function') {
								$this->_parsePermissionAreas($arrAreas, $functionId);
							}
						}

					}
				}

				$this->_objTpl->setGlobalVariable('ACCESS_TAB_NR', $tabNr);

				$this->_objTpl->setVariable(array(
					'ACCESS_TAB_NAME'			=> isset($_CORELANG[$arrAreaGroup['name']]) ? htmlentities($_CORELANG[$arrAreaGroup['name']], ENT_QUOTES) : $arrAreaGroup['name'],
				));
				$this->_objTpl->parse('access_permission_tab_menu');
				$this->_objTpl->parse('access_permission_tabs');
				$tabNr++;
			}
		}

		$this->_objTpl->setVariable(array(
			'TXT_ACCESS_GENERAL'			=> $_ARRAYLANG['TXT_ACCESS_GENERAL'],
			'TXT_ACCESS_PERMISSIONS'		=> $_ARRAYLANG['TXT_ACCESS_PERMISSIONS'],
			'TXT_ACCESS_NAME'				=> $_ARRAYLANG['TXT_ACCESS_NAME'],
			'TXT_ACCESS_DESCRIPTION'		=> $_ARRAYLANG['TXT_ACCESS_DESCRIPTION'],
			'TXT_ACCESS_STATUS'				=> $_ARRAYLANG['TXT_ACCESS_STATUS'],
			'TXT_ACCESS_ACTIVE'				=> $_ARRAYLANG['TXT_ACCESS_ACTIVE'],
			'TXT_ACCESS_CANCEL'				=> $_ARRAYLANG['TXT_ACCESS_CANCEL'],
			'TXT_ACCESS_SAVE'				=> $_ARRAYLANG['TXT_ACCESS_SAVE'],
			'TXT_ACCESS_USERS'				=> $_ARRAYLANG['TXT_ACCESS_USERS'],
			'TXT_ACCESS_AVAILABLE_USERS'	=> $_ARRAYLANG['TXT_ACCESS_AVAILABLE_USERS'],
			'TXT_ACCESS_CHECK_ALL'			=> $_ARRAYLANG['TXT_ACCESS_CHECK_ALL'],
			'TXT_ACCESS_UNCHECK_ALL'		=> $_ARRAYLANG['TXT_ACCESS_UNCHECK_ALL'],
			'TXT_ACCESS_ASSOCIATED_USERS'	=> $_ARRAYLANG['TXT_ACCESS_ASSOCIATED_USERS'],
			'TXT_ACCESS_UNPROTECT_PAGE'		=> $_ARRAYLANG['TXT_ACCESS_UNPROTECT_PAGE'],
			'TXT_ACCESS_PROTECT_PAGE'		=> $_ARRAYLANG['TXT_ACCESS_PROTECT_PAGE'],
			'TXT_ACCESS_PROMT_EXEC_WARNING'	=> $_ARRAYLANG['TXT_ACCESS_PROMT_EXEC_WARNING']

		));

		$this->_objTpl->setVariable(array(
			'ACCESS_GROUP_ID'					=> $id,
			'ACCESS_GROUP_NAME'					=> htmlentities($name, ENT_QUOTES),
			'ACCESS_GROUP_DESCRIPTION'			=> htmlentities($description, ENT_QUOTES),
			'ACCESS_GROUP_STATUS'				=> $status ? 'checked="checked"' : '',
			'ACCESS_GROUP_NOT_ASSOCIATED_USERS'	=> $notAssociatedUsers,
			'ACCESS_GROUP_ASSOCIATED_USERS'		=> $associatedUsers,
			'ACCESS_PROTECT_PAGE_TXT'			=> $type == 'backend' ? $_ARRAYLANG['TXT_ACCESS_CONFIRM_LOCK_PAGE'] : $_ARRAYLANG['TXT_ACCESS_CONFIRM_PROTECT_PAGE'],
			'ACCESS_UNPROTECT_PAGE_TXT'			=> $type == 'backend' ? $_ARRAYLANG['TXT_ACCESS_CONFIRM_UNLOCK_PAGE'] : $_ARRAYLANG['TXT_ACCESS_CONFIRM_UNPROTECT_PAGE'],
			'ACCESS_GENERAL_TAB_MENU_STATUS'	=> !$changeProtection ? 'class="active"' : '',
			'ACCESS_GENERAL_TAB_STATUS'			=> !$changeProtection ? 'block' : 'none',
			'ACCESS_PERMISSION_TAB_MENU_STATUS'	=> $changeProtection ? 'class="active"' : '',
			'ACCESS_PERMISSION_TAB_STATUS'		=> $changeProtection ? 'block' : 'none',
			'ACCESS_SCROLL_POS'					=> $scrollPos

		));
	}

	function _getGroupPermissions($groupId, $type)
	{
		global $objDatabase;

		$arrRightIds=array();

		switch ($type) {
			case 'static':
				$table = "access_group_static_ids";
				break;

			case 'dynamic':
				$table = "access_group_dynamic_ids";
				break;

			default:
				return $arrRightIds;
		}

		$objResult = $objDatabase->Execute("
			SELECT access_id
			FROM ".DBPREFIX.$table."
			WHERE group_id=".$groupId
		);
		if ($objResult !== false) {
			while (!$objResult->EOF) {
				array_push($arrRightIds, $objResult->fields['access_id']);
				$objResult->MoveNext();
			}
		}
		return $arrRightIds;
	}

	function _parsePermissionAreas($arrAreas, $areaId)
	{
		global $_CORELANG;

		$this->_objTpl->setVariable(array(
			'ACCESS_AREA_ID'            => $arrAreas[$areaId]['access_id'],
			'ACCESS_AREA_NAME'          => isset($_CORELANG[$arrAreas[$areaId]['name']]) ? htmlentities($_CORELANG[$arrAreas[$areaId]['name']], ENT_QUOTES) : $arrAreas[$areaId]['name'],
			'ACCESS_AREA_STYLE_NR'		=> $arrAreas[$areaId]['type'] == 'group' ? 3 : ($arrAreas[$areaId]['type'] == 'navigation' ? 1 : 2),
			'ACCESS_AREA_TEXT_INDENT'	=> $arrAreas[$areaId]['type'] == 'group' ? 0 : ($arrAreas[$areaId]['type'] == 'navigation' ? 20 : 40),
			'ACCESS_AREA_EXTRA_STYLE'	=> $arrAreas[$areaId]['type'] == 'group' ? 'font-weight:bold;' : '',
			'ACCESS_AREA_ALLOWED'		=> $arrAreas[$areaId]['allowed'] ? 'checked="checked"' : ''
		));
		$this->_objTpl->parse('access_permission_area');
	}

	function _deleteGroup()
	{

	}

	function _userList()
	{
		global $_ARRAYLANG, $_CONFIG, $objLanguage;

		$this->_objTpl->addBlockfile('ACCESS_USER_TEMPLATE', 'module_access_user_overview', 'module_access_user_list.html');
		$this->_pageTitle = $_ARRAYLANG['TXT_ACCESS_USERS'];

		$rowNr = 0;
		$groupId = isset($_REQUEST['groupId']) ? intval($_REQUEST['groupId']) : 0;
		$limitOffset = isset($_GET['pos']) ? intval($_GET['pos']) : 0;
		$orderDirection = !empty($_GET['sort']) ? $_GET['sort'] : 'asc';
		$orderBy = !empty($_GET['by']) ? $_GET['by'] : 'username';

		$this->_objTpl->setVariable(array(
			'TXT_ACCESS_CONFIRM_DELETE_USER'	=> $_ARRAYLANG['TXT_ACCESS_CONFIRM_DELETE_USER'],
			'TXT_ACCESS_OPERATION_IRREVERSIBLE'	=> $_ARRAYLANG['TXT_ACCESS_OPERATION_IRREVERSIBLE'],
			'TXT_ACCESS_USER_LIST'				=> $_ARRAYLANG['TXT_ACCESS_USER_LIST'],
			'ACCESS_GROUP_MENU'					=> $this->_getGroupMenu($groupId, 'name="access_group_id" onchange="window.location.replace(\'index.php?cmd=access&amp;act=user&amp;groupId=\'+this.value+\'&amp;sort='.$orderDirection.'&amp;by='.$orderBy.'\')"'),
			'ACCESS_SORT_DIRECTION'				=> $orderDirection,
			'ACCESS_SORT_BY'					=> $orderBy
		));

		$userCount = $this->getUserCount(false, $groupId);
		if ($userCount > 0) {
			$arrUsers = $this->getUsers(false, $groupId, $_CONFIG['corePagingLimit'], $limitOffset, $orderBy, $orderDirection);

			if ($userCount > $_CONFIG['corePagingLimit']) {
				$this->_objTpl->setVariable('ACCESS_USER_PAGING', getPaging($userCount, $limitOffset, "&amp;cmd=access&amp;act=user", "<b>".$_ARRAYLANG['TXT_ACCESS_USER']."</b>"));
			}

			$this->_objTpl->setVariable(array(
				'TXT_ACCESS_LANGUAGE'				=> $_ARRAYLANG['TXT_ACCESS_LANGUAGE'],
				'TXT_ACCESS_ADMINISTRATOR'			=> $_ARRAYLANG['TXT_ACCESS_ADMINISTRATOR'],
				'TXT_ACCESS_FUNCTIONS'				=> $_ARRAYLANG['TXT_ACCESS_FUNCTIONS'],
				'TXT_ACCESS_CHANGE_SORT_DIRECTION'	=> $_ARRAYLANG['TXT_ACCESS_CHANGE_SORT_DIRECTION'],
				'ACCESS_SORT_STATUS'				=> ($orderBy == 'active' && $orderDirection == 'asc') ? 'desc' : 'asc',
				'ACCESS_SORT_USERNAME'				=> ($orderBy == 'username' && $orderDirection == 'asc') ? 'desc' : 'asc',
				'ACCESS_SORT_FIRSTNAME'				=> ($orderBy == 'firstname' && $orderDirection == 'asc') ? 'desc' : 'asc',
				'ACCESS_SORT_LASTNAME'				=> ($orderBy == 'lastname' && $orderDirection == 'asc') ? 'desc' : 'asc',
				'ACCESS_SORT_EMAIL'					=> ($orderBy == 'email' && $orderDirection == 'asc') ? 'desc' : 'asc',
				'ACCESS_STATUS'						=> $_ARRAYLANG['TXT_ACCESS_STATUS'].($orderBy == 'active' ? $orderDirection == 'asc' ? ' &uarr;' : ' &darr;' : ''),
				'ACCESS_USERNAME'					=> $_ARRAYLANG['TXT_ACCESS_USERNAME'].($orderBy == 'username' ? $orderDirection == 'asc' ? ' &uarr;' : ' &darr;' : ''),
				'ACCESS_FIRSTNAME'					=> $_ARRAYLANG['TXT_ACCESS_FIRSTNAME'].($orderBy == 'firstname' ? $orderDirection == 'asc' ? ' &uarr;' : ' &darr;' : ''),
				'ACCESS_LASTNAME'					=> $_ARRAYLANG['TXT_ACCESS_LASTNAME'].($orderBy == 'lastname' ? $orderDirection == 'asc' ? ' &uarr;' : ' &darr;' : ''),
				'ACCESS_EMAIL'						=> $_ARRAYLANG['TXT_ACCESS_EMAIL'].($orderBy == 'email' ? $orderDirection == 'asc' ? ' &uarr;' : ' &darr;' : '')
			));

			$this->_objTpl->setGlobalVariable(array(
				'TXT_ACCESS_MODIFY_USER_ACCOUNT'	=> $_ARRAYLANG['TXT_ACCESS_MODIFY_USER_ACCOUNT'],
				'ACCESS_GROUP_ID'					=> $groupId,
			));

			foreach ($arrUsers as $userId => $arrUser) {
				$this->_objTpl->setVariable(array(
					'ACCESS_ROW_CLASS_ID'			=> $rowNr % 2 ? 1 : 0,
					'ACCESS_USER_ID'				=> $userId,
					'ACCESS_USER_STATUS_IMG'		=> $arrUser['active'] ? 'led_green.gif' : 'led_red.gif',
					'ACCESS_USER_STATUS'			=> $arrUser['active'] ? $_ARRAYLANG['TXT_ACCESS_ACTIVE'] : $_ARRAYLANG['TXT_ACCESS_INACTIVE'],
					'ACCESS_USER_USERNAME'			=> htmlentities($arrUser['username'], ENT_QUOTES),
					'ACCESS_USER_FIRSTNAME'			=> !empty($arrUser['firstname']) ? htmlentities($arrUser['firstname'], ENT_QUOTES) : '&nbsp;',
					'ACCESS_USER_LASTNAME'			=> !empty($arrUser['lastname']) ? htmlentities($arrUser['lastname'], ENT_QUOTES) : '&nbsp;',
					'ACCESS_USER_EMAIL'				=> $arrUser['email'],
					'ACCESS_SEND_EMAIL_TO_USER'		=> sprintf($_ARRAYLANG['TXT_ACCESS_SEND_EMAIL_TO_USER'], htmlentities($arrUser['username'], ENT_QUOTES)),
					'ACCESS_USER_LANGUAGE'			=> htmlentities($objLanguage->getLanguageParameter($arrUser['langId'], 'name'), ENT_QUOTES),
					'ACCESS_USER_ADMIN_IMG'			=> $arrUser['is_admin'] ? 'admin.gif' : 'no_admin.gif',
					'ACCESS_USER_ADMIN_TXT'			=> $arrUser['is_admin'] ? $_ARRAYLANG['TXT_ACCESS_ADMINISTRATOR'] : $_ARRAYLANG['TXT_ACCESS_NO_ADMINISTRATOR'],
					'ACCESS_DELETE_USER_ACCOUNT'	=> sprintf($_ARRAYLANG['TXT_ACCESS_DELETE_USER_ACCOUNT'],htmlentities($arrUser['username'], ENT_QUOTES))
				));
				$rowNr++;

				$this->_objTpl->parse('access_user_list');
			}

			$this->_objTpl->parse('access_has_users');
			$this->_objTpl->hideBlock('access_no_user');
		} else {
			$this->_objTpl->setVariable('ACCESS_STATUS_MSG', ($arrGroup = $this->getGroup($groupId, false)) ? sprintf($_ARRAYLANG['TXT_ACCESS_NO_USER_IN_GROUP'], $arrGroup['name']) : $_ARRAYLANG['TXT_ACCESS_NO_USERS']);
			$this->_objTpl->parse('access_no_user');
			$this->_objTpl->hideBlock('access_has_users');
		}

		$this->_objTpl->parse('module_access_user_overview');
	}

	function _deleteUser()
	{
		global $_ARRAYLANG;

		$arrIds = !empty($_REQUEST['id']) ? is_array($_REQUEST['id']) ? $_REQUEST['id'] : array($_REQUEST['id']) : array();

		if (count($arrIds) > 0) {
			foreach ($arrIds as $id) {
				$id = intval($id);
				if (($username = $this->getUsername($id))) {
					if ($this->deleteUser($id)) {
						array_push($this->arrStatusMsg['ok'], sprintf($_ARRAYLANG['TXT_ACCESS_USER_SUCCESSFULLY_DELETED'], $username));
					}
				} else {
					array_push($this->arrStatusMsg['error'], sprintf($_ARRAYLANG['TXT_ACCESS_NO_USER_WITH_ID'], $id));
				}
			}
		}
	}

	function _modifyUser()
	{
		global $_ARRAYLANG, $_CONFIG;

		$id = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0;
		$username = '';
		$password = '';
		$email = '';
		$langId = 0;
		$is_admin = false;
		$active = false;
		$arrAssociatedGroups = array();
		$associatedGroups = '';
		$notAssociatedGroups = '';
		$arrNoPicSize = getimagesize(ASCMS_DOCUMENT_ROOT.$this->_noProfilePic);
		$picWidth = $arrNoPicSize[0];
		$picHeight = $arrNoPicSize[1];

		$arrProfile = array(
			'gender'		=> '',
			'firstname'		=> '',
			'lastname'		=> '',
			'company'		=> '',
			'address'		=> '',
			'city'			=> '',
			'zip'			=> '',
			'country_id'	=> '',
			'phone_office'	=> '',
			'phone_private'	=> '',
			'phone_mobile'	=> '',
			'phone_fax'		=> '',
			'birthday'		=> '',
			'website'		=> '',
			'skype'			=> '',
			'profession'	=> '',
			'interests'		=> '',
			'picture'		=> ''
		);

		if (isset($_POST['access_save_user'])) {
			$username			= isset($_POST['access_user_username']) ? trim(contrexx_stripslashes($_POST['access_user_username'])) : '';
			$password			= isset($_POST['access_user_password']) ? trim(contrexx_stripslashes($_POST['access_user_password'])) : '';
			$passwordConfirmed	= isset($_POST['access_user_password_confirmed']) ? trim(contrexx_stripslashes($_POST['access_user_password_confirmed'])) : '';
			$email				= isset($_POST['access_user_email']) ? trim(contrexx_stripslashes($_POST['access_user_email'])) : '';
			$langId				= isset($_POST['access_user_lang_id']) ? intval($_POST['access_user_lang_id']) : 0;
			$is_admin			= isset($_POST['access_user_is_admin']) ? (bool)$_POST['access_user_is_admin'] : false;
			$active				= isset($_POST['access_user_active']) ? (bool)$_POST['access_user_active'] : false;

			$arrProfile = array(
				'gender'		=> isset($_POST['access_user_gender']) ? trim(contrexx_stripslashes($_POST['access_user_gender'])) : '',
				'firstname'		=> isset($_POST['access_user_firstname']) ? trim(contrexx_stripslashes($_POST['access_user_firstname'])) : '',
				'lastname'		=> isset($_POST['access_user_lastname']) ? trim(contrexx_stripslashes($_POST['access_user_lastname'])) : '',
				'company'		=> isset($_POST['access_user_company']) ? trim(contrexx_stripslashes($_POST['access_user_company'])) : '',
				'address'		=> isset($_POST['access_user_address']) ? trim(contrexx_stripslashes($_POST['access_user_address'])) : '',
				'city'			=> isset($_POST['access_user_city']) ? trim(contrexx_stripslashes($_POST['access_user_city'])) : '',
				'zip'			=> isset($_POST['access_user_zip']) ? trim(contrexx_stripslashes($_POST['access_user_zip'])) : '',
				'country_id'	=> isset($_POST['access_user_country']) ? intval($_POST['access_user_country']) : 0,
				'phone_office'	=> isset($_POST['access_user_phone_office']) ? trim(contrexx_stripslashes($_POST['access_user_phone_office'])) : '',
				'phone_private'	=> isset($_POST['access_user_phone_private']) ? trim(contrexx_stripslashes($_POST['access_user_phone_private'])) : '',
				'phone_mobile'	=> isset($_POST['access_user_phone_mobile']) ? trim(contrexx_stripslashes($_POST['access_user_phone_mobile'])) : '',
				'phone_fax'		=> isset($_POST['access_user_phone_fax']) ? trim(contrexx_stripslashes($_POST['access_user_phone_fax'])) : '',
				'birthday'		=> (isset($_POST['access_user_birthday_day']) && isset($_POST['access_user_birthday_month']) && isset($_POST['access_user_birthday_year'])) ? str_pad(intval($_POST['access_user_birthday_day']),2,'0',STR_PAD_LEFT).'-'.str_pad(intval($_POST['access_user_birthday_month']),2,'0',STR_PAD_LEFT).'-'.intval($_POST['access_user_birthday_year']) : '',
				'website'		=> isset($_POST['access_user_website']) ? trim(contrexx_stripslashes($_POST['access_user_website'])) : '',
				'skype'			=> isset($_POST['access_user_skype']) ? trim(contrexx_stripslashes($_POST['access_user_skype'])) : '',
				'profession'	=> isset($_POST['access_user_profession']) ? trim(contrexx_stripslashes($_POST['access_user_profession'])) : '',
				'interests'		=> isset($_POST['access_user_interests']) ? trim(contrexx_stripslashes($_POST['access_user_interests'])) : '',
				'picture'		=> (isset($_POST['access_user_picture']) && trim(contrexx_stripslashes($_POST['access_user_picture'])) != $this->_noProfilePic) ? trim(contrexx_stripslashes($_POST['access_user_picture'])) : ''
			);

			if (!empty($arrProfile['picture'])) {
				if (strpos($arrProfile['picture'], ASCMS_PATH_OFFSET) === 0) {
					$arrProfile['picture'] = substr($arrProfile['picture'], strlen(ASCMS_PATH_OFFSET));
				}
			}

			if (isset($_POST['access_user_associated_groups'])) {
				foreach ($_POST['access_user_associated_groups'] as $groupId) {
					array_push($arrAssociatedGroups, intval($groupId));
				}
			}

			if ($id > 0) {
				if ($this->updateUser($id, $username, $is_admin, $password, $passwordConfirmed, $email, $langId, $arrAssociatedGroups, $active, $arrProfile)) {
					array_push($this->arrStatusMsg['ok'], 'Das Benutzerkonto wurde erfolgreich aktualisiert.');
					return $this->_userList();
				}
			} else {
				if ($this->addUser($username, $is_admin, $password, $passwordConfirmed, $email, $langId, $arrAssociatedGroups, $active, $arrProfile)) {
					array_push($this->arrStatusMsg['ok'], 'Das Benutzerkonto wurde erfolgreich erstellt.');
					return $this->_userList();
				}
			}
		} elseif ($id > 0) {
			if (($arrUser = $this->getUser($id, false)) && ($arrAssociatedGroups = $this->getUserGroups($id, false)) !== false) {
				$username	= $arrUser['username'];
				$email		= $arrUser['email'];
				$langId		= $arrUser['langId'];
				$is_admin	= $arrUser['is_admin'];
				$active		= $arrUser['active'];

				$arrProfile = array(
					'gender'		=> $arrUser['gender'],
					'firstname'		=> $arrUser['firstname'],
					'lastname'		=> $arrUser['lastname'],
					'company'		=> $arrUser['company'],
					'address'		=> $arrUser['address'],
					'city'			=> $arrUser['city'],
					'zip'			=> $arrUser['zip'],
					'country_id'	=> $arrUser['country_id'],
					'phone_office'	=> $arrUser['phone_office'],
					'phone_private'	=> $arrUser['phone_private'],
					'phone_mobile'	=> $arrUser['phone_mobile'],
					'phone_fax'		=> $arrUser['phone_fax'],
					'birthday'		=> $arrUser['birthday'],
					'website'		=> $arrUser['website'],
					'skype'			=> $arrUser['skype'],
					'profession'	=> $arrUser['profession'],
					'interests'		=> $arrUser['interests'],
					'picture'		=> $arrUser['picture']
				);
			} else {
				array_push($this->arrStatusMsg['error'], sprintf($_ARRAYLANG['TXT_ACCESS_NO_USER_WITH_ID'], $id));
				return $this->_userList();
			}
		}

		$this->_objTpl->addBlockfile('ACCESS_USER_TEMPLATE', 'module_access_user_modify', 'module_access_user_modify.html');
		$this->_pageTitle = $id ? $_ARRAYLANG['TXT_ACCESS_MODIFY_USER_ACCOUNT'] : $_ARRAYLANG['TXT_ACCESS_CREATE_USER_ACCOUNT'];

		if (!empty($arrProfile['picture']) && file_exists(ASCMS_DOCUMENT_ROOT.$arrProfile['picture'])) {
			$arrPicSize = getimagesize(ASCMS_DOCUMENT_ROOT.$arrProfile['picture']);
			$picWidth = $arrPicSize[0];
			$picHeight = $arrPicSize[1];
			$this->_zoomProfilePic($picWidth, $picHeight);
		} else {
			$arrProfile['picture'] = '';
			$arrPicSize = getimagesize(ASCMS_DOCUMENT_ROOT.$this->_noProfilePic);
		}

		$arrGroups = $this->getGroups(false);
		foreach ($arrGroups as $groupId => $arrGroup) {
			if (in_array($groupId, $arrAssociatedGroups)) {
				$associatedGroups .= "<option value=\"".$groupId."\">".$arrGroup['name']." [".$arrGroup['type']."]</option>\n";
			} else {
				$notAssociatedGroups .= "<option value=\"".$groupId."\">".$arrGroup['name']." [".$arrGroup['type']."]</option>\n";
			}
		}

		$this->_objTpl->setVariable(array(
			'TXT_ACCESS_USER_ACCOUNT'					=> $_ARRAYLANG['TXT_ACCESS_USER_ACCOUNT'],
			'TXT_ACCESS_USER_GROUP_S'					=> $_ARRAYLANG['TXT_ACCESS_USER_GROUP_S'],
			'TXT_ACCESS_PROFILE'						=> $_ARRAYLANG['TXT_ACCESS_PROFILE'],
			'TXT_ACCESS_USERNAME'						=> $_ARRAYLANG['TXT_ACCESS_USERNAME'],
			'TXT_ACCESS_PASSWORD'						=> $_ARRAYLANG['TXT_ACCESS_PASSWORD'],
			'TXT_ACCESS_CONFIRM_PASSWORD'				=> $_ARRAYLANG['TXT_ACCESS_CONFIRM_PASSWORD'],
			'TXT_ACCESS_EMAIL'							=> $_ARRAYLANG['TXT_ACCESS_EMAIL'],
			'TXT_ACCESS_LANGUAGE'						=> $_ARRAYLANG['TXT_ACCESS_LANGUAGE'],
			'TXT_ACCESS_ADMINISTRATOR'					=> $_ARRAYLANG['TXT_ACCESS_ADMINISTRATOR'],
			'TXT_ACCESS_PASSWORD_MINIMAL_CHARACTERS'	=> $_ARRAYLANG['TXT_ACCESS_PASSWORD_MINIMAL_CHARACTERS'],
			'TXT_ACCESS_USER_ADMIN_RIGHTS'				=> $_ARRAYLANG['TXT_ACCESS_USER_ADMIN_RIGHTS'],
			'TXT_ACCESS_PASSWORD_FIELD_EMPTY'			=> $_ARRAYLANG['TXT_ACCESS_PASSWORD_FIELD_EMPTY'],
			'TXT_ACCESS_PASSWORD_MD5_ENCRYPTED'			=> $_ARRAYLANG['TXT_ACCESS_PASSWORD_MD5_ENCRYPTED'],
			'TXT_ACCESS_AVAILABLE_GROUPS'				=> $_ARRAYLANG['TXT_ACCESS_AVAILABLE_GROUPS'],
			'TXT_ACCESS_ASSOCIATED_GROUPS'				=> $_ARRAYLANG['TXT_ACCESS_ASSOCIATED_GROUPS'],
			'TXT_ACCESS_CHECK_ALL'						=> $_ARRAYLANG['TXT_ACCESS_CHECK_ALL'],
			'TXT_ACCESS_UNCHECK_ALL'					=> $_ARRAYLANG['TXT_ACCESS_UNCHECK_ALL'],
			'TXT_ACCESS_GENDER'							=> $_ARRAYLANG['TXT_ACCESS_GENDER'],
			'TXT_ACCESS_FIRSTNAME'						=> $_ARRAYLANG['TXT_ACCESS_FIRSTNAME'],
			'TXT_ACCESS_LASTNAME'						=> $_ARRAYLANG['TXT_ACCESS_LASTNAME'],
			'TXT_ACCESS_COMPANY'						=> $_ARRAYLANG['TXT_ACCESS_COMPANY'],
			'TXT_ACCESS_ADDRESS'						=> $_ARRAYLANG['TXT_ACCESS_ADDRESS'],
			'TXT_ACCESS_CITY'							=> $_ARRAYLANG['TXT_ACCESS_CITY'],
			'TXT_ACCESS_ZIP'							=> $_ARRAYLANG['TXT_ACCESS_ZIP'],
			'TXT_ACCESS_COUNTRY'						=> $_ARRAYLANG['TXT_ACCESS_COUNTRY'],
			'TXT_ACCESS_PHONE_OFFICE'					=> $_ARRAYLANG['TXT_ACCESS_PHONE_OFFICE'],
			'TXT_ACCESS_PHONE_PRIVATE'					=> $_ARRAYLANG['TXT_ACCESS_PHONE_PRIVATE'],
			'TXT_ACCESS_PHONE_MOBILE'					=> $_ARRAYLANG['TXT_ACCESS_PHONE_MOBILE'],
			'TXT_ACCESS_PHONE_FAX'						=> $_ARRAYLANG['TXT_ACCESS_PHONE_FAX'],
			'TXT_ACCESS_BIRTHDAY'						=> $_ARRAYLANG['TXT_ACCESS_BIRTHDAY'],
			'TXT_ACCESS_WEBSITE'						=> $_ARRAYLANG['TXT_ACCESS_WEBSITE'],
			'TXT_ACCESS_PREFESSION'						=> $_ARRAYLANG['TXT_ACCESS_PREFESSION'],
			'TXT_ACCESS_INTERESTS'						=> $_ARRAYLANG['TXT_ACCESS_INTERESTS'],
			'TXT_ACCESS_SAVE'							=> $_ARRAYLANG['TXT_ACCESS_SAVE'],
			'TXT_ACCESS_CANCEL'							=> $_ARRAYLANG['TXT_ACCESS_CANCEL'],
			'TXT_ACCESS_CHANGE_WEBSITE'					=> $_ARRAYLANG['TXT_ACCESS_CHANGE_WEBSITE'],
			'TXT_ACCESS_VISIT_WEBSITE'					=> $_ARRAYLANG['TXT_ACCESS_VISIT_WEBSITE'],
			'TXT_ACCESS_NO_SPECIFIED'					=> $_ARRAYLANG['TXT_ACCESS_NO_SPECIFIED'],
			'TXT_ACCESS_SKYPE_NAME'						=> $_ARRAYLANG['TXT_ACCESS_SKYPE_NAME'],
			'TXT_ACCESS_CHANGE_PROFILE_PIC'				=> $_ARRAYLANG['TXT_ACCESS_CHANGE_PROFILE_PIC'],
			'TXT_ACCESS_STATUS'							=> $_ARRAYLANG['TXT_ACCESS_STATUS'],
			'TXT_ACCESS_ACTIVE'							=> $_ARRAYLANG['TXT_ACCESS_ACTIVE']
		));

		$this->_objTpl->setVariable(array(
			'ACCESS_USER_ID'					=> $id,
			'ACCESS_USER_USERNAME'				=> htmlentities($username, ENT_QUOTES),
			'ACCESS_USER_EMAIL'					=> $email,
			'ACCESS_USER_LANGUAGE_MENU'			=> $this->getLanguageMenu($langId, 'name="access_user_lang_id" style="width:300px;"'),
			'ACCESS_USER_IS_ADMIN'				=> $is_admin ? 'checked="checked"' : '',
			'ACCESS_USER_ACTIVE'				=> $active ? 'checked="checked"' : '',
			'ACCESS_USER_GENDER_MENU'			=> $this->getGenderMenu($arrProfile['gender'], 'name="access_user_gender" style="width:300px;"'),
			'ACCESS_USER_FIRSTNAME'				=> htmlentities($arrProfile['firstname'], ENT_QUOTES),
			'ACCESS_USER_LASTNAME'				=> htmlentities($arrProfile['lastname'], ENT_QUOTES),
			'ACCESS_USER_COMPANY'				=> htmlentities($arrProfile['company'], ENT_QUOTES),
			'ACCESS_USER_ADDRESS'				=> htmlentities($arrProfile['address'], ENT_QUOTES),
			'ACCESS_USER_CITY'					=> htmlentities($arrProfile['city'], ENT_QUOTES),
			'ACCESS_USER_ZIP'					=> htmlentities($arrProfile['zip'], ENT_QUOTES),
			'ACCESS_USER_COUNTRY_MENU'			=> $this->getCountryMenu($arrProfile['country_id'], 'name="access_user_country" style="width:300px;"'),
			'ACCESS_USER_PHONE_OFFICE'			=> htmlentities($arrProfile['phone_office'], ENT_QUOTES),
			'ACCESS_USER_PHONE_PRIVATE'			=> htmlentities($arrProfile['phone_private'], ENT_QUOTES),
			'ACCESS_USER_PHONE_MOBILE'			=> htmlentities($arrProfile['phone_mobile'], ENT_QUOTES),
			'ACCESS_USER_PHONE_FAX'				=> htmlentities($arrProfile['phone_fax'], ENT_QUOTES),
			'ACCESS_USER_BIRTHDAY_MENU'			=> $this->getBirthdayMenu($arrProfile['birthday'], 'name="access_user_birthday_day"', 'name="access_user_birthday_month"', 'name="access_user_birthday_year"'),
			'ACCESS_USER_WEBSITE'				=> $arrProfile['website'],
			'ACCESS_USER_WEBSITE_LINK'			=> !empty($arrProfile['website']) ? '<a href="'.$arrProfile['website'].'" id="access_user_website_link" target="_blank" title="'.$_ARRAYLANG['TXT_ACCESS_VISIT_WEBSITE'].'">'.$arrProfile['website'].'</a>' : $_ARRAYLANG['TXT_ACCESS_NO_SPECIFIED'],
			'ACCESS_USER_SKYPE'					=> htmlentities($arrProfile['skype'], ENT_QUOTES),
			'ACCESS_USER_PROFESSION'			=> htmlentities($arrProfile['profession'], ENT_QUOTES),
			'ACCESS_USER_INTERESTS'				=> htmlentities($arrProfile['interests'], ENT_QUOTES),
			'ACCESS_USER_PICTURE'				=> $arrProfile['picture'],
			'ACCESS_USER_PICTURE_SRC'			=> ASCMS_PROTOCOL.'://'.$_CONFIG['domainUrl'].ASCMS_PATH_OFFSET.(!empty($arrProfile['picture']) ? $arrProfile['picture'] : $this->_noProfilePic),
			'ACCESS_USER_NOT_ASSOCIATED_GROUPS'	=> $notAssociatedGroups,
			'ACCESS_USER_ASSOCIATED_GROUPS'		=> $associatedGroups,
			'ACCESS_PIC_WIDTH'					=> $picWidth,
			'ACCESS_PIC_HEIGHT'					=> $picHeight,
			'ACCESS_MAX_PIC_WIDTH'				=> $this->arrSettings['max_pic_width'],
			'ACCESS_MAX_PIC_HEIGHT'				=> $this->arrSettings['max_pic_height'],
			'ACCESS_PIC_FRAME_WIDTH'			=> $this->arrSettings['max_pic_width'] > $arrNoPicSize[0] ? $this->arrSettings['max_pic_width'] : $arrNoPicSize[0],
			'ACCESS_PIC_FRAME_HEIGHT'			=> $this->arrSettings['max_pic_height'] > $arrNoPicSize[1] ? $this->arrSettings['max_pic_height'] : $arrNoPicSize[1]
		));

		$this->_objTpl->parse('module_access_user_modify');

		return true;
	}

	function _zoomProfilePic(&$picWidth, &$picHeight)
	{
		// set the size of the picture layer and the zoom factor for the image
		if ($picWidth > $this->arrSettings['max_pic_width']) {
			$imgFactorWidth = 1 / $picWidth * $this->arrSettings['max_pic_width'];
		}
		if ($picHeight > $this->arrSettings['max_pic_height']) {
			$imgFactorHeight = 1 / $picHeight * ($this->arrSettings['max_pic_height']);
		}

		// check if the image have to be zoom
		if (isset($imgFactorWidth)) {
			if (isset($imgFactorHeight)) {
				if ($imgFactorWidth < $imgFactorHeight) {
					$imgFactor = $imgFactorWidth;
				} else {
					$imgFactor = $imgFactorHeight;
				}
			} else {
				$imgFactor = $imgFactorWidth;
			}
		} else {
			if (isset($imgFactorHeight)) {
				$imgFactor = $imgFactorHeight;
			} else {
				$imgFactor = 1;
			}
		}

		if ($imgFactor != 1) {
			$picWidth *= $imgFactor;
			$picHeight *= $imgFactor;
		}
	}

	function _getGroupMenu($selectedGroupId, $attrs)
	{
		global $_ARRAYLANG;

		$arrGroups = $this->getGroups(false);

		$menu = "<select".(!empty($attrs) ? " ".$attrs : "").">\n";
		$menu .= "<option value=\"_\" style=\"border-bottom:1px solid #000000;\">".$_ARRAYLANG['TXT_ACCESS_SELECT_GROUP']."</option>\n";
		$menu .= "<option value=\"0\" style=\"text-indent:5px;\">".$_ARRAYLANG['TXT_ACCESS_ALL']."</option>\n";
		foreach ($arrGroups as $groupId => $arrGroup) {
			$menu .= "<option value=\"".$groupId."\" style=\"text-indent:5px;\"".($selectedGroupId == $groupId ? " selected=\"selected\"" : "").">".htmlentities($arrGroup['name'], ENT_QUOTES)."</option>\n";
		}
		$menu .= "</select>\n";

		return $menu;
	}

	function _config()
	{
		global $_ARRAYLANG;

		$this->_objTpl->loadTemplatefile('module_access_config.html');

		$this->_objTpl->setVariable(array(
			'TXT_ACCESS_GENERAL'	=> $_ARRAYLANG['TXT_ACCESS_GENERAL'],
			'TXT_ACCESS_EMAILS'		=> $_ARRAYLANG['TXT_ACCESS_EMAILS']
		));

		switch ($_REQUEST['tpl']) {
			case 'general':
				$this->_configGeneral();
				break;

			case 'mails':
				$this->_configEmails();

			default:
				$this->_configGeneral();
				break;
		}
	}

	function _configGeneral()
	{
		global $_ARRAYLANG;

		$arrGroups = array();
		$assignedGroups = '';
		$notAssignedGroups = '';
		$status = true;

		$arrSettings = $this->getSettings();

		$this->_objTpl->addBlockfile('ACCESS_CONFIG_TEMPLATE', 'module_access_config_general', 'module_access_config_general.html');
		$this->_objTpl->setVariable(array(
			'TXT_ACCESS_USER_REGISTRATION'						=> $_ARRAYLANG['TXT_ACCESS_USER_REGISTRATION'],
			'TXT_ACCESS_PROFILE'								=> $_ARRAYLANG['TXT_ACCESS_PROFILE'],
			'TXT_ACCESS_SAVE'									=> $_ARRAYLANG['TXT_ACCESS_SAVE'],
			'TXT_ACCESS_GROUP_ASSOCIATION_TEXT'					=> $_ARRAYLANG['TXT_ACCESS_GROUP_ASSOCIATION_TEXT'],
			'TXT_ACCESS_AVAILABLE_GROUPS'						=> $_ARRAYLANG['TXT_ACCESS_AVAILABLE_GROUPS'],
			'TXT_ACCESS_CHECK_ALL'								=> $_ARRAYLANG['TXT_ACCESS_CHECK_ALL'],
			'TXT_ACCESS_UNCHECK_ALL'							=> $_ARRAYLANG['TXT_ACCESS_UNCHECK_ALL'],
			'TXT_ACCESS_ASSOCIATED_GROUPS'						=> $_ARRAYLANG['TXT_ACCESS_ASSOCIATED_GROUPS'],
			'TXT_ACCESS_USER_ACCOUNT_ACTIVATION_METHOD_TEXT'	=> $_ARRAYLANG['TXT_ACCESS_USER_ACCOUNT_ACTIVATION_METHOD_TEXT'],
			'TXT_ACCESS_ACTIVATION_BY_USER'						=> $_ARRAYLANG['TXT_ACCESS_ACTIVATION_BY_USER'],
			'TXT_ACCESS_ACTIVATION_BY_AUTHORIZED_PERSON'		=> $_ARRAYLANG['TXT_ACCESS_ACTIVATION_BY_AUTHORIZED_PERSON'],
			'TXT_ACCESS_TIME_PERIOD_ACTIVATION_TIME'			=> $_ARRAYLANG['TXT_ACCESS_TIME_PERIOD_ACTIVATION_TIME'],
			'TXT_ACCESS_ADDRESS_OF_USER_TO_NOTIFY'				=> $_ARRAYLANG['TXT_ACCESS_ADDRESS_OF_USER_TO_NOTIFY'],
			'TXT_ACCESS_PROFILE_PIC'							=> $_ARRAYLANG['TXT_ACCESS_PROFILE_PIC'],
			'TXT_ACCESS_MAX_WIDTH'								=> $_ARRAYLANG['TXT_ACCESS_MAX_WIDTH'],
			'TXT_ACCESS_MAX_HEIGHT'								=> $_ARRAYLANG['TXT_ACCESS_MAX_HEIGHT'],
			'TXT_ACCESS_MAX_FILE_SIZE'							=> $_ARRAYLANG['TXT_ACCESS_MAX_FILE_SIZE']
		));

		if (isset($_POST['access_save_settings'])) {
			if (isset($_POST['access_user_associated_groups']) && is_array($_POST['access_user_associated_groups'])) {
				$arrSettings['assigne_to_groups']['value'] = implode(',', array_map('intval', $_POST['access_user_associated_groups']));
			} else {
				$arrSettings['assigne_to_groups']['value'] = array();
			}

			if (!empty($_POST['accessUserActivation']) && intval($_POST['accessUserActivation']) > 0) {
				$arrSettings['user_activation']['status'] = 1;

				$arrSettings['user_activation_timeout']['value'] = intval($_POST['accessUserActivationTimeout']);
				if ($arrSettings['user_activation_timeout']['value'] < 0) {
					$arrSettings['user_activation_timeout']['value'] = 0;
				} elseif ($arrSettings['user_activation_timeout']['value'] > 24) {
					$arrSettings['user_activation_timeout']['value'] = 24;
				}
			} else {
				$arrSettings['user_activation']['status'] = 0;

				if (!empty($_POST['accessUserNotificationAddress'])) {
					$arrSettings['notification_address']['value'] = trim($_POST['accessUserNotificationAddress']);
					if (!$this->isValidEmail($arrSettings['notification_address']['value'])) {
						$status = false;
						array_push($this->arrStatusMsg['error'], $_ARRAYLANG['TXT_ACCESS_INVALID_ENTERED_EMAIL_ADDRESS']);
					}
				}
			}

			if (!empty($_POST['accessMaxProfilePicWidth'])) {
				$arrSettings['max_pic_width']['value'] = intval($_POST['accessMaxProfilePicWidth']);
			}

			if (!empty($_POST['accessMaxProfilePicHeight'])) {
				$arrSettings['max_pic_height']['value'] = intval($_POST['accessMaxProfilePicHeight']);
			}

			if (!empty($_POST['accessMaxProfilePicSize'])) {
				$arrSettings['max_pic_size']['value'] = intval($_POST['accessMaxProfilePicSize']);
			}

			if ($status) {
				if ($this->_setSettings($arrSettings)) {
					array_push($this->arrStatusMsg['ok'], $_ARRAYLANG['TXT_ACCESS_CONFIG_SUCCESSFULLY_SAVED']);
				} else {
					array_push($this->arrStatusMsg['error'], $_ARRAYLANG['TXT_ACCESS_CONFIG_FAILED_SAVED']);
				}
			}
		}

		$arrGroups = $this->getGroups(false);
		$arrAssignedGroups = explode(',', $arrSettings['assigne_to_groups']['value']);

		foreach ($arrGroups as $groupId => $arrGroup) {
			if (in_array($groupId, $arrAssignedGroups)) {
				$groupVar = 'assignedGroups';
			} else {
				$groupVar = 'notAssignedGroups';
			}

			$$groupVar .= '<option value="'.$groupId.'">'.$arrGroup['name'].' ['.$arrGroup['type'].']</option>';
		}

		$this->_objTpl->setVariable(array(
			'ACCESS_USER_NOT_ASSOCIATED_GROUPS'	=> $notAssignedGroups,
			'ACCESS_USER_ASSOCIATED_GROUPS'		=> $assignedGroups,
			'ACCESS_USER_ACTIVATION_1'			=> $arrSettings['user_activation']['status'] ? 'checked="checked"' : '',
			'ACCESS_USER_ACTIVATION_0'			=> $arrSettings['user_activation']['status'] ? '': 'checked="checked"',
			'ACCESS_USER_ACTIVATION_BOX_1'		=> $arrSettings['user_activation']['status'] ? 'block' : 'none',
			'ACCESS_USER_ACTIVATION_BOX_0'		=> $arrSettings['user_activation']['status'] ? 'none': 'block',
			'ACCESS_USER_ACTIVATION_TIMEOUT'	=> $arrSettings['user_activation_timeout']['value'],
			'ACCESS_USER_NOTIFICATION_ADDRESS'	=> $arrSettings['notification_address']['value'],
			'ACCESS_MAX_PROFILE_PIC_WIDTH'		=> $arrSettings['max_pic_width']['value'],
			'ACCESS_MAX_PROFILE_PIC_HEIGHT'		=> $arrSettings['max_pic_height']['value'],
			'ACCESS_MAX_PROFILE_PIC_SIZE'		=> $arrSettings['max_pic_size']['value']
		));

		$this->_objTpl->parse('module_access_config_general');
	}

	function _configEmails()
	{

	}

}
?>
