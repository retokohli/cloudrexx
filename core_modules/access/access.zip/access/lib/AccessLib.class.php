<?php
/**
* Class access library
*
* Provides common methodes for the access module
*
* @copyright CONTREXX CMS - Astalavista IT Engineering GmbH Thun
* @author Astalavista Development Team <thun@astalvista.ch>
* @module access
* @modulegroups core_modules
* @access private
* @version 1.0.0
*/
class AccessLib {
	var $_arrConfig = array();


	function _initConfig($reload = false)
	{
		global $objDatabase;

		if (empty($this->_arrConfig) || $reload) {
			$objConfig = $objDatabase->Execute('SELECT `key`, `value`, `status` `'.DBPREFIX.'access_settings');

			if ($objConfig !== false) {
				while (!$objConfig->EOF) {
					$this->_arrConfig[$objResult->fields['key']] = array(
						'value'		=> $objResult->fields['value'],
						'status'	=> $objResult->fields['status']
					);
					$objResult->MoveNext();
				}
			}
		}
	}
}
?>
