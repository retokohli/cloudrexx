<?php
/**
* Class NewsML
*
* NewsML interface
*
* @copyright CONTREXX CMS - Astalavista IT Engineering GmbH Thun
* @author Astalavista Development Team <thun@astalvista.ch>
* @module FRAMEWORK
* @modulegroups lib
* @access public
* @version 1.0.0
*/
class NewsML
{
	var $_xmlDocument;

	var $_currentXmlElement;
	var $_arrParentXmlElement = array();
	var $arrTplPlaceholders = array();
	var $arrCategories = array();
	var $_arrProviders = array();
	var $_arrDocuments = array();
	var $_arrExcludeFiles = array('.', '..', 'index.php', 'index.html');
	var $_inNITF = false;
	var $_xmlContentHTMLTag = '';
	var $_inParagraph = false;
	var $_tmpParagraph = array();
	var $_xmlParserCharacterEncoding = 'ISO-8859-1';
	var $standardMessageCount = 10;
	var $administrate = false;

	function NewsML($administrate = false)
	{
		$this->__construct($administrate);
	}

	function __construct($administrate = false)
	{
		global $objDatabase;

		$this->administrate = $administrate;
		$this->initCategories();
	}

	/**
	* Set news
	*
	* Set the news message of the newsML category
	*
	* @access public
	* @param array $arrNewsMLCategories
	* @param string &$code
	* @global object $objDatabase
	*/
	function setNews($arrNewsMLCategories, &$code)
	{
		global $objDatabase;

		$arrTplPlaceholders = $this->arrTplPlaceholders;

		if (count($arrTplPlaceholders)>0) {
			foreach ($arrNewsMLCategories as $category) {
				$arrMatches = preg_grep('/^'.$category.'$/i', $arrTplPlaceholders);

				if (count($arrMatches)>0) {
					$categoryIds = array_keys($arrMatches);
					$categoryId = $categoryIds[0];
					$this->readDocuments($categoryId);
					$code = str_replace("{NEWSML_".$category."}", $this->parseDocuments($categoryId), $code);
				}
			}
		}
	}

	/**
	* Parse NewsML documents
	*
	* Parse the NewsML documents of the category $categoryId and return the parsed html code
	*
	* @access public
	* @param integer $categoryId
	* @global array $_CORELANG
	* @return string html code
	*/
	function parseDocuments($categoryId)
	{
		global $_CORELANG;

		$arrDocuments = $this->getDocuments($categoryId);
		$code = $this->arrCategories[$categoryId]['template'];

		$arrWeekDays = explode(',', $_CORELANG['TXT_DAY_ARRAY']);
		$arrMonths = explode(',', $_CORELANG['TXT_MONTH_ARRAY']);

		$output = "";
		$nr = 0;
		if (count($arrDocuments)>0) {
			foreach ($arrDocuments as $documentId => $arrDocument) {
				if ($nr == $this->arrCategories[$categoryId]['limit']) {
					break;
				}

				$text = str_replace(array('<p>', '</p>'), '', $arrDocument['dataContent']);
				$date = $arrWeekDays[date('w', $arrDocument['thisRevisionDate'])].', '.date('j', $arrDocument['thisRevisionDate']).'. '.$arrMonths[date('n', $arrDocument['thisRevisionDate'])-1].' '.date('Y', $arrDocument['thisRevisionDate']).' / '.date('G:i', $arrDocument['thisRevisionDate']).' h';
				$dateLong = date(ASCMS_DATE_FORMAT, $arrDocument['thisRevisionDate']);
				$dateShort = date(ASCMS_DATE_SHORT_FORMAT, $arrDocument['thisRevisionDate']);
				$output .= str_replace(
					array(
						'{ID}',
						'{TITLE}',
						'{DATE}',
						'{LONG_DATE}',
						'{SHORT_DATE}',
						'{TEXT}'
					),
					array(
						$documentId,
						$arrDocument['headLine'],
						$date,
						$dateLong,
						$dateShort,
						substr($text,0,100).'...'
					),
					$code
				);

				if (isset($arrDocument['photo'])) {
					if ($arrDocument['photo']['width'] > 100 || $arrDocument['photo']['height'] > 75) {
						$factorWidth = 100 / $arrDocument['photo']['width'];
						$factorHeight = 75 / $arrDocument['photo']['height'];

						if ($factorWidth < $factorHeight) {
							$arrDocument['photo']['width'] = 100;
							$arrDocument['photo']['height'] *= $factorWidth;
						} else {
							$arrDocument['photo']['width'] *= $factorHeight;
							$arrDocument['photo']['height'] = 75;
						}
					}

					$output = str_replace(
						array(
							'{IMAGE_SOURCE}',
							'{IMAGE_LABEL}',
							'{IMAGE_WIDTH}',
							'{IMAGE_HEIGHT}'
						),
						array(
							$arrDocument['photo']['source'],
							$arrDocument['photo']['label'],
							$arrDocument['photo']['width'],
							$arrDocument['photo']['height']
						),
						$output
					);
					$output = preg_replace('/<--\sBEGIN\simage\s-->/', '', $output);
					$output = preg_replace('/<--\sEND\simage\s-->/', '', $output);
				} else {
					$output = preg_replace('/<--\sBEGIN\simage[\s\S]*END\simage\s-->/', '', $output);
				}


				$nr++;
			}
		}
		return $output;
	}

	/**
	* Initialize newsML categories
	*
	* Initializ the newsML categories
	*
	* @access private
	* @global object $objDatabase
	*/
	function initCategories()
	{
		global $objDatabase;

		$this->arrCategories = array();
		$this->arrTplPlaceholders = array();

		$objCategories = $objDatabase->Execute("SELECT
			cat.id,
			cat.name,
			cat.subjectCodes,
			cat.showSubjectCodes,
			cat.template,
			cat.`limit`,
			provider.name AS providerName,
			provider.path,
			provider.providerId,
			cat.auto_update
			FROM ".DBPREFIX."module_feed_newsml_categories AS cat, ".DBPREFIX."module_feed_newsml_providers AS provider
			WHERE cat.providerId=provider.id");
		if ($objCategories !== false) {
			while (!$objCategories->EOF) {
				$this->arrCategories[$objCategories->fields['id']] = array(
					'name'				=> $objCategories->fields['name'],
					'subjectCodes'		=> explode(',', $objCategories->fields['subjectCodes']),
					'showSubjectCodes'	=> $objCategories->fields['showSubjectCodes'],
					'template'			=> $objCategories->fields['template'],
					'limit'				=> $objCategories->fields['limit'],
					'path'				=> $objCategories->fields['path'],
					'providerName'		=> $objCategories->fields['providerName'],
					'providerId'		=> $objCategories->fields['providerId'],
					'auto_update'		=> (bool) $objCategories->fields['auto_update']
				);

				$this->arrTplPlaceholders[$objCategories->fields['id']] = preg_replace('/\s/', '_', $objCategories->fields['name']);
				$objCategories->MoveNext();
			}
		}
	}

	/**
	* Initialize providers
	*
	* Initialize the NewsML providers
	*
	* @access private
	* @global object $objDatabase
	*/
	function _initProviders()
	{
		global $objDatabase;

		$objProviders = $objDatabase->Execute("SELECT id, name FROM ".DBPREFIX."module_feed_newsml_providers");
		if ($objProviders !== false) {
			while (!$objProviders->EOF) {
				$this->_arrProviders[$objProviders->fields['id']] = $objProviders->fields['name'];
				$objProviders->MoveNext();
			}
		}
	}

	/**
	* Get NewsML documents
	*
	* Get the NewsML documents of the category with the id $categoryId
	*
	* @access public
	* @param integer $categoryId
	* @global object $objDatabase
	* @return array Documents
	*/
	function getDocuments($categoryId)
	{
		global $objDatabase;

		$arrDocuments = array();
		$subjectCodeDelimiter = '';

		if ($this->arrCategories[$categoryId]['showSubjectCodes'] != 'all' && count($this->arrCategories[$categoryId]['subjectCodes'])>0) {
			$subjectCodeDelimiter = 'AND (';
			foreach ($this->arrCategories[$categoryId]['subjectCodes'] as $subjectCode) {
				$subjectCodeDelimiter .= 'subjectCode '.($this->arrCategories[$categoryId]['showSubjectCodes'] == 'exclude' ? '!' : ''). '='.$subjectCode.($this->arrCategories[$categoryId]['showSubjectCodes'] == 'exclude' ? ' AND ' : ' OR ');
			}
			$subjectCodeDelimiter = substr($subjectCodeDelimiter, 0, strlen($subjectCodeDelimiter)-4).')';
		}

		$objDocuments = $objDatabase->Execute("SELECT
			id,
			publicIdentifier,
			providerId,
			dateId,
			newsItemId,
			revisionId,
			thisRevisionDate,
			urgency,
			subjectCode,
			headLine,
			dataContent
			FROM ".DBPREFIX."module_feed_newsml_documents
			WHERE providerId='".$this->arrCategories[$categoryId]['providerId']."' ".$subjectCodeDelimiter."
			AND newsItemId LIKE 'brz%'
			AND urgency<5
			ORDER by dateId DESC, urgency, thisRevisionDate DESC
			".(!$this->administrate ? "LIMIT 5" : ""));
		if ($objDocuments !== false) {
			while (!$objDocuments->EOF) {
				$arrDocuments[$objDocuments->fields['id']] = array(
					'dateId'			=> $objDocuments->fields['dateId'],
					'newsItemId'		=> $objDocuments->fields['newsItemId'],
					'revisionId'		=> $objDocuments->fields['revisionId'],
					'thisRevisionDate'	=> $objDocuments->fields['thisRevisionDate'],
					'publicIdentifier'	=> $objDocuments->fields['publicIdentifier'],
					'urgency'			=> $objDocuments->fields['urgency'],
					'subjectCode'		=> $objDocuments->fields['subjectCode'],
					'headLine'			=> $objDocuments->fields['headLine'],
					'dataContent'		=> $objDocuments->fields['dataContent']
				);


					$pics = array();
					$objAssociated = $objDatabase->Execute("SELECT pId_slave FROM ".DBPREFIX."module_feed_newsml_association WHERE pId_master='".$objDocuments->fields['publicIdentifier']."' ORDER BY pId_slave DESC");
					if ($objAssociated !== false) {
						while(!$objAssociated->EOF) {
							$objPic = $objDatabase->SelectLimit("SELECT properties, source FROM ".DBPREFIX."module_feed_newsml_documents WHERE publicIdentifier LIKE '".$objAssociated->fields['pId_slave']."%' AND media_type='Photo'", 1);
							if ($objPic !== false) {
								if ($objPic->RecordCount() == 1) {
									$arrTmpProperties = explode(';', $objPic->fields['properties']);
									foreach ($arrTmpProperties as $property) {
										$arrPair = explode(':', $property);
										$arrProperties[base64_decode($arrPair[0])] = base64_decode($arrPair[1]);
									}

									$pics[$objAssociated->fields['pId_slave']] = array(
										'source'	=> ASCMS_PATH_OFFSET.$this->arrCategories[$categoryId]['path'].'/'.$objPic->fields['source'],
										'label'		=> isset($arrProperties['label']) ? $arrProperties['label'] : '',
										'width'		=> isset($arrProperties['Width']) ? $arrProperties['Width'] : '',
										'height'	=> isset($arrProperties['Height']) ? $arrProperties['Height'] : ''
									);

									if ($pics[$objAssociated->fields['pId_slave']]['width'] == 85 && $pics[$objAssociated->fields['pId_slave']]['height'] == 85) {
										$arrDocuments[$objDocuments->fields['id']]['photo'] = $pics[$objAssociated->fields['pId_slave']];
										break;
									}
								}
							}

							$objAssociated->MoveNext();
						}

						if (!isset($arrDocuments[$objDocuments->fields['id']]['photo']) && count($pics) > 0) {
							reset($pics);
							$arrDocuments[$objDocuments->fields['id']]['photo'] = current($pics);
						}

				}

				$objDocuments->MoveNext();
			}
		}

		$objDocuments = $objDatabase->Execute("SELECT
			id,
			publicIdentifier,
			providerId,
			dateId,
			newsItemId,
			revisionId,
			thisRevisionDate,
			urgency,
			subjectCode,
			headLine,
			dataContent
			FROM ".DBPREFIX."module_feed_newsml_documents
			WHERE providerId='".$this->arrCategories[$categoryId]['providerId']."' ".$subjectCodeDelimiter."
			AND newsItemId LIKE 'brz%'
			AND urgency>4
			ORDER by dateId DESC, urgency, thisRevisionDate DESC
			".(!$this->administrate ? "LIMIT ".($this->arrCategories[$categoryId]['limit']-count($arrDocuments)) : ""));
		if ($objDocuments !== false) {
			while (!$objDocuments->EOF) {
				$arrDocuments[$objDocuments->fields['id']] = array(
					'dateId'			=> $objDocuments->fields['dateId'],
					'newsItemId'		=> $objDocuments->fields['newsItemId'],
					'revisionId'		=> $objDocuments->fields['revisionId'],
					'thisRevisionDate'	=> $objDocuments->fields['thisRevisionDate'],
					'publicIdentifier'	=> $objDocuments->fields['publicIdentifier'],
					'urgency'			=> $objDocuments->fields['urgency'],
					'subjectCode'		=> $objDocuments->fields['subjectCode'],
					'headLine'			=> $objDocuments->fields['headLine'],
					'dataContent'		=> $objDocuments->fields['dataContent']


				);
				$objDocuments->MoveNext();
			}
		}

		return $arrDocuments;
	}

	/**
	* Read NewsML documents
	*
	* Read the NewsML documents of the category with the id $categoryId from its data directory
	* and delete the documents after they are inserted into the database
	*
	* @access public
	* @param integer $categoryId
	* @global object $objDatabase
	*/
	function readDocuments($categoryId)
	{
		global $objDatabase;

		$objDir = @opendir(ASCMS_DOCUMENT_ROOT.$this->arrCategories[$categoryId]['path']);
		if ($objDir) {
			$arrDocuments = array();

			while ($document = @readdir($objDir)) {
				if (!in_array($document, $this->_arrExcludeFiles) && strtolower(substr($document, -3)) == 'xml') {
					array_push($arrDocuments , $document);
				}
			}
			@closedir($objDir);

			require_once ASCMS_FRAMEWORK_PATH.'/File.class.php';
			$objFile = &new File();
			$objFile->setChmod(ASCMS_DOCUMENT_ROOT.$this->arrCategories[$categoryId]['path'],$this->arrCategories[$categoryId]['path'], '/');

			foreach ($arrDocuments as $document) {
				if ($this->_readDocument($categoryId, $document)) {
					$objFile->setChmod(ASCMS_DOCUMENT_ROOT.$this->arrCategories[$categoryId]['path'],$this->arrCategories[$categoryId]['path'], '/'.$document);
//					@copy(ASCMS_DOCUMENT_ROOT.$this->arrCategories[$categoryId]['path'].'/'.$document, ASCMS_DOCUMENT_ROOT.'/si_online_archive/'.$document);
//					@chmod(ASCMS_DOCUMENT_ROOT.'/si_online_archive/'.$document, 0644);
//					@unlink(ASCMS_DOCUMENT_ROOT.$this->arrCategories[$categoryId]['path'].'/'.$document);
				}
			}

			foreach ($this->_arrDocuments as $dateId => $arrNewsItems) {
				foreach ($arrNewsItems as $newsItemId => $arrRevisions) {
					krsort($arrRevisions, SORT_NUMERIC);
					reset($arrRevisions);
					$arrRevision = current($arrRevisions);

					$revisionUpdateStatus = isset($arrRevision['revisionUpdateStatus']) ? $arrRevision['revisionUpdateStatus'] : '';

					switch ($revisionUpdateStatus) {
					case 'A':
						$objDatabase->Execute("DELETE FROM ".DBPREFIX."module_feed_newsml_documents WHERE providerId='".$this->arrCategories[$categoryId]['providerId']."' AND dateId=".$dateId." AND newsItemId='".$newsItemId."'");
						break;

					default:
						$objDatabase->Execute("DELETE FROM ".DBPREFIX."module_feed_newsml_documents WHERE providerId='".$this->arrCategories[$categoryId]['providerId']."' AND dateId=".$dateId." AND newsItemId='".$newsItemId."' AND revisionId != ".$arrRevision['revisionId']);
						if (isset($arrRevision['dateId'])) {
							$this->_addDocument($arrRevision['publicIdentifier'], $this->arrCategories[$categoryId]['providerId'], $dateId, $newsItemId, $arrRevision['revisionId'], $arrRevision['thisRevisionDate'], $arrRevision['newsProduct'], $arrRevision['urgency'], $arrRevision['subjectCode'], $arrRevision['headLine'], $arrRevision['contentItem'], $arrRevision['associatedNewsItems']);
						}
						break;
					}
				}
			}
		}
	}

	/**
	* Add newsml document
	*
	* Add a new NewsML document to the database
	*
	* @access private
	* @param string $publicIdentifier
	* @param integer $providerId
	* @param integer $dateId
	* @param string $newsItemId
	* @param integer $revisionId
	* @param integer $thisRevisionDate
	* @param integer $urgency
	* @param integer $subjectCode
	* @param string $headLine
	* @param string $arrContentItem
	* @global object $objDatabase
	* @return boolean true on success, false on failure
	*/
	function _addDocument($publicIdentifier, $providerId, $dateId, $newsItemId, $revisionId, $thisRevisionDate, $newsProduct, $urgency, $subjectCode, $headLine, $arrContentItem, $associatedNewsItems)
	{
		global $objDatabase;

		$objResult = $objDatabase->SelectLimit("SELECT id FROM ".DBPREFIX."module_feed_newsml_documents WHERE publicIdentifier='".$publicIdentifier."'", 1);
		if ($objResult !== false && $objResult->RecordCount() == 0) {
			if ($objDatabase->Execute("INSERT INTO ".DBPREFIX."module_feed_newsml_documents (
				publicIdentifier,
				providerId,
				dateId,
				newsItemId,
				revisionId,
				thisRevisionDate,
				newsProduct,
				urgency,
				subjectCode,
				headLine
				) VALUES (
				'".$publicIdentifier."',
				'".$providerId."',
				".$dateId.",
				'".$newsItemId."',
				".$revisionId.",
				".$thisRevisionDate.",
				'".$newsProduct."',
				".$urgency.",
				".$subjectCode.",
				'".$headLine."'
				)") !== false) {

				$newsItemId = $objDatabase->Insert_ID();

				foreach ($arrContentItem as $contentItem) {
					if (isset($contentItem['source'])) {
						$isReference = true;
					} else {
						$isReference = false;
					}

					if ($objDatabase->Execute("INSERT INTO ".DBPREFIX."module_feed_newsml_content_item (`news_item_id`, `media_type`, `is_reference`) VALUES (".$newsItemId.", '".$contentItem['mediaType']."', ".$isReference.")") !== false) {
						$contentItemId = $objDatabase->Insert_ID();

						if ($isReference) {
							$objDatabase->Execute("INSERT INTO ".DBPREFIX."module_feed_newsml_content_item_source (`content_item_id`, `source`) VALUES (".$contentItemId.", '".addslashes($contentItem['source'])."')");
						} else {
							$objDatabase->Execute("INSERT INTO ".DBPREFIX."module_feed_newsml_content_item_data (`content_item_id`, `data`) VALUES (".$contentItemId.", '".addslashes($contentItem['data'])."')");
						}

						if (isset($contentItem['properties'])) {
							foreach ($contentItem['properties'] as $property => $value) {
								$objDatabase->Execute("INSERT INTO ".DBPREFIX."module_feed_newsml_content_item_property (`content_item_id`, `property`, `value`) VALUES (".$contentItemId.", '".addslashes($property)."', '".addslashes($value)."')");
							}
						}
					}
				}

				if (count(isset($associatedNewsItems)) > 0) {
					foreach ($associatedNewsItems as $associatedNewsItem) {
						$objDatabase->Execute("INSERT INTO ".DBPREFIX."module_feed_newsml_association (`pId_master`, `pId_slave`) VALUES ('".$publicIdentifier."', '".$associatedNewsItem."')");
					}
				}

				return true;
			}
		}
		return false;
	}

	/**
	* Read NewsML document
	*
	* Read the NewsML document $document of the category with the id $categoryId
	* and put it into the database
	*
	* @access private
	* @param integer $categoryId
	* @param string $document
	* @global object $objDatabase
	* @return boolean true on success, false on failure
	*/
	function _readDocument($categoryId, $document)
	{
		global $objDatabase;

		$xmlFilePath  = ASCMS_DOCUMENT_ROOT.$this->arrCategories[$categoryId]['path'].'/'.$document;

		$this->_currentXmlElement = null;
		$this->_xmlDocument = null;

		$xml_parser = xml_parser_create($this->_xmlParserCharacterEncoding);
		xml_set_object($xml_parser,$this);
		xml_set_element_handler($xml_parser,"_xmlStartTag","_xmlEndTag");
		xml_set_character_data_handler($xml_parser, "_xmlCharacterDataTag");

		$documentContent = @file_get_contents($xmlFilePath);
		if ($documentContent !== false) {
			xml_parse($xml_parser, $documentContent);
			xml_parser_free($xml_parser);

			if (isset($this->_xmlDocument['NEWSML'])) {
				if (isset($this->_xmlDocument['NEWSML']['NEWSITEM'][0])) {
					foreach ($this->_xmlDocument['NEWSML']['NEWSITEM'] as $newsItem) {
						$newsProduct = isset($this->_xmlDocument['NEWSML']['NEWSENVELOPE']['NEWSPRODUCT']['attrs']['FORMALNAME']) ? addslashes($this->_xmlDocument['NEWSML']['NEWSENVELOPE']['NEWSPRODUCT']['attrs']['FORMALNAME']) : '';
						$this->_addNewsItem($newsItem, $categoryId, $newsProduct);
					}
				} else {
					$newsProduct = isset($this->_xmlDocument['NEWSML']['NEWSENVELOPE']['NEWSPRODUCT']['attrs']['FORMALNAME']) ? addslashes($this->_xmlDocument['NEWSML']['NEWSENVELOPE']['NEWSPRODUCT']['attrs']['FORMALNAME']) : '';
					$this->_addNewsItem($this->_xmlDocument['NEWSML']['NEWSITEM'], $categoryId, $newsProduct);
				}

				return true;
			}
		}
		return false;
	}

	function _addNewsItem(&$newsItem, $categoryId, $newsProduct)
	{
		global $objDatabase;

		$newsItem = $this->_getNewsItem($newsItem);

		//$instruction = addslashes($newsItem['NEWSMANAGEMENT']['INSTRUCTION']);

		if (!isset($this->_arrDocuments[$newsItem['dateId']][$newsItem['newsItemId']])) {
			$objDocuments = $objDatabase->Execute("SELECT
				publicIdentifier,
				revisionId
				FROM ".DBPREFIX."module_feed_newsml_documents
				WHERE providerId='".$this->arrCategories[$categoryId]['providerId']."' AND dateId=".$newsItem['dateId']." AND newsItemId='".$newsItem['newsItemId']."'
				ORDER BY dateId, newsItemId, revisionId");
			if ($objDocuments !== false) {
				while (!$objDocuments->EOF) {
					$this->_arrDocuments[$newsItem['dateId']][$newsItem['newsItemId']][$objDocuments->fields['revisionId']] = array(
						'revisionId'		=> $objDocuments->fields['revisionId'],
						'publicIdentifier'	=> $objDocuments->fields['publicIdentifier']
					);
					$objDocuments->MoveNext();
				}
			}
		}

		if (!isset($this->_arrDocuments[$newsItem['dateId']][$newsItem['newsItemId']][$newsItem['revisionId']])) {
			$this->_arrDocuments[$newsItem['dateId']][$newsItem['newsItemId']][$newsItem['revisionId']] = array(
				'revisionId'			=> $newsItem['revisionId'],
				'publicIdentifier'		=> $newsItem['publicIdentifier'],
				'previousRevisionId'	=> $newsItem['previousRevisionId'],
				'revisionUpdateStatus'	=> $newsItem['revisionUpdateStatus'],
				'dateId'				=> $newsItem['dateId'],
				'newsItemId'			=> $newsItem['newsItemId'],
				'thisRevisionDate'		=> $newsItem['thisRevisionDate'],
				'newsProduct'			=> $newsProduct,
				'urgency'				=> $newsItem['urgency'],
				'associatedNewsItems'	=> isset($newsItem['associatedNewsItems']) ? $newsItem['associatedNewsItems'] : array(),
				'subjectCode'			=> $newsItem['newsComponent']['subjectCode'],
				'headLine'				=> $newsItem['newsComponent']['headLine'],
				'contentItem'			=> $this->_getContentOfNewsComponent($newsItem['newsComponent'], 'newsComponent')
			);
		}
	}

	function _getContentOfNewsComponent($newsComponent, $parentElement)
	{
		$arrContentItems = array();

		if ($parentElement == 'newsComponent') {
			foreach ($newsComponent as $element => $elementData) {
				if ($element === 'newsComponent') {
					$arrContentItems = $this->_getContentOfNewsComponent($elementData, $element);
				} elseif (is_array($elementData) && isset($elementData['contentItem'])) {
					if (!isset($arrContent)) {
						$arrContent = array();
					}
					if (isset($elementData['role'])) {
						switch ($elementData['role']) {
							case 'Main':
								if ($elementData['contentItem']['is_ref']) {
									$arrContent['source'] = $elementData['contentItem']['data'];
								} else {
									$arrContent['data'] = $elementData['contentItem']['data'];
								}
								break;

							case 'Caption':
								$arrContent['properties']['label'] = $elementData['contentItem']['data'];
								break;

							default:
								break;
						}
					} else {
						if (isset($elementData['data'])) {
							$arrContent['data'] = $elementData['data'];
						} else {
							$arrContent['data'] = $elementData['contentItem']['data'];
						}
					}

					$arrContent['mediaType'] = $elementData['contentItem']['mediaType'];

					if (isset($elementData['contentItem']['properties'])) {
						foreach ($elementData['contentItem']['properties'] as $property => $value) {
							$arrContent['properties'][$property] = $value;
						}
					}
				}
			}
			if (isset($arrContent)) {
				array_push($arrContentItems, $arrContent);
			}
		}

		return $arrContentItems;
	}

	function _getNewsItem($newsItem)
	{
		$arrNewsItem = array();

		// NewsItem identification
		$arrNewsItem['dateId'] = intval($newsItem['IDENTIFICATION']['NEWSIDENTIFIER']['DATEID']['cdata']);
		$arrNewsItem['newsItemId'] = addslashes($newsItem['IDENTIFICATION']['NEWSIDENTIFIER']['NEWSITEMID']['cdata']);
		$arrNewsItem['revisionId'] = intval($newsItem['IDENTIFICATION']['NEWSIDENTIFIER']['REVISIONID']['cdata']);
		$arrNewsItem['publicIdentifier'] = addslashes($newsItem['IDENTIFICATION']['NEWSIDENTIFIER']['PUBLICIDENTIFIER']['cdata']);
		$arrNewsItem['previousRevisionId'] = intval($newsItem['IDENTIFICATION']['NEWSIDENTIFIER']['REVISIONID']['attrs']['PREVIOUSREVISION']);
		$arrNewsItem['revisionUpdateStatus'] = $newsItem['IDENTIFICATION']['NEWSIDENTIFIER']['REVISIONID']['attrs']['UPDATE'];

		// NewsItem management
		$arrNewsItem['urgency'] = intval($newsItem['NEWSMANAGEMENT']['URGENCY']['attrs']['FORMALNAME']);
		if (preg_match('/^([0-9]{4})([0-9]{2})([0-9]{2})T([0-9]{2})([0-9]{2})([0-9]{2})/', $newsItem['NEWSMANAGEMENT']['THISREVISIONCREATED']['cdata'], $arrTime)) {
			$arrNewsItem['thisRevisionDate'] = mktime($arrTime[4], $arrTime[5], $arrTime[6], $arrTime[2], $arrTime[3], $arrTime[1]);
		} else {
			$arrNewsItem['thisRevisionDate'] = time();
		}

		if (isset($newsItem['NEWSMANAGEMENT']['ASSOCIATEDWITH'])) {
			$arrNewsItem['associatedNewsItems'] = array();
			if (isset($newsItem['NEWSMANAGEMENT']['ASSOCIATEDWITH'][0])) {
				foreach ($newsItem['NEWSMANAGEMENT']['ASSOCIATEDWITH'] as $item) {
					array_push($arrNewsItem['associatedNewsItems'], $item['attrs']['NEWSITEM']);
				}
			} else {
				array_push($arrNewsItem['associatedNewsItems'], $newsItem['NEWSMANAGEMENT']['ASSOCIATEDWITH']['attrs']['NEWSITEM']);
			}
		}

		//$instruction = addslashes($newsItem['NEWSMANAGEMENT']['INSTRUCTION']);

		// NewsItem newscomponent
		$arrNewsItem['newsComponent'] = $this->_getNewsComponent($newsItem['NEWSCOMPONENT']);

		return $arrNewsItem;
	}

	function _getNewsComponent($newsComponent)
	{
		$arrNewsComponent = array();

		if (isset($newsComponent['DESCRIPTIVEMETADATA'])) {
			$arrNewsComponent['subjectCode'] = intval($newsComponent['DESCRIPTIVEMETADATA']['SUBJECTCODE']['SUBJECT']['attrs']['FORMALNAME']);
		}

		if (isset($newsComponent['NEWSLINES'])) {
			$headLine = '';
			if (isset($newsComponent['NEWSLINES']['HEADLINE'][0])) {
				foreach ($newsComponent['NEWSLINES']['HEADLINE'] as $cdata) {
					$headLine .= addslashes($cdata);
				}
			} else {
				$headLine = addslashes($newsComponent['NEWSLINES']['HEADLINE']['cdata']);
			}

			$arrNewsComponent['headLine'] = $headLine;
		}

		if (isset($newsComponent['ROLE']['attrs']['FORMALNAME'])) {
			$arrNewsComponent['role'] = addslashes($newsComponent['ROLE']['attrs']['FORMALNAME']);
		}

		if (isset($newsComponent['CONTENTITEM'])) {
			if (isset($newsComponent['CONTENTITEM'][0])) {
				$contentItemElement = array();
				foreach ($newsComponent['CONTENTITEM'] as $contentItemElement) {
					array_push($contentItem, $this->_getContentItem($contentItemElement));
				}
			} else {
				$contentItem = $this->_getContentItem($newsComponent['CONTENTITEM']);
			}
			$arrNewsComponent['contentItem'] = $contentItem;
		} elseif (isset($newsComponent['NEWSCOMPONENT'])) {
			if (isset($newsComponent['NEWSCOMPONENT'][0])) {
				$subNewsComponent = array();
				foreach ($newsComponent['NEWSCOMPONENT'] as $newsComponentElement) {
					array_push($subNewsComponent, $this->_getNewsComponent($newsComponentElement));
				}
			} else {
				$subNewsComponent = $this->_getNewsComponent($newsComponent['NEWSCOMPONENT']);
			}
			$arrNewsComponent['newsComponent'] = $subNewsComponent;
		} elseif (isset($newsComponent['NEWSITEM'])) {
			if (isset($newsComponent['NEWSITEM'][0])) {
				$newsItem = array();
				foreach ($newsComponent['NEWSITEM'] as $newsItemElement) {
					array_push($newsItem, $this->_getNewsItem($newsItemElement));
				}
			} else {
				$newsItem = $this->_getNewsItem($newsComponent['NEWSITEM']);
			}
			$arrNewsComponent['newsItem'] = $newsItem;
		} elseif (isset($newsComponent['NEWSITEMREF'])) {
			if (isset($newsComponent['NEWSITEMREF'][0])) {
				$newsItemRef = array();
				foreach ($newsComponent['NEWSITEMREF'] as $newsItemRefElement) {
					array_push($newsItemRef, $this->_getNewsItemRef($newsItemRefElement));
				}
			} else {
				$newsItemRef = $this->_getNewsItemRef($newsComponent['NEWSITEMREF']);
			}
			$arrNewsComponent['newsItemRef'] = $newsItemRef;
		}

		return $arrNewsComponent;
	}

	function _getContentItem($contentItem)
	{
		$arrContentItem = array();

		$arrContentMediaTypes = array(
			'types'		=> array(
				'Text',
				'Graphic',
				'Photo',
				'Audio',
				'Video',
				'ComplexData'
			),
			'default'	=> 'Text'
		);

		if (isset($contentItem['FORMAT']['attrs']['FORMALNAME'])) {
			$arrContentItem['format'] = addslashes($contentItem['FORMAT']['attrs']['FORMALNAME']);
		}

		$arrContentItem['mediaType'] = (isset($contentItem['MEDIATYPE']['attrs']['FORMALNAME']) && in_array($contentItem['MEDIATYPE']['attrs']['FORMALNAME'], $arrContentMediaTypes['types'])) ? addslashes($contentItem['MEDIATYPE']['attrs']['FORMALNAME']) : $arrContentMediaTypes['default'];

		if (isset($contentItem['attrs']['HREF'])) {
			$arrContentItem['is_ref'] = true;
			$arrContentItem['data'] = $contentItem['attrs']['HREF'];
		} else {
			$arrContentItem['is_ref'] = false;
			$arrContentItem['data'] = (isset($arrContentItem['format']) && $arrContentItem['format'] == 'NITF') ? $this->_getNITF($contentItem['DATACONTENT']['NITF']) : $contentItem['DATACONTENT']['cdata'];
		}

		if (isset($contentItem['CHARACTERISTICS']['PROPERTY'])) {
			if (isset($contentItem['CHARACTERISTICS']['PROPERTY'][0])) {
				foreach ($contentItem['CHARACTERISTICS']['PROPERTY'] as $arrProperty) {
					$arrContentItem['properties'][$arrProperty['attrs']['FORMALNAME']] = $arrProperty['attrs']['VALUE'];
				}
			} else {
				$arrContentItem['properties'] = array($contentItem['CHARACTERISTICS']['PROPERTY']['attrs']['FORMALNAME'] => $contentItem['CHARACTERISTICS']['PROPERTY']['attrs']['VALUE']);
			}
		}

		return $arrContentItem;
	}

	function _getNITF($nitfContent)
	{
		$content = '';
		foreach ($nitfContent['cdata'] as $arrdata) {
			$content .= "<p>".$arrdata['data']."</p>";
		}

		return $content;
	}

	function _getNewsItemRef($newsItemRef)
	{
		return '';
	}

	/**
	* Delete NewsML document
	*
	* Delete the NewsML document with the id $documentId
	*
	* @access public
	* @param integer $documentId
	* @global object $objDatabase
	* @return boolen true on success, false on failure
	*/
	function deleteDocument($documentId)
	{
		global $objDatabase;

		$status = $objDatabase->Execute("DELETE FROM ".DBPREFIX."module_feed_newsml_documents WHERE id='".$documentId."'");
		if ($status !== false) {
			return true;
		} else {
			return false;
		}
	}

	/**
	* Delete NewsML category
	*
	* Deletethe NewsML category specified by the $categoryId
	*
	* @access public
	* @param integer $categoryId
	* @global object $objDatabase
	* @return boolean true on success, false on failure
	*/
	function deleteCategory($categoryId)
	{
		global $objDatabase;

   		if ($objDatabase->Execute("DELETE FROM ".DBPREFIX."module_feed_newsml_categories WHERE id=".$categoryId) !== false) {
   			return true;
   		} else {
   			return false;
   		}
	}

	/**
	* Add category
	*
	* Add a new NewsML category
	*
	* @access public
	* @param integer $providerId
	* @param string $categoryName
	* @param array $arrSubjectCodes
	* @param string $subjectCodeMethod
	* @param string $templateHtml
	* @param integer $msgCount
	* @global object $objDatabase
	* @return boolean true on success, false on failure
	*/
	function addCategory($providerId, $categoryName, $arrSubjectCodes, $subjectCodeMethod, $templateHtml, $msgCount)
	{
		global $objDatabase;

		if ($objDatabase->Execute("INSERT INTO ".DBPREFIX."module_feed_newsml_categories (
					providerId,
					name,
					subjectCodes,
					showSubjectCodes,
					template,
					`limit`
					) VALUES (
					".$providerId.",
					'".$categoryName."',
					'".implode(',', $arrSubjectCodes)."',
					'".$subjectCodeMethod."',
					'".$templateHtml."',
					".$msgCount.")") !== false) {
			return true;
		} else {
			return false;
		}
	}

	/**
	* Update category
	*
	* Update a NewsML category
	*
	* @access public
	* @param integer $categoryId
	* @param integer $providerId
	* @param string $categoryName
	* @param array $arrSubjectCodes
	* @param string $subjectCodeMethod
	* @param string $templateHtml
	* @param integer $msgCount
	* @global object $objDatabase
	* @return boolean true on success, false on failure
	*/
	function updateCategory($categoryId, $providerId, $categoryName, $arrSubjectCodes, $subjectCodeMethod, $templateHtml, $msgCount)
	{
		global $objDatabase;

		if ($objDatabase->Execute("UPDATE ".DBPREFIX."module_feed_newsml_categories
			SET providerId=".$providerId.",
				name='".$categoryName."',
				subjectCodes='".implode(',', $arrSubjectCodes)."',
				showSubjectCodes='".$subjectCodeMethod."',
				template='".$templateHtml."',
				`limit`=".$msgCount."
			WHERE id=".$categoryId) !== false) {
			return true;
		} else {
			return false;
		}
	}

	/**
	* Get provider menu
	*
	* Return a drop-down menu with the providers
	*
	* @access public
	* @param integer $selectedProviderId
	* @param string $attrs
	* @return string drop-down menu
	*/
	function getProviderMenu($selectedProviderId, $attrs)
	{
		$this->_initProviders();

		$menu = "<select ".$attrs.">\n";
		foreach ($this->_arrProviders as $providerId => $providerName) {
			$menu .= "<option value=\"".$providerId."\"".($providerId != $selectedProviderId ? "" : " selected=\"selected\"").">".$providerName."</option>\n";
		}
		$menu .= "</select>\n";

		return $menu;
	}

	/**
	* Get subject code methods menu
	*
	* Get subject code methods menu
	*
	* @access public
	* @param integer $categoryId
	* @param string $attrs
	* @global array $_ARRAYLANG
	* @return string menu
	*/
	function getSubjectCodesMenu($categoryId, $attrs)
	{
		global $_ARRAYLANG;

		$subjectCodeMethod = isset($this->arrCategories[$categoryId]['showSubjectCodes']) ? $this->arrCategories[$categoryId]['showSubjectCodes'] : 'all';
		$menu = "<select ".$attrs.">\n";
		$menu .= "<option value=\"all\"".($subjectCodeMethod == "all" ? " selected=\"selected\"" : "").">".$_ARRAYLANG['TXT_FEED_SHOW_ALL']."</option>\n";
		$menu .= "<option value=\"only\"".($subjectCodeMethod == "only" ? " selected=\"selected\"" : "").">".$_ARRAYLANG['TXT_FEED_ONLY_DISPLAY_SELECTED']."</option>\n";
		$menu .= "<option value=\"exclude\"".($subjectCodeMethod == "exclude" ? " selected=\"selected\"" : "").">".$_ARRAYLANG['TXT_FEED_DISPLAY_ONLY_INDICATED_ONES']."</option>\n";
		$menu .= "</select>\n";

		return $menu;
	}

	/**
	* XML parser start tag
	*
	* @access private
	* @param resource $parser
	* @param string $name
	* @param array $attrs
	*/
	function _xmlStartTag($parser,$name,$attrs)
	{
		if (isset($this->_currentXmlElement)) {
			if ($this->_inNITF) {
				if ($this->_inParagraph) {
					$this->_xmlContentHTMLTag = strtolower($name);
				} else {
					if ($name == "BODY.CONTENT") {
						$this->_inParagraph = true;
					}
				}
			} else {
				if ($name == "NITF") {
					$this->_inNITF = true;
				}

				if (!isset($this->_currentXmlElement[$name])) {
					$this->_currentXmlElement[$name] = array();
					$this->_arrParentXmlElement[$name] = &$this->_currentXmlElement;
					$this->_currentXmlElement = &$this->_currentXmlElement[$name];
				} else {
					if (!isset($this->_currentXmlElement[$name][0])) {
						$arrTmp = $this->_currentXmlElement[$name];
						unset($this->_currentXmlElement[$name]);// = array();
						$this->_currentXmlElement[$name][0] = $arrTmp;
					}

					array_push($this->_currentXmlElement[$name], array());
					$this->_arrParentXmlElement[$name] = &$this->_currentXmlElement;
					$this->_currentXmlElement = &$this->_currentXmlElement[$name][count($this->_currentXmlElement[$name])-1];
				}
			}
		} else{
			$this->_xmlDocument[$name] = array();
			$this->_currentXmlElement = &$this->_xmlDocument[$name];
		}

		if (count($attrs)>0) {
			foreach ($attrs as $key => $value) {
				$this->_currentXmlElement['attrs'][$key] = $value;
			}
		}
	}

	/**
	* XML parser character data tag
	*
	* @access private
	* @param resource $parser
	* @param string $cData
	*/
	function _xmlCharacterDataTag($parser, $cData)
	{
		$cData = trim($cData);
		if (!empty($cData)) {
			if ($this->_inParagraph) {
//				if (!empty($this->_xmlContentHTMLTag)) {
					array_push(
						$this->_tmpParagraph,
						array(
							'type'	=> $this->_xmlContentHTMLTag,
							'data'	=> $cData
						)
					);
					//array_push($this->_tmpParagraph, array($this->_xmlContentHTMLTag => .= '<'.$this->_xmlContentHTMLTag.'>'.$cData.'</'.$this->_xmlContentHTMLTag.'>';
//				} else {
//					array_push(
//						$this->_tmpParagraph,
//						array(
//							'type'	=> '',
//							'data'	=> $cData
//						)
//					);
//					//$this->_tmpParagraph .= $cData;
//				}
			} else {
				if (!isset($this->_currentXmlElement['cdata'])) {
					$this->_currentXmlElement['cdata'] = $cData;
				} else {
					$this->_currentXmlElement['cdata'] .= $cData;
				}
			}
		}
	}

	/**
	* XML parser end tag
	*
	* @access private
	* @param resource $parser
	* @param string $name
	*/
	function _xmlEndTag($parser,$name)
	{
		if ($this->_inNITF) {
			if ($name == "BODY.CONTENT") {
				$this->_inParagraph = false;
				$this->_xmlContentHTMLTag = '';

//				if (!isset($this->_currentXmlElement['cdata'])) {
//					$this->_currentXmlElement['cdata'] = "";
//				}
				$this->_currentXmlElement['cdata'] = $this->_tmpParagraph;
				$this->_tmpParagraph = array();
			}

			if ($name == "NITF") {
				$this->_inNITF = false;
			}
		} else {
			$this->_currentXmlElement = &$this->_arrParentXmlElement[$name];
			unset($this->_arrParentXmlElement[$name]);
		}
	}

	/*
	* These functions are for future usage
	*
	function _execNewsManagementInstruction($providerId)
	{
		global $objDatabase;

		$arrNewsMLDocuments = array();

		$objNewsMLDocument = $objDatabase->Execute("SELECT
			publicIdentifier,
			dateId,
			newsItemId,
			revisionId
			FROM ".DBPREFIX."module_feed_newsml_documents
			WHERE providerId=".$providerId."
			ORDER BY dateId, newsItemId, revisionId");
		if ($objNewsMLDocument !== false) {
			while (!$objNewsMLDocument->EOF) {
				$arrNewsMLDocuments[$objNewsMLDocument->fields['dateId']][$objNewsMLDocument->fields['newsItemId']][$objNewsMLDocument->fields['revisionId']] = array(
					'publicIdentifier'	=> $objNewsMLDocument->fields['publicIdentifier'],
					//'instruction'		=> $objNewsMLDocument->
					'status'			=> true
				);
				$objNewsMLDocument->MoveNext();
			}
		}

		foreach ($arrNewsMLDocuments as $dateId => $arrNewsItems) {
			foreach ($arrNewsItems as $newsItemId => $arrRevisions) {
				foreach ($arrRevisions as $revisionId => $arrRevision) {
					if ($arrRevision['status']) {
						$this->_SDA_newsManagementInstruction();
					}
				}
			}
		}
		print_r($arrNewsMLDocuments);
	}

	function _SDA_newsManagementInstruction($instruction)
	{

		switch ($instruction) {
		case 'Rectify': // indicates that the current story replaces all previous versions of the story.

			break;

		case 'Update': // indicates an update, which adds relevant information that is missing in earlier revisions.

			break;

		case 'Delete': // instructs to remove all revisions of the referenced story (full retraction of a news item).

			break;

		case 'LiftEmbargo': // instructs to release a story from embargo.

			break;
		}
	}
	*/
}
?>
