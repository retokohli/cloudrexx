<?php
/**
* Contrexx CMS
* generated date Tue,  2 May 2006 17:09:47 +0200
**/

$_ARRAYLANG['TXT_FEED_NO_NEWSFEED'] = "Keine NewsFeeds vorhanden!";
$_ARRAYLANG['TXT_FEED_LAST_UPDATE'] = "Letzte Aktualisierung";
?>